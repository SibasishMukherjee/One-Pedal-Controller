/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: controller.h
 *
 * Code generated for Simulink model 'controller'.
 *
 * Model version                  : 3.80
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Fri Jun  9 23:37:10 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_controller_h_
#define RTW_HEADER_controller_h_
#ifndef controller_COMMON_INCLUDES_
#define controller_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* controller_COMMON_INCLUDES_ */

#include "controller_types.h"

/* Block signals for model 'controller' */
typedef struct {
  real_T TargetSpeed_km_h;             /* '<Root>/OnePedal_Controller' */
  real32_T TorqueRequest_Nm;           /* '<Root>/OnePedal_Supervisor' */
  real32_T TorqueRequest_Nm_e;         /* '<Root>/OnePedal_Controller' */
  real32_T StoppedControllerMode;      /* '<Root>/OnePedal_Controller' */
  int32_T AutomaticTransmissionState;  /* '<Root>/OnePedal_Supervisor' */
} B_controller_c_T;

/* Block states (default storage) for model 'controller' */
typedef struct {
  uint16_T temporalCounter_i1;         /* '<Root>/OnePedal_Supervisor' */
  uint8_T is_c1_controller;            /* '<Root>/OnePedal_Supervisor' */
  uint8_T is_active_c1_controller;     /* '<Root>/OnePedal_Supervisor' */
  uint8_T is_c3_controller;            /* '<Root>/OnePedal_Controller' */
  uint8_T is_Reverse;                  /* '<Root>/OnePedal_Controller' */
  uint8_T is_Drive;                    /* '<Root>/OnePedal_Controller' */
  uint8_T is_Brake;                    /* '<Root>/OnePedal_Controller' */
  uint8_T is_active_c3_controller;     /* '<Root>/OnePedal_Controller' */
} DW_controller_f_T;

/* Parameters (default storage) */
struct P_controller_T_ {
  real_T Gain_Gain;                    /* Expression: 30
                                        * Referenced by: '<Root>/Gain'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 80
                                        * Referenced by: '<Root>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: -80
                                        * Referenced by: '<Root>/Saturation1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_controller_T {
  const char_T **errorStatus;
};

typedef struct {
  B_controller_c_T rtb;
  DW_controller_f_T rtdw;
  RT_MODEL_controller_T rtm;
} MdlrefDW_controller_T;

/* Model block global parameters (default storage) */
extern real_T rtP_MAX_TORQUE;          /* Variable: MAX_TORQUE
                                        * Referenced by: '<Root>/OnePedal_Controller'
                                        */
extern real_T rtP_MAX_TORQUE_REVERSE;  /* Variable: MAX_TORQUE_REVERSE
                                        * Referenced by: '<Root>/OnePedal_Controller'
                                        */

/* Model reference registration function */
extern void controller_initialize(const char_T **rt_errorStatus,
  RT_MODEL_controller_T *const controller_M);
extern void controller(const boolean_T *rtu_BrakePedalPressed, const real32_T
  *rtu_ThrottlePedalPosition, const TransmissionState
  *rtu_AutomaticTransmissionSelect, const boolean_T
  *rtu_BrakePedalPressed_Backup, const real32_T *rtu_ThrottlePedalPosition_Backu,
  const real32_T *rtu_VehicleSpeed_km_h, real32_T *rty_TorqueRequest_Nm,
  TransmissionState *rty_AutomaticTransmissionState, real32_T *rty_Error,
  real32_T *rty_Error_TS, B_controller_c_T *localB, DW_controller_f_T *localDW);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'controller'
 * '<S1>'   : 'controller/OnePedal_Controller'
 * '<S2>'   : 'controller/OnePedal_Supervisor'
 */
#endif                                 /* RTW_HEADER_controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

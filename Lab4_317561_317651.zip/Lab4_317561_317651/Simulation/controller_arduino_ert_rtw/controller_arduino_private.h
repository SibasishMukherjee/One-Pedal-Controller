/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: controller_arduino_private.h
 *
 * Code generated for Simulink model 'controller_arduino'.
 *
 * Model version                  : 1.13
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sat Jun 10 15:27:39 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_controller_arduino_private_h_
#define RTW_HEADER_controller_arduino_private_h_
#include "rtwtypes.h"
#include "controller_arduino.h"
#include "controller_arduino_types.h"

extern boolean_T controller_ar_IfActionSubsystem(int32_T rtu_In1,
  P_IfActionSubsystem_controlle_T *localP);

#endif                            /* RTW_HEADER_controller_arduino_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: controller_arduino.c
 *
 * Code generated for Simulink model 'controller_arduino'.
 *
 * Model version                  : 1.13
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sat Jun 10 15:27:39 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "controller_arduino.h"
#include "rtwtypes.h"
#include "controller_arduino_private.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "rt_roundf_snf.h"
#include "controller_arduino_types.h"
#include "controller.h"

/* Block signals (default storage) */
B_controller_arduino_T controller_arduino_B;

/* Block states (default storage) */
DW_controller_arduino_T controller_arduino_DW;

/* Real-time model */
static RT_MODEL_controller_arduino_T controller_arduino_M_;
RT_MODEL_controller_arduino_T *const controller_arduino_M =
  &controller_arduino_M_;
static void rate_scheduler(void);

/*
 *         This function updates active task flag for each subrate.
 *         The function is called at model base rate, hence the
 *         generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (controller_arduino_M->Timing.TaskCounters.TID[1])++;
  if ((controller_arduino_M->Timing.TaskCounters.TID[1]) > 9) {/* Sample time: [0.1s, 0.0s] */
    controller_arduino_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/*
 * Output and update for atomic system:
 *    '<Root>/If Action Subsystem'
 *    '<Root>/If Action Subsystem1'
 *    '<Root>/If Action Subsystem2'
 *    '<Root>/If Action Subsystem3'
 *    '<Root>/If Action Subsystem4'
 */
boolean_T controller_ar_IfActionSubsystem(int32_T rtu_In1,
  P_IfActionSubsystem_controlle_T *localP)
{
  /* RelationalOperator: '<S1>/Relational Operator' incorporates:
   *  Constant: '<S1>/Constant7'
   */
  return rtu_In1 == localP->Constant7_Value;
}

/* Model step function */
void controller_arduino_step(void)
{
  /* local block i/o variables */
  real32_T rtb_Controller_o1;
  TransmissionState rtb_AutomaticTransmissionState;
  codertarget_arduinobase_inter_T *obj;
  real_T tmp;
  real32_T rtb_DataTypeConversion10;
  real32_T rtb_DataTypeConversion7;
  real32_T rtb_DataTypeConversion8;
  uint16_T b_varargout_1;
  uint8_T tmp_0;
  boolean_T rtb_RelationalOperator_o;
  TransmissionState rtb_DataTypeConversion2;
  if (controller_arduino_M->Timing.TaskCounters.TID[1] == 0) {
    /* MATLABSystem: '<Root>/Digital Input' */
    if (controller_arduino_DW.obj_gg.SampleTime !=
        controller_arduino_P.DigitalInput_SampleTime) {
      controller_arduino_DW.obj_gg.SampleTime =
        controller_arduino_P.DigitalInput_SampleTime;
    }

    /* MATLABSystem: '<Root>/Digital Input' */
    controller_arduino_B.DigitalInput = readDigitalPin(9);
  }

  /* MATLABSystem: '<Root>/Analog Input' */
  if (controller_arduino_DW.obj_g.SampleTime !=
      controller_arduino_P.AnalogInput_SampleTime) {
    controller_arduino_DW.obj_g.SampleTime =
      controller_arduino_P.AnalogInput_SampleTime;
  }

  obj = &controller_arduino_DW.obj_g;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(14UL);
  controller_arduino_B.datatype_id = MW_ANALOGIN_UINT16;
  MW_AnalogInSingle_ReadResult
    (controller_arduino_DW.obj_g.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, controller_arduino_B.datatype_id);

  /* DataTypeConversion: '<Root>/Data Type Conversion8' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  Gain: '<Root>/Gain5'
   *  Gain: '<Root>/Gain6'
   *  MATLABSystem: '<Root>/Analog Input'
   */
  rtb_DataTypeConversion8 = (real32_T)(controller_arduino_P.Gain5_Gain * (real_T)
    b_varargout_1 * controller_arduino_P.Gain6_Gain);

  /* MATLABSystem: '<Root>/Analog Input2' */
  if (controller_arduino_DW.obj_i.SampleTime !=
      controller_arduino_P.AnalogInput2_SampleTime) {
    controller_arduino_DW.obj_i.SampleTime =
      controller_arduino_P.AnalogInput2_SampleTime;
  }

  obj = &controller_arduino_DW.obj_i;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(16UL);
  controller_arduino_B.datatype_id = MW_ANALOGIN_UINT16;
  MW_AnalogInSingle_ReadResult
    (controller_arduino_DW.obj_i.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, controller_arduino_B.datatype_id);

  /* DataTypeConversion: '<Root>/Data Type Conversion6' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion4'
   *  Gain: '<Root>/Gain1'
   *  Gain: '<Root>/Gain2'
   *  MATLABSystem: '<Root>/Analog Input2'
   */
  tmp = floor(controller_arduino_P.Gain2_Gain * (real_T)b_varargout_1 *
              controller_arduino_P.Gain1_Gain);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  /* DataTypeConversion: '<Root>/Data Type Conversion2' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion6'
   */
  rtb_DataTypeConversion2 = (TransmissionState)(tmp < 0.0 ? -(int32_T)(uint32_T)
    -tmp : (int32_T)(uint32_T)tmp);
  if (controller_arduino_M->Timing.TaskCounters.TID[1] == 0) {
    /* MATLABSystem: '<Root>/Digital Input1' */
    if (controller_arduino_DW.obj_d.SampleTime !=
        controller_arduino_P.DigitalInput1_SampleTime) {
      controller_arduino_DW.obj_d.SampleTime =
        controller_arduino_P.DigitalInput1_SampleTime;
    }

    /* MATLABSystem: '<Root>/Digital Input1' */
    controller_arduino_B.DigitalInput1 = readDigitalPin(10);
  }

  /* MATLABSystem: '<Root>/Analog Input1' */
  if (controller_arduino_DW.obj_m.SampleTime !=
      controller_arduino_P.AnalogInput1_SampleTime) {
    controller_arduino_DW.obj_m.SampleTime =
      controller_arduino_P.AnalogInput1_SampleTime;
  }

  obj = &controller_arduino_DW.obj_m;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(15UL);
  controller_arduino_B.datatype_id = MW_ANALOGIN_UINT16;
  MW_AnalogInSingle_ReadResult
    (controller_arduino_DW.obj_m.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, controller_arduino_B.datatype_id);

  /* DataTypeConversion: '<Root>/Data Type Conversion10' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   *  Gain: '<Root>/Gain7'
   *  Gain: '<Root>/Gain8'
   *  MATLABSystem: '<Root>/Analog Input1'
   */
  rtb_DataTypeConversion10 = (real32_T)(controller_arduino_P.Gain7_Gain *
    (real_T)b_varargout_1 * controller_arduino_P.Gain8_Gain);

  /* MATLABSystem: '<Root>/Analog Input3' */
  if (controller_arduino_DW.obj.SampleTime !=
      controller_arduino_P.AnalogInput3_SampleTime) {
    controller_arduino_DW.obj.SampleTime =
      controller_arduino_P.AnalogInput3_SampleTime;
  }

  obj = &controller_arduino_DW.obj;
  obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(17UL);
  controller_arduino_B.datatype_id = MW_ANALOGIN_UINT16;
  MW_AnalogInSingle_ReadResult
    (controller_arduino_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, controller_arduino_B.datatype_id);

  /* DataTypeConversion: '<Root>/Data Type Conversion7' incorporates:
   *  Constant: '<Root>/LowerBound_km_h'
   *  DataTypeConversion: '<Root>/Data Type Conversion3'
   *  Gain: '<Root>/Gain3'
   *  Gain: '<Root>/Gain4'
   *  MATLABSystem: '<Root>/Analog Input3'
   *  Sum: '<Root>/Sum'
   */
  rtb_DataTypeConversion7 = (real32_T)(controller_arduino_P.Gain3_Gain * (real_T)
    b_varargout_1 * controller_arduino_P.Gain4_Gain +
    controller_arduino_P.LowerBound_km_h_Value);

  /* ModelReference: '<Root>/Controller' */
  controller(&controller_arduino_B.DigitalInput, &rtb_DataTypeConversion8,
             &rtb_DataTypeConversion2, &controller_arduino_B.DigitalInput1,
             &rtb_DataTypeConversion10, &rtb_DataTypeConversion7,
             &rtb_Controller_o1, &rtb_AutomaticTransmissionState,
             &controller_arduino_B.Error, &controller_arduino_B.Error_TS,
             &(controller_arduino_DW.Controller_InstanceData.rtb),
             &(controller_arduino_DW.Controller_InstanceData.rtdw));

  /* MATLABSystem: '<Root>/Digital Output' incorporates:
   *  Constant: '<Root>/Constant'
   *  RelationalOperator: '<Root>/Relational Operator'
   */
  writeDigitalPin(2, (uint8_T)(rtb_Controller_o1 >
    controller_arduino_P.Constant_Value));

  /* Outputs for Atomic SubSystem: '<Root>/If Action Subsystem' */
  /* DataTypeConversion: '<Root>/Data Type Conversion9' */
  rtb_RelationalOperator_o = controller_ar_IfActionSubsystem((int32_T)
    rtb_AutomaticTransmissionState, &controller_arduino_P.IfActionSubsystem);

  /* End of Outputs for SubSystem: '<Root>/If Action Subsystem' */

  /* MATLABSystem: '<Root>/Digital Output1' */
  writeDigitalPin(4, (uint8_T)rtb_RelationalOperator_o);

  /* Outputs for Atomic SubSystem: '<Root>/If Action Subsystem1' */
  /* DataTypeConversion: '<Root>/Data Type Conversion9' */
  rtb_RelationalOperator_o = controller_ar_IfActionSubsystem((int32_T)
    rtb_AutomaticTransmissionState, &controller_arduino_P.IfActionSubsystem1);

  /* End of Outputs for SubSystem: '<Root>/If Action Subsystem1' */

  /* MATLABSystem: '<Root>/Digital Output5' */
  writeDigitalPin(5, (uint8_T)rtb_RelationalOperator_o);

  /* Outputs for Atomic SubSystem: '<Root>/If Action Subsystem2' */
  /* DataTypeConversion: '<Root>/Data Type Conversion9' */
  rtb_RelationalOperator_o = controller_ar_IfActionSubsystem((int32_T)
    rtb_AutomaticTransmissionState, &controller_arduino_P.IfActionSubsystem2);

  /* End of Outputs for SubSystem: '<Root>/If Action Subsystem2' */

  /* MATLABSystem: '<Root>/Digital Output6' */
  writeDigitalPin(6, (uint8_T)rtb_RelationalOperator_o);

  /* Outputs for Atomic SubSystem: '<Root>/If Action Subsystem3' */
  /* DataTypeConversion: '<Root>/Data Type Conversion9' */
  rtb_RelationalOperator_o = controller_ar_IfActionSubsystem((int32_T)
    rtb_AutomaticTransmissionState, &controller_arduino_P.IfActionSubsystem3);

  /* End of Outputs for SubSystem: '<Root>/If Action Subsystem3' */

  /* MATLABSystem: '<Root>/Digital Output7' */
  writeDigitalPin(7, (uint8_T)rtb_RelationalOperator_o);

  /* Outputs for Atomic SubSystem: '<Root>/If Action Subsystem4' */
  /* DataTypeConversion: '<Root>/Data Type Conversion9' */
  rtb_RelationalOperator_o = controller_ar_IfActionSubsystem((int32_T)
    rtb_AutomaticTransmissionState, &controller_arduino_P.IfActionSubsystem4);

  /* End of Outputs for SubSystem: '<Root>/If Action Subsystem4' */

  /* MATLABSystem: '<Root>/Digital Output8' */
  writeDigitalPin(8, (uint8_T)rtb_RelationalOperator_o);

  /* MATLABSystem: '<Root>/Digital Output2' */
  rtb_DataTypeConversion8 = rt_roundf_snf(controller_arduino_B.Error);
  if (rtb_DataTypeConversion8 < 256.0F) {
    if (rtb_DataTypeConversion8 >= 0.0F) {
      tmp_0 = (uint8_T)rtb_DataTypeConversion8;
    } else {
      tmp_0 = 0U;
    }
  } else {
    tmp_0 = MAX_uint8_T;
  }

  writeDigitalPin(12, tmp_0);

  /* End of MATLABSystem: '<Root>/Digital Output2' */

  /* MATLABSystem: '<Root>/Digital Output3' */
  rtb_DataTypeConversion8 = rt_roundf_snf(controller_arduino_B.Error_TS);
  if (rtb_DataTypeConversion8 < 256.0F) {
    if (rtb_DataTypeConversion8 >= 0.0F) {
      tmp_0 = (uint8_T)rtb_DataTypeConversion8;
    } else {
      tmp_0 = 0U;
    }
  } else {
    tmp_0 = MAX_uint8_T;
  }

  writeDigitalPin(11, tmp_0);

  /* End of MATLABSystem: '<Root>/Digital Output3' */

  /* MATLABSystem: '<Root>/Digital Output4' incorporates:
   *  Constant: '<Root>/Constant1'
   *  RelationalOperator: '<Root>/Relational Operator1'
   */
  writeDigitalPin(3, (uint8_T)(rtb_Controller_o1 <
    controller_arduino_P.Constant1_Value));

  /* Logic: '<Root>/NOT1' incorporates:
   *  Delay: '<Root>/Delay1'
   */
  controller_arduino_DW.Delay1_DSTATE = !controller_arduino_DW.Delay1_DSTATE;

  /* MATLABSystem: '<Root>/Digital Output9' incorporates:
   *  Delay: '<Root>/Delay1'
   */
  writeDigitalPin(13, (uint8_T)controller_arduino_DW.Delay1_DSTATE);
  rate_scheduler();
}

/* Model initialize function */
void controller_arduino_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* Model Initialize function for ModelReference Block: '<Root>/Controller' */
  controller_initialize(rtmGetErrorStatusPointer(controller_arduino_M),
                        &(controller_arduino_DW.Controller_InstanceData.rtm));

  {
    codertarget_arduinobase_inter_T *obj;

    /* InitializeConditions for Delay: '<Root>/Delay1' */
    controller_arduino_DW.Delay1_DSTATE =
      controller_arduino_P.Delay1_InitialCondition;

    /* Start for MATLABSystem: '<Root>/Digital Input' */
    controller_arduino_DW.obj_gg.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_gg.SampleTime =
      controller_arduino_P.DigitalInput_SampleTime;
    controller_arduino_DW.obj_gg.isInitialized = 1L;
    digitalIOSetup(9, 0);
    controller_arduino_DW.obj_gg.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Analog Input' */
    controller_arduino_DW.obj_g.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_g.SampleTime =
      controller_arduino_P.AnalogInput_SampleTime;
    obj = &controller_arduino_DW.obj_g;
    controller_arduino_DW.obj_g.isInitialized = 1L;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(14UL);
    controller_arduino_DW.obj_g.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Analog Input2' */
    controller_arduino_DW.obj_i.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_i.SampleTime =
      controller_arduino_P.AnalogInput2_SampleTime;
    obj = &controller_arduino_DW.obj_i;
    controller_arduino_DW.obj_i.isInitialized = 1L;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(16UL);
    controller_arduino_DW.obj_i.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Input1' */
    controller_arduino_DW.obj_d.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_d.SampleTime =
      controller_arduino_P.DigitalInput1_SampleTime;
    controller_arduino_DW.obj_d.isInitialized = 1L;
    digitalIOSetup(10, 0);
    controller_arduino_DW.obj_d.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Analog Input1' */
    controller_arduino_DW.obj_m.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_m.SampleTime =
      controller_arduino_P.AnalogInput1_SampleTime;
    obj = &controller_arduino_DW.obj_m;
    controller_arduino_DW.obj_m.isInitialized = 1L;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(15UL);
    controller_arduino_DW.obj_m.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Analog Input3' */
    controller_arduino_DW.obj.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj.SampleTime =
      controller_arduino_P.AnalogInput3_SampleTime;
    obj = &controller_arduino_DW.obj;
    controller_arduino_DW.obj.isInitialized = 1L;
    obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(17UL);
    controller_arduino_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output' */
    controller_arduino_DW.obj_h5.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_h5.isInitialized = 1L;
    digitalIOSetup(2, 1);
    controller_arduino_DW.obj_h5.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output1' */
    controller_arduino_DW.obj_hy.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_hy.isInitialized = 1L;
    digitalIOSetup(4, 1);
    controller_arduino_DW.obj_hy.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output5' */
    controller_arduino_DW.obj_j.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_j.isInitialized = 1L;
    digitalIOSetup(5, 1);
    controller_arduino_DW.obj_j.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output6' */
    controller_arduino_DW.obj_h.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_h.isInitialized = 1L;
    digitalIOSetup(6, 1);
    controller_arduino_DW.obj_h.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output7' */
    controller_arduino_DW.obj_n.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_n.isInitialized = 1L;
    digitalIOSetup(7, 1);
    controller_arduino_DW.obj_n.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output8' */
    controller_arduino_DW.obj_e.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_e.isInitialized = 1L;
    digitalIOSetup(8, 1);
    controller_arduino_DW.obj_e.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output2' */
    controller_arduino_DW.obj_jv.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_jv.isInitialized = 1L;
    digitalIOSetup(12, 1);
    controller_arduino_DW.obj_jv.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output3' */
    controller_arduino_DW.obj_b.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_b.isInitialized = 1L;
    digitalIOSetup(11, 1);
    controller_arduino_DW.obj_b.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output4' */
    controller_arduino_DW.obj_de.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_de.isInitialized = 1L;
    digitalIOSetup(3, 1);
    controller_arduino_DW.obj_de.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Output9' */
    controller_arduino_DW.obj_iz.matlabCodegenIsDeleted = false;
    controller_arduino_DW.obj_iz.isInitialized = 1L;
    digitalIOSetup(13, 1);
    controller_arduino_DW.obj_iz.isSetupComplete = true;
  }
}

/* Model terminate function */
void controller_arduino_terminate(void)
{
  codertarget_arduinobase_inter_T *obj;

  /* Terminate for MATLABSystem: '<Root>/Digital Input' */
  if (!controller_arduino_DW.obj_gg.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_gg.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Input' */

  /* Terminate for MATLABSystem: '<Root>/Analog Input' */
  obj = &controller_arduino_DW.obj_g;
  if (!controller_arduino_DW.obj_g.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_g.matlabCodegenIsDeleted = true;
    if ((controller_arduino_DW.obj_g.isInitialized == 1L) &&
        controller_arduino_DW.obj_g.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(14UL);
      MW_AnalogIn_Close
        (controller_arduino_DW.obj_g.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input' */

  /* Terminate for MATLABSystem: '<Root>/Analog Input2' */
  obj = &controller_arduino_DW.obj_i;
  if (!controller_arduino_DW.obj_i.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_i.matlabCodegenIsDeleted = true;
    if ((controller_arduino_DW.obj_i.isInitialized == 1L) &&
        controller_arduino_DW.obj_i.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(16UL);
      MW_AnalogIn_Close
        (controller_arduino_DW.obj_i.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input2' */

  /* Terminate for MATLABSystem: '<Root>/Digital Input1' */
  if (!controller_arduino_DW.obj_d.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_d.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Input1' */

  /* Terminate for MATLABSystem: '<Root>/Analog Input1' */
  obj = &controller_arduino_DW.obj_m;
  if (!controller_arduino_DW.obj_m.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_m.matlabCodegenIsDeleted = true;
    if ((controller_arduino_DW.obj_m.isInitialized == 1L) &&
        controller_arduino_DW.obj_m.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(15UL);
      MW_AnalogIn_Close
        (controller_arduino_DW.obj_m.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input1' */

  /* Terminate for MATLABSystem: '<Root>/Analog Input3' */
  obj = &controller_arduino_DW.obj;
  if (!controller_arduino_DW.obj.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj.matlabCodegenIsDeleted = true;
    if ((controller_arduino_DW.obj.isInitialized == 1L) &&
        controller_arduino_DW.obj.isSetupComplete) {
      obj->AnalogInDriverObj.MW_ANALOGIN_HANDLE = MW_AnalogIn_GetHandle(17UL);
      MW_AnalogIn_Close
        (controller_arduino_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Analog Input3' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output' */
  if (!controller_arduino_DW.obj_h5.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_h5.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output1' */
  if (!controller_arduino_DW.obj_hy.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_hy.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output1' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output5' */
  if (!controller_arduino_DW.obj_j.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_j.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output5' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output6' */
  if (!controller_arduino_DW.obj_h.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_h.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output6' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output7' */
  if (!controller_arduino_DW.obj_n.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_n.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output7' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output8' */
  if (!controller_arduino_DW.obj_e.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_e.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output8' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output2' */
  if (!controller_arduino_DW.obj_jv.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_jv.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output2' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output3' */
  if (!controller_arduino_DW.obj_b.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_b.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output3' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output4' */
  if (!controller_arduino_DW.obj_de.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_de.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output4' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output9' */
  if (!controller_arduino_DW.obj_iz.matlabCodegenIsDeleted) {
    controller_arduino_DW.obj_iz.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output9' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

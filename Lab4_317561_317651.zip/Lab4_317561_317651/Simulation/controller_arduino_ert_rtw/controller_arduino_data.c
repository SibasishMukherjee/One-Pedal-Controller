/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: controller_arduino_data.c
 *
 * Code generated for Simulink model 'controller_arduino'.
 *
 * Model version                  : 1.13
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sat Jun 10 15:27:39 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "controller_arduino.h"

/* Model block global parameters (default storage) */
real_T rtP_MAX_TORQUE = 80.0;          /* Variable: MAX_TORQUE
                                        * Referenced by: '<Root>/Controller'
                                        */
real_T rtP_MAX_TORQUE_REVERSE = 40.0;  /* Variable: MAX_TORQUE_REVERSE
                                        * Referenced by: '<Root>/Controller'
                                        */

/* Block parameters (default storage) */
P_controller_arduino_T controller_arduino_P = {
  /* Expression: -1
   * Referenced by: '<Root>/Analog Input'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<Root>/Analog Input1'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<Root>/Analog Input2'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<Root>/Analog Input3'
   */
  -1.0,

  /* Expression: 0.1
   * Referenced by: '<Root>/Digital Input'
   */
  0.1,

  /* Expression: 0.1
   * Referenced by: '<Root>/Digital Input1'
   */
  0.1,

  /* Expression: 5/((2^10)-1)
   * Referenced by: '<Root>/Gain5'
   */
  0.0048875855327468231,

  /* Expression: 1/5
   * Referenced by: '<Root>/Gain6'
   */
  0.2,

  /* Expression: 5/((2^10)-1)
   * Referenced by: '<Root>/Gain2'
   */
  0.0048875855327468231,

  /* Expression: 4/5
   * Referenced by: '<Root>/Gain1'
   */
  0.8,

  /* Expression: 5/((2^10)-1)
   * Referenced by: '<Root>/Gain7'
   */
  0.0048875855327468231,

  /* Expression: 1/5
   * Referenced by: '<Root>/Gain8'
   */
  0.2,

  /* Expression: 5/((2^10)-1)
   * Referenced by: '<Root>/Gain3'
   */
  0.0048875855327468231,

  /* Expression: 300/5
   * Referenced by: '<Root>/Gain4'
   */
  60.0,

  /* Expression: -60
   * Referenced by: '<Root>/LowerBound_km_h'
   */
  -60.0,

  /* Expression: 0
   * Referenced by: '<Root>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Constant1'
   */
  0.0,

  /* Computed Parameter: Delay1_InitialCondition
   * Referenced by: '<Root>/Delay1'
   */
  false,

  /* Start of '<Root>/If Action Subsystem4' */
  {
    /* Expression: 4
     * Referenced by: '<S5>/Constant7'
     */
    4.0
  }
  ,

  /* End of '<Root>/If Action Subsystem4' */

  /* Start of '<Root>/If Action Subsystem3' */
  {
    /* Expression: 3
     * Referenced by: '<S4>/Constant7'
     */
    3.0
  }
  ,

  /* End of '<Root>/If Action Subsystem3' */

  /* Start of '<Root>/If Action Subsystem2' */
  {
    /* Expression: 2
     * Referenced by: '<S3>/Constant7'
     */
    2.0
  }
  ,

  /* End of '<Root>/If Action Subsystem2' */

  /* Start of '<Root>/If Action Subsystem1' */
  {
    /* Expression: 1
     * Referenced by: '<S2>/Constant7'
     */
    1.0
  }
  ,

  /* End of '<Root>/If Action Subsystem1' */

  /* Start of '<Root>/If Action Subsystem' */
  {
    /* Expression: 0
     * Referenced by: '<S1>/Constant7'
     */
    0.0
  }
  /* End of '<Root>/If Action Subsystem' */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

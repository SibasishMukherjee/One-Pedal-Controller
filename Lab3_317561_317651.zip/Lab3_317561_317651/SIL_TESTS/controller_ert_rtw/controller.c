/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: controller.c
 *
 * Code generated for Simulink model 'controller'.
 *
 * Model version                  : 3.72
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sat May 27 22:39:19 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "controller.h"
#include "rtwtypes.h"
#include <math.h>
#include "controller_types.h"

/* Named constants for Chart: '<Root>/OnePedal_Controller' */
#define c_IN_EmergencyStop_ReverseState ((uint8_T)2U)
#define con_IN_EmergencyStop_BrakeState ((uint8_T)3U)
#define con_IN_EmergencyStop_DriveState ((uint8_T)2U)
#define controller_IN_Accelerating     ((uint8_T)1U)
#define controller_IN_Brake            ((uint8_T)1U)
#define controller_IN_Braking          ((uint8_T)2U)
#define controller_IN_Cruise           ((uint8_T)1U)
#define controller_IN_Drive            ((uint8_T)2U)
#define controller_IN_NO_ACTIVE_CHILD  ((uint8_T)0U)
#define controller_IN_Neutral          ((uint8_T)3U)
#define controller_IN_Parking          ((uint8_T)4U)
#define controller_IN_Reverse          ((uint8_T)5U)
#define controller_IN_Stopping         ((uint8_T)4U)

/* Named constants for Chart: '<Root>/OnePedal_Supervisor' */
#define IN_TransmissionStateErrorDetect ((uint8_T)5U)
#define c_IN_ThrottlePedalErrorDetected ((uint8_T)4U)
#define cont_IN_BrakePedalErrorDetected ((uint8_T)1U)
#define controller_IN_Error            ((uint8_T)2U)
#define controller_IN_NormalOperations ((uint8_T)3U)

/* Block signals (default storage) */
B_controller_T controller_B;

/* Block states (default storage) */
DW_controller_T controller_DW;

/* External inputs (root inport signals with default storage) */
ExtU_controller_T controller_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_controller_T controller_Y;

/* Real-time model */
static RT_MODEL_controller_T controller_M_;
RT_MODEL_controller_T *const controller_M = &controller_M_;

/* Model step function */
void controller_step(void)
{
  int32_T rtb_AutomaticTransmissionState;
  real32_T rtb_Saturation;

  /* Saturate: '<Root>/Saturation' incorporates:
   *  Inport: '<Root>/ThrottlePedalPosition'
   */
  if (controller_U.ThrottlePedalPosition > 0.5F) {
    rtb_Saturation = 0.5F;
  } else if (controller_U.ThrottlePedalPosition < -0.5F) {
    rtb_Saturation = -0.5F;
  } else {
    rtb_Saturation = controller_U.ThrottlePedalPosition;
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* Chart: '<Root>/OnePedal_Controller' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   *  Inport: '<Root>/AutomaticTransmissionSelectorState'
   *  Inport: '<Root>/BrakePedalPressed'
   *  Inport: '<Root>/VehicleSpeed_km_h'
   */
  if (controller_DW.is_active_c3_controller == 0U) {
    controller_DW.is_active_c3_controller = 1U;
    controller_DW.is_c3_controller = controller_IN_Parking;
    rtb_AutomaticTransmissionState = 0;
  } else {
    switch (controller_DW.is_c3_controller) {
     case controller_IN_Brake:
      {
        rtb_AutomaticTransmissionState = 4;
        if ((int32_T)controller_U.AutomaticTransmissionSelectorSt != 4) {
          controller_DW.is_Brake = controller_IN_NO_ACTIVE_CHILD;
          controller_DW.is_c3_controller = controller_IN_Drive;
          rtb_AutomaticTransmissionState = 3;
          controller_DW.is_Drive = controller_IN_Cruise;
        } else {
          switch (controller_DW.is_Brake) {
           case controller_IN_Accelerating:
            if (rtb_Saturation < 0.33333333333333331) {
              controller_DW.is_Brake = controller_IN_Braking;
              controller_B.StoppedControllerMode = 0.0F;
            } else if (controller_U.BrakePedalPressed) {
              controller_DW.is_Brake = con_IN_EmergencyStop_BrakeState;
            } else {
              controller_B.TorqueRequest_Nm_e = (rtb_Saturation - 0.333333343F) *
                120.0F;
            }
            break;

           case controller_IN_Braking:
            if (rtb_Saturation > 0.33333333333333331) {
              controller_DW.is_Brake = controller_IN_Accelerating;
              controller_B.StoppedControllerMode = 0.0F;
            } else if (fabsf(controller_U.VehicleSpeed_km_h) <= 1.0F) {
              controller_DW.is_Brake = controller_IN_Stopping;
              controller_B.StoppedControllerMode = 1.0F;
            } else if (controller_U.BrakePedalPressed) {
              controller_DW.is_Brake = con_IN_EmergencyStop_BrakeState;
            } else {
              controller_B.TorqueRequest_Nm_e = (1.0F - 3.0F * rtb_Saturation) *
                -80.0F;
            }
            break;

           case con_IN_EmergencyStop_BrakeState:
            {
              boolean_T tmp;
              tmp = !controller_U.BrakePedalPressed;
              if ((rtb_Saturation > 0.33333333333333331) && tmp) {
                controller_DW.is_Brake = controller_IN_Accelerating;
                controller_B.StoppedControllerMode = 0.0F;
              } else if ((rtb_Saturation <= 0.33333333333333331) && tmp) {
                controller_DW.is_Brake = controller_IN_Braking;
                controller_B.StoppedControllerMode = 0.0F;
              } else {
                controller_B.StoppedControllerMode = 1.0F;
                controller_B.TargetSpeed_km_h = 0.0;
              }
            }
            break;

           default:
            /* case IN_Stopping: */
            if (rtb_Saturation > 0.33333333333333331) {
              controller_DW.is_Brake = controller_IN_Accelerating;
              controller_B.StoppedControllerMode = 0.0F;
            } else {
              controller_B.TargetSpeed_km_h = 0.0;
            }
            break;
          }
        }
      }
      break;

     case controller_IN_Drive:
      rtb_AutomaticTransmissionState = 3;
      if (((int32_T)controller_U.AutomaticTransmissionSelectorSt == 4) &&
          (rtb_Saturation > 0.33333333333333331)) {
        controller_DW.is_Drive = controller_IN_NO_ACTIVE_CHILD;
        controller_DW.is_c3_controller = controller_IN_Brake;
        rtb_AutomaticTransmissionState = 4;
        controller_DW.is_Brake = controller_IN_Braking;
        controller_B.StoppedControllerMode = 0.0F;
      } else if ((int32_T)controller_U.AutomaticTransmissionSelectorSt < 3) {
        controller_DW.is_Drive = controller_IN_NO_ACTIVE_CHILD;
        controller_DW.is_c3_controller = controller_IN_Neutral;
        rtb_AutomaticTransmissionState = 2;
      } else if (controller_DW.is_Drive == controller_IN_Cruise) {
        if (controller_U.BrakePedalPressed && (rtb_Saturation == 0.0F)) {
          controller_DW.is_Drive = con_IN_EmergencyStop_DriveState;
        } else {
          controller_B.TorqueRequest_Nm_e = 80.0F * rtb_Saturation;
        }

        /* case IN_EmergencyStop_DriveState: */
      } else if ((rtb_Saturation > 0.0F) && (!controller_U.BrakePedalPressed)) {
        controller_DW.is_Drive = controller_IN_Cruise;
      } else {
        controller_B.StoppedControllerMode = 1.0F;
        controller_B.TargetSpeed_km_h = 0.0;
      }
      break;

     case controller_IN_Neutral:
      rtb_AutomaticTransmissionState = 2;
      if ((fabsf(controller_U.VehicleSpeed_km_h) < 5.0F) &&
          (controller_U.BrakePedalPressed && ((int32_T)
            controller_U.AutomaticTransmissionSelectorSt == 0))) {
        controller_DW.is_c3_controller = controller_IN_Parking;
        rtb_AutomaticTransmissionState = 0;
      } else if ((controller_U.VehicleSpeed_km_h < 5.0F) &&
                 controller_U.BrakePedalPressed && ((int32_T)
                  controller_U.AutomaticTransmissionSelectorSt == 1)) {
        controller_DW.is_c3_controller = controller_IN_Reverse;
        rtb_AutomaticTransmissionState = 1;
        controller_DW.is_Reverse = controller_IN_Cruise;
      } else if ((controller_U.VehicleSpeed_km_h > -5.0F) &&
                 controller_U.BrakePedalPressed && ((int32_T)
                  controller_U.AutomaticTransmissionSelectorSt > 2)) {
        controller_DW.is_c3_controller = controller_IN_Drive;
        rtb_AutomaticTransmissionState = 3;
        controller_DW.is_Drive = controller_IN_Cruise;
      } else {
        controller_B.TorqueRequest_Nm_e = 0.0F;
      }
      break;

     case controller_IN_Parking:
      rtb_AutomaticTransmissionState = 0;
      if (controller_U.BrakePedalPressed && ((int32_T)
           controller_U.AutomaticTransmissionSelectorSt != 0)) {
        controller_DW.is_c3_controller = controller_IN_Neutral;
        rtb_AutomaticTransmissionState = 2;
      } else {
        controller_B.TorqueRequest_Nm_e = 0.0F;
      }
      break;

     default:
      /* case IN_Reverse: */
      rtb_AutomaticTransmissionState = 1;
      if ((int32_T)controller_U.AutomaticTransmissionSelectorSt != 1) {
        controller_DW.is_Reverse = controller_IN_NO_ACTIVE_CHILD;
        controller_DW.is_c3_controller = controller_IN_Neutral;
        rtb_AutomaticTransmissionState = 2;
      } else if (controller_DW.is_Reverse == controller_IN_Cruise) {
        if (controller_U.BrakePedalPressed && (rtb_Saturation == 0.0F)) {
          controller_DW.is_Reverse = c_IN_EmergencyStop_ReverseState;
        } else {
          controller_B.StoppedControllerMode = 0.0F;
          controller_B.TorqueRequest_Nm_e = -rtb_Saturation * 40.0F;
        }

        /* case IN_EmergencyStop_ReverseState: */
      } else if ((!controller_U.BrakePedalPressed) && (rtb_Saturation > 0.0F)) {
        controller_DW.is_Reverse = controller_IN_Cruise;
      } else {
        controller_B.StoppedControllerMode = 1.0F;
        controller_B.TargetSpeed_km_h = 0.0;
      }
      break;
    }
  }

  /* End of Chart: '<Root>/OnePedal_Controller' */

  /* Chart: '<Root>/OnePedal_Supervisor' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   *  Inport: '<Root>/AutomaticTransmissionSelectorState'
   *  Inport: '<Root>/BrakePedalPressed'
   *  Inport: '<Root>/BrakePedalPressed_Backup'
   *  Inport: '<Root>/ThrottlePedalPosition_Backup'
   */
  if (controller_DW.temporalCounter_i1 < 511U) {
    controller_DW.temporalCounter_i1++;
  }

  if (controller_DW.is_active_c1_controller == 0U) {
    controller_DW.is_active_c1_controller = 1U;
    controller_DW.is_c1_controller = controller_IN_NormalOperations;
  } else {
    switch (controller_DW.is_c1_controller) {
     case cont_IN_BrakePedalErrorDetected:
      if (controller_DW.temporalCounter_i1 >= 100U) {
        controller_DW.is_c1_controller = controller_IN_Error;
      } else if (controller_U.BrakePedalPressed_Backup ==
                 controller_U.BrakePedalPressed) {
        controller_DW.is_c1_controller = controller_IN_NormalOperations;
      }
      break;

     case controller_IN_Error:
      /* Outport: '<Root>/Error' */
      controller_Y.Error = 1.0F;
      controller_B.AutomaticTransmissionState = 2;
      controller_B.TorqueRequest_Nm = 0.0F;
      break;

     case controller_IN_NormalOperations:
      if (controller_U.ThrottlePedalPosition_Backup != rtb_Saturation) {
        controller_DW.is_c1_controller = c_IN_ThrottlePedalErrorDetected;
        controller_DW.temporalCounter_i1 = 0U;
      } else if (controller_U.BrakePedalPressed_Backup !=
                 controller_U.BrakePedalPressed) {
        controller_DW.is_c1_controller = cont_IN_BrakePedalErrorDetected;
        controller_DW.temporalCounter_i1 = 0U;
      } else if ((int32_T)controller_U.AutomaticTransmissionSelectorSt !=
                 rtb_AutomaticTransmissionState) {
        controller_DW.is_c1_controller = IN_TransmissionStateErrorDetect;
        controller_DW.temporalCounter_i1 = 0U;
      } else {
        /* Outport: '<Root>/Error' */
        controller_Y.Error = 0.0F;

        /* Outport: '<Root>/Error_TS' */
        controller_Y.Error_TS = 0.0F;
      }
      break;

     case c_IN_ThrottlePedalErrorDetected:
      if (controller_DW.temporalCounter_i1 >= 100U) {
        controller_DW.is_c1_controller = controller_IN_Error;
      } else if (controller_U.ThrottlePedalPosition_Backup == rtb_Saturation) {
        controller_DW.is_c1_controller = controller_IN_NormalOperations;
      }
      break;

     default:
      /* case IN_TransmissionStateErrorDetected: */
      if ((int32_T)controller_U.AutomaticTransmissionSelectorSt ==
          rtb_AutomaticTransmissionState) {
        controller_DW.is_c1_controller = controller_IN_NormalOperations;
      } else {
        /* Outport: '<Root>/Error_TS' */
        controller_Y.Error_TS = 1.0F;
        controller_B.TorqueRequest_Nm = 0.0F;
      }
      break;
    }
  }

  /* End of Chart: '<Root>/OnePedal_Supervisor' */

  /* Switch: '<Root>/Switch1' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion3'
   *  Logic: '<Root>/NOT2'
   *  Outport: '<Root>/Error'
   *  Outport: '<Root>/Error_TS'
   *  Sum: '<Root>/Add'
   */
  if (!(controller_Y.Error + controller_Y.Error_TS != 0.0F)) {
    real_T rtb_Switch;

    /* Switch: '<Root>/Switch' incorporates:
     *  Gain: '<Root>/Gain'
     *  Inport: '<Root>/VehicleSpeed_km_h'
     *  Logic: '<Root>/NOT'
     *  Sum: '<Root>/Sum'
     */
    if (!(controller_B.StoppedControllerMode != 0.0F)) {
      rtb_Switch = controller_B.TorqueRequest_Nm_e;
    } else {
      rtb_Switch = (controller_B.TargetSpeed_km_h -
                    controller_U.VehicleSpeed_km_h) * 30.0;
    }

    /* End of Switch: '<Root>/Switch' */

    /* Saturate: '<Root>/Saturation1' */
    if (rtb_Switch > 80.0) {
      /* Outport: '<Root>/TorqueRequest_Nm' */
      controller_Y.TorqueRequest_Nm = 80.0F;
    } else if (rtb_Switch < -80.0) {
      /* Outport: '<Root>/TorqueRequest_Nm' */
      controller_Y.TorqueRequest_Nm = -80.0F;
    } else {
      /* Outport: '<Root>/TorqueRequest_Nm' */
      controller_Y.TorqueRequest_Nm = (real32_T)rtb_Switch;
    }

    /* End of Saturate: '<Root>/Saturation1' */
  } else {
    /* Outport: '<Root>/TorqueRequest_Nm' */
    controller_Y.TorqueRequest_Nm = controller_B.TorqueRequest_Nm;
  }

  /* End of Switch: '<Root>/Switch1' */

  /* Switch: '<Root>/Switch2' incorporates:
   *  Logic: '<Root>/NOT1'
   *  Outport: '<Root>/Error'
   */
  if (!(controller_Y.Error != 0.0F)) {
    /* Outport: '<Root>/AutomaticTransmissionState' incorporates:
     *  DataTypeConversion: '<Root>/Data Type Conversion'
     */
    controller_Y.AutomaticTransmissionState = (TransmissionState)
      rtb_AutomaticTransmissionState;
  } else {
    /* Outport: '<Root>/AutomaticTransmissionState' incorporates:
     *  DataTypeConversion: '<Root>/Data Type Conversion2'
     */
    controller_Y.AutomaticTransmissionState = (TransmissionState)
      controller_B.AutomaticTransmissionState;
  }

  /* End of Switch: '<Root>/Switch2' */
}

/* Model initialize function */
void controller_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void controller_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

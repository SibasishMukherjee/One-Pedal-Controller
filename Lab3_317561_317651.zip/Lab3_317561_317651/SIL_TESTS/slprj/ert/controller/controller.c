/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: controller.c
 *
 * Code generated for Simulink model 'controller'.
 *
 * Model version                  : 3.72
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Sat May 27 22:43:28 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "controller.h"
#include "rtwtypes.h"
#include "controller_types.h"
#include <math.h>
#include "controller_private.h"

/* Named constants for Chart: '<Root>/OnePedal_Controller' */
#define c_IN_EmergencyStop_ReverseState ((uint8_T)2U)
#define con_IN_EmergencyStop_BrakeState ((uint8_T)3U)
#define con_IN_EmergencyStop_DriveState ((uint8_T)2U)
#define controller_IN_Accelerating     ((uint8_T)1U)
#define controller_IN_Brake            ((uint8_T)1U)
#define controller_IN_Braking          ((uint8_T)2U)
#define controller_IN_Cruise           ((uint8_T)1U)
#define controller_IN_Drive            ((uint8_T)2U)
#define controller_IN_NO_ACTIVE_CHILD  ((uint8_T)0U)
#define controller_IN_Neutral          ((uint8_T)3U)
#define controller_IN_Parking          ((uint8_T)4U)
#define controller_IN_Reverse          ((uint8_T)5U)
#define controller_IN_Stopping         ((uint8_T)4U)

/* Named constants for Chart: '<Root>/OnePedal_Supervisor' */
#define IN_TransmissionStateErrorDetect ((uint8_T)5U)
#define c_IN_ThrottlePedalErrorDetected ((uint8_T)4U)
#define cont_IN_BrakePedalErrorDetected ((uint8_T)1U)
#define controller_IN_Error            ((uint8_T)2U)
#define controller_IN_NormalOperations ((uint8_T)3U)

/* Output and update for referenced model: 'controller' */
void controller(const boolean_T *rtu_BrakePedalPressed, const real32_T
                *rtu_ThrottlePedalPosition, const TransmissionState
                *rtu_AutomaticTransmissionSelect, const boolean_T
                *rtu_BrakePedalPressed_Backup, const real32_T
                *rtu_ThrottlePedalPosition_Backu, const real32_T
                *rtu_VehicleSpeed_km_h, real32_T *rty_TorqueRequest_Nm,
                TransmissionState *rty_AutomaticTransmissionState, real32_T
                *rty_Error, real32_T *rty_Error_TS, B_controller_c_T *localB,
                DW_controller_f_T *localDW)
{
  int32_T rtb_AutomaticTransmissionState;
  int32_T rtb_DataTypeConversion1;
  real32_T rtb_Saturation;

  /* Saturate: '<Root>/Saturation' */
  rtb_Saturation = *rtu_ThrottlePedalPosition;
  if (rtb_Saturation > 0.5F) {
    rtb_Saturation = 0.5F;
  } else if (rtb_Saturation < -0.5F) {
    rtb_Saturation = -0.5F;
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* DataTypeConversion: '<Root>/Data Type Conversion1' */
  rtb_DataTypeConversion1 = (int32_T)*rtu_AutomaticTransmissionSelect;

  /* Chart: '<Root>/OnePedal_Controller' */
  if (localDW->is_active_c3_controller == 0U) {
    localDW->is_active_c3_controller = 1U;
    localDW->is_c3_controller = controller_IN_Parking;
    rtb_AutomaticTransmissionState = 0;
  } else {
    switch (localDW->is_c3_controller) {
     case controller_IN_Brake:
      {
        rtb_AutomaticTransmissionState = 4;
        if (rtb_DataTypeConversion1 != 4) {
          localDW->is_Brake = controller_IN_NO_ACTIVE_CHILD;
          localDW->is_c3_controller = controller_IN_Drive;
          rtb_AutomaticTransmissionState = 3;
          localDW->is_Drive = controller_IN_Cruise;
        } else {
          switch (localDW->is_Brake) {
           case controller_IN_Accelerating:
            if (rtb_Saturation < 0.33333333333333331) {
              localDW->is_Brake = controller_IN_Braking;
              localB->StoppedControllerMode = 0.0F;
            } else if (*rtu_BrakePedalPressed) {
              localDW->is_Brake = con_IN_EmergencyStop_BrakeState;
            } else {
              localB->TorqueRequest_Nm_e = (rtb_Saturation - 0.333333343F) *
                120.0F;
            }
            break;

           case controller_IN_Braking:
            if (rtb_Saturation > 0.33333333333333331) {
              localDW->is_Brake = controller_IN_Accelerating;
              localB->StoppedControllerMode = 0.0F;
            } else if (fabsf(*rtu_VehicleSpeed_km_h) <= 1.0F) {
              localDW->is_Brake = controller_IN_Stopping;
              localB->StoppedControllerMode = 1.0F;
            } else if (*rtu_BrakePedalPressed) {
              localDW->is_Brake = con_IN_EmergencyStop_BrakeState;
            } else {
              localB->TorqueRequest_Nm_e = (1.0F - 3.0F * rtb_Saturation) *
                -80.0F;
            }
            break;

           case con_IN_EmergencyStop_BrakeState:
            {
              boolean_T i_out;
              i_out = !*rtu_BrakePedalPressed;
              if ((rtb_Saturation > 0.33333333333333331) && i_out) {
                localDW->is_Brake = controller_IN_Accelerating;
                localB->StoppedControllerMode = 0.0F;
              } else if ((rtb_Saturation <= 0.33333333333333331) && i_out) {
                localDW->is_Brake = controller_IN_Braking;
                localB->StoppedControllerMode = 0.0F;
              } else {
                localB->StoppedControllerMode = 1.0F;
                localB->TargetSpeed_km_h = 0.0;
              }
            }
            break;

           default:
            /* case IN_Stopping: */
            if (rtb_Saturation > 0.33333333333333331) {
              localDW->is_Brake = controller_IN_Accelerating;
              localB->StoppedControllerMode = 0.0F;
            } else {
              localB->TargetSpeed_km_h = 0.0;
            }
            break;
          }
        }
      }
      break;

     case controller_IN_Drive:
      {
        rtb_AutomaticTransmissionState = 3;
        if ((rtb_DataTypeConversion1 == 4) && (rtb_Saturation >
             0.33333333333333331)) {
          localDW->is_Drive = controller_IN_NO_ACTIVE_CHILD;
          localDW->is_c3_controller = controller_IN_Brake;
          rtb_AutomaticTransmissionState = 4;
          localDW->is_Brake = controller_IN_Braking;
          localB->StoppedControllerMode = 0.0F;
        } else if (rtb_DataTypeConversion1 < 3) {
          localDW->is_Drive = controller_IN_NO_ACTIVE_CHILD;
          localDW->is_c3_controller = controller_IN_Neutral;
          rtb_AutomaticTransmissionState = 2;
        } else if (localDW->is_Drive == controller_IN_Cruise) {
          boolean_T i_out;
          i_out = ((*rtu_BrakePedalPressed) && (rtb_Saturation == 0.0F));
          if (i_out) {
            localDW->is_Drive = con_IN_EmergencyStop_DriveState;
          } else {
            localB->TorqueRequest_Nm_e = 80.0F * rtb_Saturation;
          }
        } else {
          boolean_T i_out;

          /* case IN_EmergencyStop_DriveState: */
          i_out = ((rtb_Saturation > 0.0F) && (!*rtu_BrakePedalPressed));
          if (i_out) {
            localDW->is_Drive = controller_IN_Cruise;
          } else {
            localB->StoppedControllerMode = 1.0F;
            localB->TargetSpeed_km_h = 0.0;
          }
        }
      }
      break;

     case controller_IN_Neutral:
      {
        boolean_T i_out;
        rtb_AutomaticTransmissionState = 2;
        i_out = ((fabsf(*rtu_VehicleSpeed_km_h) < 5.0F) &&
                 ((*rtu_BrakePedalPressed) && (rtb_DataTypeConversion1 == 0)));
        if (i_out) {
          localDW->is_c3_controller = controller_IN_Parking;
          rtb_AutomaticTransmissionState = 0;
        } else {
          i_out = ((*rtu_VehicleSpeed_km_h < 5.0F) && (*rtu_BrakePedalPressed) &&
                   (rtb_DataTypeConversion1 == 1));
          if (i_out) {
            localDW->is_c3_controller = controller_IN_Reverse;
            rtb_AutomaticTransmissionState = 1;
            localDW->is_Reverse = controller_IN_Cruise;
          } else {
            i_out = ((*rtu_VehicleSpeed_km_h > -5.0F) && (*rtu_BrakePedalPressed)
                     && (rtb_DataTypeConversion1 > 2));
            if (i_out) {
              localDW->is_c3_controller = controller_IN_Drive;
              rtb_AutomaticTransmissionState = 3;
              localDW->is_Drive = controller_IN_Cruise;
            } else {
              localB->TorqueRequest_Nm_e = 0.0F;
            }
          }
        }
      }
      break;

     case controller_IN_Parking:
      {
        boolean_T i_out;
        rtb_AutomaticTransmissionState = 0;
        i_out = ((*rtu_BrakePedalPressed) && (rtb_DataTypeConversion1 != 0));
        if (i_out) {
          localDW->is_c3_controller = controller_IN_Neutral;
          rtb_AutomaticTransmissionState = 2;
        } else {
          localB->TorqueRequest_Nm_e = 0.0F;
        }
      }
      break;

     default:
      {
        /* case IN_Reverse: */
        rtb_AutomaticTransmissionState = 1;
        if (rtb_DataTypeConversion1 != 1) {
          localDW->is_Reverse = controller_IN_NO_ACTIVE_CHILD;
          localDW->is_c3_controller = controller_IN_Neutral;
          rtb_AutomaticTransmissionState = 2;
        } else if (localDW->is_Reverse == controller_IN_Cruise) {
          boolean_T i_out;
          i_out = ((*rtu_BrakePedalPressed) && (rtb_Saturation == 0.0F));
          if (i_out) {
            localDW->is_Reverse = c_IN_EmergencyStop_ReverseState;
          } else {
            localB->StoppedControllerMode = 0.0F;
            localB->TorqueRequest_Nm_e = -rtb_Saturation * 40.0F;
          }
        } else {
          boolean_T i_out;

          /* case IN_EmergencyStop_ReverseState: */
          i_out = ((!*rtu_BrakePedalPressed) && (rtb_Saturation > 0.0F));
          if (i_out) {
            localDW->is_Reverse = controller_IN_Cruise;
          } else {
            localB->StoppedControllerMode = 1.0F;
            localB->TargetSpeed_km_h = 0.0;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<Root>/OnePedal_Controller' */

  /* Chart: '<Root>/OnePedal_Supervisor' */
  if (localDW->temporalCounter_i1 < 511U) {
    localDW->temporalCounter_i1++;
  }

  if (localDW->is_active_c1_controller == 0U) {
    localDW->is_active_c1_controller = 1U;
    localDW->is_c1_controller = controller_IN_NormalOperations;
  } else {
    switch (localDW->is_c1_controller) {
     case cont_IN_BrakePedalErrorDetected:
      if (localDW->temporalCounter_i1 >= 100U) {
        localDW->is_c1_controller = controller_IN_Error;
      } else if (*rtu_BrakePedalPressed_Backup == *rtu_BrakePedalPressed) {
        localDW->is_c1_controller = controller_IN_NormalOperations;
      }
      break;

     case controller_IN_Error:
      *rty_Error = 1.0F;
      localB->AutomaticTransmissionState = 2;
      localB->TorqueRequest_Nm = 0.0F;
      break;

     case controller_IN_NormalOperations:
      if (*rtu_ThrottlePedalPosition_Backu != rtb_Saturation) {
        localDW->is_c1_controller = c_IN_ThrottlePedalErrorDetected;
        localDW->temporalCounter_i1 = 0U;
      } else if (*rtu_BrakePedalPressed_Backup != *rtu_BrakePedalPressed) {
        localDW->is_c1_controller = cont_IN_BrakePedalErrorDetected;
        localDW->temporalCounter_i1 = 0U;
      } else if (rtb_DataTypeConversion1 != rtb_AutomaticTransmissionState) {
        localDW->is_c1_controller = IN_TransmissionStateErrorDetect;
        localDW->temporalCounter_i1 = 0U;
      } else {
        *rty_Error = 0.0F;
        *rty_Error_TS = 0.0F;
      }
      break;

     case c_IN_ThrottlePedalErrorDetected:
      if (localDW->temporalCounter_i1 >= 100U) {
        localDW->is_c1_controller = controller_IN_Error;
      } else if (*rtu_ThrottlePedalPosition_Backu == rtb_Saturation) {
        localDW->is_c1_controller = controller_IN_NormalOperations;
      }
      break;

     default:
      /* case IN_TransmissionStateErrorDetected: */
      if (rtb_DataTypeConversion1 == rtb_AutomaticTransmissionState) {
        localDW->is_c1_controller = controller_IN_NormalOperations;
      } else {
        *rty_Error_TS = 1.0F;
        localB->TorqueRequest_Nm = 0.0F;
      }
      break;
    }
  }

  /* End of Chart: '<Root>/OnePedal_Supervisor' */

  /* Switch: '<Root>/Switch1' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion3'
   *  Logic: '<Root>/NOT2'
   *  Sum: '<Root>/Add'
   */
  if (!(*rty_Error + *rty_Error_TS != 0.0F)) {
    real_T rtb_Sum;

    /* Switch: '<Root>/Switch' incorporates:
     *  Gain: '<Root>/Gain'
     *  Logic: '<Root>/NOT'
     */
    if (!(localB->StoppedControllerMode != 0.0F)) {
      rtb_Sum = localB->TorqueRequest_Nm_e;
    } else {
      /* Sum: '<Root>/Sum' */
      rtb_Sum = localB->TargetSpeed_km_h - *rtu_VehicleSpeed_km_h;
      rtb_Sum *= 30.0;
    }

    /* End of Switch: '<Root>/Switch' */

    /* Saturate: '<Root>/Saturation1' */
    if (rtb_Sum > 80.0) {
      *rty_TorqueRequest_Nm = 80.0F;
    } else if (rtb_Sum < -80.0) {
      *rty_TorqueRequest_Nm = -80.0F;
    } else {
      *rty_TorqueRequest_Nm = (real32_T)rtb_Sum;
    }

    /* End of Saturate: '<Root>/Saturation1' */
  } else {
    *rty_TorqueRequest_Nm = localB->TorqueRequest_Nm;
  }

  /* End of Switch: '<Root>/Switch1' */

  /* Switch: '<Root>/Switch2' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  DataTypeConversion: '<Root>/Data Type Conversion2'
   *  Logic: '<Root>/NOT1'
   */
  if (!(*rty_Error != 0.0F)) {
    *rty_AutomaticTransmissionState = (TransmissionState)
      rtb_AutomaticTransmissionState;
  } else {
    *rty_AutomaticTransmissionState = (TransmissionState)
      localB->AutomaticTransmissionState;
  }

  /* End of Switch: '<Root>/Switch2' */
}

/* Model initialize function */
void controller_initialize(const char_T **rt_errorStatus, RT_MODEL_controller_T *
  const controller_M)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatusPointer(controller_M, rt_errorStatus);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

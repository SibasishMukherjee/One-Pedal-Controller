#ifndef __MW_INTERNAL_SLDV_PS_ANALYSIS__
#ifdef __cplusplus
extern "C"
#else
extern
#endif
unsigned int* __mw_instrum_controller_phits;

#define __MW_INSTRUM_RECORD_HIT_NO_TEST(id) ((void)((++__mw_instrum_controller_phits[id - 1u]) || ((__mw_instrum_controller_phits[id - 1u] = (~0u))!=0)))
#define __MW_INSTRUM_RECORD_HIT(id) (__mw_instrum_controller_phits ? __MW_INSTRUM_RECORD_HIT_NO_TEST(id) : (void) 0)

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_45() \
  __MW_INSTRUM_RECORD_HIT(298U + __mw_instrum_controller_curr_combination_idx_45)

#define __MW_INSTRUM_NODE_47(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(47U), (__mw_instrum_controller_curr_combination_idx_45 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(48U), (__mw_instrum_controller_curr_combination_idx_45 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_51(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(51U), (__mw_instrum_controller_curr_combination_idx_45 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(52U), (0 == 1)))
#define __MW_INSTRUM_NODE_45(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(45U), __MW_INSTRUM_RECORD_COMBINATION_HIT_45(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(46U), __MW_INSTRUM_RECORD_COMBINATION_HIT_45(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_53() \
  __MW_INSTRUM_RECORD_HIT(301U + __mw_instrum_controller_curr_combination_idx_53)

#define __MW_INSTRUM_NODE_55(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(55U), (__mw_instrum_controller_curr_combination_idx_53 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(56U), (__mw_instrum_controller_curr_combination_idx_53 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_59(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(59U), (__mw_instrum_controller_curr_combination_idx_53 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(60U), (0 == 1)))
#define __MW_INSTRUM_NODE_53(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(53U), __MW_INSTRUM_RECORD_COMBINATION_HIT_53(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(54U), __MW_INSTRUM_RECORD_COMBINATION_HIT_53(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_67() \
  __MW_INSTRUM_RECORD_HIT(304U + __mw_instrum_controller_curr_combination_idx_67)

#define __MW_INSTRUM_NODE_69(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(69U), (__mw_instrum_controller_curr_combination_idx_67 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(70U), (__mw_instrum_controller_curr_combination_idx_67 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_74(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(74U), (__mw_instrum_controller_curr_combination_idx_67 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(75U), (0 == 1)))
#define __MW_INSTRUM_NODE_67(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(67U), __MW_INSTRUM_RECORD_COMBINATION_HIT_67(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(68U), __MW_INSTRUM_RECORD_COMBINATION_HIT_67(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_88() \
  __MW_INSTRUM_RECORD_HIT(307U + __mw_instrum_controller_curr_combination_idx_88)

#define __MW_INSTRUM_NODE_90(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(90U), (__mw_instrum_controller_curr_combination_idx_88 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(91U), (__mw_instrum_controller_curr_combination_idx_88 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_92(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(92U), (__mw_instrum_controller_curr_combination_idx_88 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(93U), (0 == 1)))
#define __MW_INSTRUM_NODE_88(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(88U), __MW_INSTRUM_RECORD_COMBINATION_HIT_88(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(89U), __MW_INSTRUM_RECORD_COMBINATION_HIT_88(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_98() \
  __MW_INSTRUM_RECORD_HIT(310U + __mw_instrum_controller_curr_combination_idx_98)

#define __MW_INSTRUM_NODE_100(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(100U), (__mw_instrum_controller_curr_combination_idx_98 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(101U), (__mw_instrum_controller_curr_combination_idx_98 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_106(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(106U), (__mw_instrum_controller_curr_combination_idx_98 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(107U), (0 == 1)))
#define __MW_INSTRUM_NODE_98(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(98U), __MW_INSTRUM_RECORD_COMBINATION_HIT_98(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(99U), __MW_INSTRUM_RECORD_COMBINATION_HIT_98(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_111() \
  __MW_INSTRUM_RECORD_HIT(313U + __mw_instrum_controller_curr_combination_idx_111)

#define __MW_INSTRUM_NODE_113(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(113U), (__mw_instrum_controller_curr_combination_idx_111 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(114U), (__mw_instrum_controller_curr_combination_idx_111 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_120(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(120U), (__mw_instrum_controller_curr_combination_idx_111 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(121U), (0 == 1)))
#define __MW_INSTRUM_NODE_122(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(122U), (__mw_instrum_controller_curr_combination_idx_111 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(123U), (0 == 1)))
#define __MW_INSTRUM_NODE_111(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(111U), __MW_INSTRUM_RECORD_COMBINATION_HIT_111(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(112U), __MW_INSTRUM_RECORD_COMBINATION_HIT_111(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_129() \
  __MW_INSTRUM_RECORD_HIT(317U + __mw_instrum_controller_curr_combination_idx_129)

#define __MW_INSTRUM_NODE_133(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(133U), (__mw_instrum_controller_curr_combination_idx_129 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(134U), (__mw_instrum_controller_curr_combination_idx_129 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_137(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(137U), (__mw_instrum_controller_curr_combination_idx_129 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(138U), (0 == 1)))
#define __MW_INSTRUM_NODE_139(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(139U), (__mw_instrum_controller_curr_combination_idx_129 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(140U), (0 == 1)))
#define __MW_INSTRUM_NODE_129(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(129U), __MW_INSTRUM_RECORD_COMBINATION_HIT_129(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(130U), __MW_INSTRUM_RECORD_COMBINATION_HIT_129(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_146() \
  __MW_INSTRUM_RECORD_HIT(321U + __mw_instrum_controller_curr_combination_idx_146)

#define __MW_INSTRUM_NODE_150(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(150U), (__mw_instrum_controller_curr_combination_idx_146 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(151U), (__mw_instrum_controller_curr_combination_idx_146 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_154(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(154U), (__mw_instrum_controller_curr_combination_idx_146 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(155U), (0 == 1)))
#define __MW_INSTRUM_NODE_156(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(156U), (__mw_instrum_controller_curr_combination_idx_146 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(157U), (0 == 1)))
#define __MW_INSTRUM_NODE_146(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(146U), __MW_INSTRUM_RECORD_COMBINATION_HIT_146(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(147U), __MW_INSTRUM_RECORD_COMBINATION_HIT_146(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_164() \
  __MW_INSTRUM_RECORD_HIT(325U + __mw_instrum_controller_curr_combination_idx_164)

#define __MW_INSTRUM_NODE_166(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(166U), (__mw_instrum_controller_curr_combination_idx_164 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(167U), (__mw_instrum_controller_curr_combination_idx_164 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_168(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(168U), (__mw_instrum_controller_curr_combination_idx_164 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(169U), (0 == 1)))
#define __MW_INSTRUM_NODE_164(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(164U), __MW_INSTRUM_RECORD_COMBINATION_HIT_164(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(165U), __MW_INSTRUM_RECORD_COMBINATION_HIT_164(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_186() \
  __MW_INSTRUM_RECORD_HIT(328U + __mw_instrum_controller_curr_combination_idx_186)

#define __MW_INSTRUM_NODE_188(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(188U), (__mw_instrum_controller_curr_combination_idx_186 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(189U), (__mw_instrum_controller_curr_combination_idx_186 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_190(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(190U), (__mw_instrum_controller_curr_combination_idx_186 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(191U), (0 == 1)))
#define __MW_INSTRUM_NODE_186(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(186U), __MW_INSTRUM_RECORD_COMBINATION_HIT_186(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(187U), __MW_INSTRUM_RECORD_COMBINATION_HIT_186(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_196() \
  __MW_INSTRUM_RECORD_HIT(331U + __mw_instrum_controller_curr_combination_idx_196)

#define __MW_INSTRUM_NODE_200(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(200U), (__mw_instrum_controller_curr_combination_idx_196 = 2U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(201U), (__mw_instrum_controller_curr_combination_idx_196 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_202(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(202U), (__mw_instrum_controller_curr_combination_idx_196 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(203U), (0 == 1)))
#define __MW_INSTRUM_NODE_196(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(196U), __MW_INSTRUM_RECORD_COMBINATION_HIT_196(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(197U), __MW_INSTRUM_RECORD_COMBINATION_HIT_196(), (0 == 1)))


#define __MW_INSTRUM_FCN_ENTER_1() \
  unsigned int __mw_instrum_controller_curr_combination_idx_45 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_53 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_67 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_88 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_98 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_111 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_129 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_146 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_164 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_186 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_196 = 0U; 
#define __MW_INSTRUM_FCN_ENTER_2() 

#define __MW_INSTRUM_NODE_1() (__MW_INSTRUM_RECORD_HIT(1U))
#define __MW_INSTRUM_NODE_2(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(2U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(3U), (0 == 1)))
#define __MW_INSTRUM_NODE_4(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_3() (__MW_INSTRUM_RECORD_HIT(3U))
#define __MW_INSTRUM_NODE_6(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(6U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(7U), (0 == 1)))
#define __MW_INSTRUM_NODE_8(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_10(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(10U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(11U), (0 == 1)))
#define __MW_INSTRUM_NODE_12(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_11() (__MW_INSTRUM_RECORD_HIT(11U))
#define __MW_INSTRUM_NODE_15() (__MW_INSTRUM_RECORD_HIT(15U))
#define __MW_INSTRUM_NODE_16(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(16U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(17U), (0 == 1)))
#define __MW_INSTRUM_NODE_18(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_17() (__MW_INSTRUM_RECORD_HIT(17U))
#define __MW_INSTRUM_NODE_21() (__MW_INSTRUM_RECORD_HIT(21U))
#define __MW_INSTRUM_NODE_22(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(22U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(23U), (0 == 1)))
#define __MW_INSTRUM_NODE_24(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_23() (__MW_INSTRUM_RECORD_HIT(23U))
#define __MW_INSTRUM_NODE_26(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(26U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(27U), (0 == 1)))
#define __MW_INSTRUM_NODE_27() (__MW_INSTRUM_RECORD_HIT(27U))
#define __MW_INSTRUM_NODE_28() (__MW_INSTRUM_RECORD_HIT(28U))
#define __MW_INSTRUM_NODE_29(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(29U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(30U), (0 == 1)))
#define __MW_INSTRUM_NODE_31(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_30() (__MW_INSTRUM_RECORD_HIT(30U))
#define __MW_INSTRUM_NODE_33(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(33U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(34U), (0 == 1)))
#define __MW_INSTRUM_NODE_35(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_37() (__MW_INSTRUM_RECORD_HIT(37U))
#define __MW_INSTRUM_NODE_34() (__MW_INSTRUM_RECORD_HIT(34U))
#define __MW_INSTRUM_NODE_38(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(38U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(39U), (0 == 1)))
#define __MW_INSTRUM_NODE_39() (__MW_INSTRUM_RECORD_HIT(39U))
#define __MW_INSTRUM_NODE_40() (__MW_INSTRUM_RECORD_HIT(40U))
#define __MW_INSTRUM_NODE_41(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(41U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(42U), (0 == 1)))
#define __MW_INSTRUM_NODE_43(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(43U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(44U), (0 == 1)))
#define __MW_INSTRUM_NODE_49(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_46() (__MW_INSTRUM_RECORD_HIT(46U))
#define __MW_INSTRUM_NODE_57(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_54() (__MW_INSTRUM_RECORD_HIT(54U))
#define __MW_INSTRUM_NODE_61() (__MW_INSTRUM_RECORD_HIT(61U))
#define __MW_INSTRUM_NODE_62(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(62U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(63U), (0 == 1)))
#define __MW_INSTRUM_NODE_64(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_63() (__MW_INSTRUM_RECORD_HIT(63U))
#define __MW_INSTRUM_NODE_66() (__MW_INSTRUM_RECORD_HIT(66U))
#define __MW_INSTRUM_NODE_71(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_76(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_68() (__MW_INSTRUM_RECORD_HIT(68U))
#define __MW_INSTRUM_NODE_78(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(78U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(79U), (0 == 1)))
#define __MW_INSTRUM_NODE_80(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_79() (__MW_INSTRUM_RECORD_HIT(79U))
#define __MW_INSTRUM_NODE_83(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(83U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(84U), (0 == 1)))
#define __MW_INSTRUM_NODE_85(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_94(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_96(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(96U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(97U), (0 == 1)))
#define __MW_INSTRUM_NODE_97() (__MW_INSTRUM_RECORD_HIT(97U))
#define __MW_INSTRUM_NODE_84() (__MW_INSTRUM_RECORD_HIT(84U))
#define __MW_INSTRUM_NODE_102(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_104(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(104U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(105U), (0 == 1)))
#define __MW_INSTRUM_NODE_108(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(108U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(109U), (0 == 1)))
#define __MW_INSTRUM_NODE_109() (__MW_INSTRUM_RECORD_HIT(109U))
#define __MW_INSTRUM_NODE_110() (__MW_INSTRUM_RECORD_HIT(110U))
#define __MW_INSTRUM_NODE_115(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_117() (__MW_INSTRUM_RECORD_HIT(117U))
#define __MW_INSTRUM_NODE_118(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(118U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(119U), (0 == 1)))
#define __MW_INSTRUM_NODE_124(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_127(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(127U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(128U), (0 == 1)))
#define __MW_INSTRUM_NODE_128() (__MW_INSTRUM_RECORD_HIT(128U))
#define __MW_INSTRUM_NODE_131(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(131U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(132U), (0 == 1)))
#define __MW_INSTRUM_NODE_135(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_141(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_144(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(144U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(145U), (0 == 1)))
#define __MW_INSTRUM_NODE_145() (__MW_INSTRUM_RECORD_HIT(145U))
#define __MW_INSTRUM_NODE_148(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(148U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(149U), (0 == 1)))
#define __MW_INSTRUM_NODE_152(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_158(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_161(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(161U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(162U), (0 == 1)))
#define __MW_INSTRUM_NODE_162() (__MW_INSTRUM_RECORD_HIT(162U))
#define __MW_INSTRUM_NODE_163() (__MW_INSTRUM_RECORD_HIT(163U))
#define __MW_INSTRUM_NODE_170(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_173(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(173U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(174U), (0 == 1)))
#define __MW_INSTRUM_NODE_174() (__MW_INSTRUM_RECORD_HIT(174U))
#define __MW_INSTRUM_NODE_175() (__MW_INSTRUM_RECORD_HIT(175U))
#define __MW_INSTRUM_NODE_176(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(176U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(177U), (0 == 1)))
#define __MW_INSTRUM_NODE_178(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_177() (__MW_INSTRUM_RECORD_HIT(177U))
#define __MW_INSTRUM_NODE_181(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(181U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(182U), (0 == 1)))
#define __MW_INSTRUM_NODE_183(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_192(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_194(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(194U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(195U), (0 == 1)))
#define __MW_INSTRUM_NODE_195() (__MW_INSTRUM_RECORD_HIT(195U))
#define __MW_INSTRUM_NODE_182() (__MW_INSTRUM_RECORD_HIT(182U))
#define __MW_INSTRUM_NODE_198(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(198U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(199U), (0 == 1)))
#define __MW_INSTRUM_NODE_204(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_206(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(206U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(207U), (0 == 1)))
#define __MW_INSTRUM_NODE_207() (__MW_INSTRUM_RECORD_HIT(207U))
#define __MW_INSTRUM_NODE_208(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(208U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(209U), (0 == 1)))
#define __MW_INSTRUM_NODE_210(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_213(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(213U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(214U), (0 == 1)))
#define __MW_INSTRUM_NODE_215(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_214() (__MW_INSTRUM_RECORD_HIT(214U))
#define __MW_INSTRUM_NODE_218() (__MW_INSTRUM_RECORD_HIT(218U))
#define __MW_INSTRUM_NODE_219(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(219U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(220U), (0 == 1)))
#define __MW_INSTRUM_NODE_221(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_220() (__MW_INSTRUM_RECORD_HIT(220U))
#define __MW_INSTRUM_NODE_224(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(224U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(225U), (0 == 1)))
#define __MW_INSTRUM_NODE_226(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_229(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(229U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(230U), (0 == 1)))
#define __MW_INSTRUM_NODE_231(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(231U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(232U), (0 == 1)))
#define __MW_INSTRUM_NODE_233() (__MW_INSTRUM_RECORD_HIT(233U))
#define __MW_INSTRUM_NODE_234() (__MW_INSTRUM_RECORD_HIT(234U))
#define __MW_INSTRUM_NODE_235(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(235U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(236U), (0 == 1)))
#define __MW_INSTRUM_NODE_237(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_236() (__MW_INSTRUM_RECORD_HIT(236U))
#define __MW_INSTRUM_NODE_239(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(239U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(240U), (0 == 1)))
#define __MW_INSTRUM_NODE_241(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_244(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(244U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(245U), (0 == 1)))
#define __MW_INSTRUM_NODE_246(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(246U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(247U), (0 == 1)))
#define __MW_INSTRUM_NODE_240() (__MW_INSTRUM_RECORD_HIT(240U))
#define __MW_INSTRUM_NODE_248(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(248U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(249U), (0 == 1)))
#define __MW_INSTRUM_NODE_250(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_249() (__MW_INSTRUM_RECORD_HIT(249U))
#define __MW_INSTRUM_NODE_253() (__MW_INSTRUM_RECORD_HIT(253U))
#define __MW_INSTRUM_NODE_254(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(254U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(255U), (0 == 1)))
#define __MW_INSTRUM_NODE_256(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_255() (__MW_INSTRUM_RECORD_HIT(255U))
#define __MW_INSTRUM_NODE_259(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(259U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(260U), (0 == 1)))
#define __MW_INSTRUM_NODE_261(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_263() (__MW_INSTRUM_RECORD_HIT(263U))
#define __MW_INSTRUM_NODE_264(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(264U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(265U), (0 == 1)))
#define __MW_INSTRUM_NODE_266(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_265() (__MW_INSTRUM_RECORD_HIT(265U))
#define __MW_INSTRUM_NODE_269(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(269U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(270U), (0 == 1)))
#define __MW_INSTRUM_NODE_271(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(271U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(272U), (0 == 1)))
#define __MW_INSTRUM_NODE_273(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_275(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(275U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(276U), (0 == 1)))
#define __MW_INSTRUM_NODE_277(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(277U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(278U), (0 == 1)))
#define __MW_INSTRUM_NODE_279(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_276() (__MW_INSTRUM_RECORD_HIT(276U))
#define __MW_INSTRUM_NODE_281(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(281U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(282U), (0 == 1)))
#define __MW_INSTRUM_NODE_283(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_282() (__MW_INSTRUM_RECORD_HIT(282U))
#define __MW_INSTRUM_NODE_285(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(285U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(286U), (0 == 1)))
#define __MW_INSTRUM_NODE_287(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_286() (__MW_INSTRUM_RECORD_HIT(286U))
#define __MW_INSTRUM_NODE_270() (__MW_INSTRUM_RECORD_HIT(270U))
#define __MW_INSTRUM_NODE_289(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(289U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(290U), (0 == 1)))
#define __MW_INSTRUM_NODE_291(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(291U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(292U), (0 == 1)))
#define __MW_INSTRUM_NODE_293(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_290() (__MW_INSTRUM_RECORD_HIT(290U))
#define __MW_INSTRUM_NODE_295() (__MW_INSTRUM_RECORD_HIT(295U))
#define __MW_INSTRUM_NODE_296() (__MW_INSTRUM_RECORD_HIT(296U))
#define __MW_INSTRUM_NODE_297() (__MW_INSTRUM_RECORD_HIT(297U))
#else /* __MW_INTERNAL_SLDV_PS_ANALYSIS__ */
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_47CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_47(...) (__MW_INSTRUM_RECORD_HIT_47CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_47(exp) (__MW_INSTRUM_RECORD_HIT_47CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_51CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_51(...) (__MW_INSTRUM_RECORD_HIT_51CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_51(exp) (__MW_INSTRUM_RECORD_HIT_51CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_45DA_47_51Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_45(...) (__MW_INSTRUM_RECORD_HIT_45DA_47_51Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_45(exp) (__MW_INSTRUM_RECORD_HIT_45DA_47_51Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_55CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_55(...) (__MW_INSTRUM_RECORD_HIT_55CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_55(exp) (__MW_INSTRUM_RECORD_HIT_55CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_59CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_59(...) (__MW_INSTRUM_RECORD_HIT_59CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_59(exp) (__MW_INSTRUM_RECORD_HIT_59CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_53DA_55_59Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_53(...) (__MW_INSTRUM_RECORD_HIT_53DA_55_59Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_53(exp) (__MW_INSTRUM_RECORD_HIT_53DA_55_59Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_69CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_69(...) (__MW_INSTRUM_RECORD_HIT_69CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_69(exp) (__MW_INSTRUM_RECORD_HIT_69CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_74CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_74(...) (__MW_INSTRUM_RECORD_HIT_74CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_74(exp) (__MW_INSTRUM_RECORD_HIT_74CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_67DA_69_74Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_67(...) (__MW_INSTRUM_RECORD_HIT_67DA_69_74Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_67(exp) (__MW_INSTRUM_RECORD_HIT_67DA_69_74Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_90CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_90(...) (__MW_INSTRUM_RECORD_HIT_90CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_90(exp) (__MW_INSTRUM_RECORD_HIT_90CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_92CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_92(...) (__MW_INSTRUM_RECORD_HIT_92CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_92(exp) (__MW_INSTRUM_RECORD_HIT_92CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_88DA_90_92Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_88(...) (__MW_INSTRUM_RECORD_HIT_88DA_90_92Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_88(exp) (__MW_INSTRUM_RECORD_HIT_88DA_90_92Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_100CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_100(...) (__MW_INSTRUM_RECORD_HIT_100CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_100(exp) (__MW_INSTRUM_RECORD_HIT_100CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_106CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_106(...) (__MW_INSTRUM_RECORD_HIT_106CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_106(exp) (__MW_INSTRUM_RECORD_HIT_106CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_98DA_100N_106Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_98(...) (__MW_INSTRUM_RECORD_HIT_98DA_100N_106Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_98(exp) (__MW_INSTRUM_RECORD_HIT_98DA_100N_106Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_113CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_113(...) (__MW_INSTRUM_RECORD_HIT_113CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_113(exp) (__MW_INSTRUM_RECORD_HIT_113CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_120CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_120(...) (__MW_INSTRUM_RECORD_HIT_120CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_120(exp) (__MW_INSTRUM_RECORD_HIT_120CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_122CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_122(...) (__MW_INSTRUM_RECORD_HIT_122CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_122(exp) (__MW_INSTRUM_RECORD_HIT_122CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_111DA_113A_120_122Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_111(...) (__MW_INSTRUM_RECORD_HIT_111DA_113A_120_122Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_111(exp) (__MW_INSTRUM_RECORD_HIT_111DA_113A_120_122Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_133CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_133(...) (__MW_INSTRUM_RECORD_HIT_133CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_133(exp) (__MW_INSTRUM_RECORD_HIT_133CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_137CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_137(...) (__MW_INSTRUM_RECORD_HIT_137CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_137(exp) (__MW_INSTRUM_RECORD_HIT_137CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_139CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_139(...) (__MW_INSTRUM_RECORD_HIT_139CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_139(exp) (__MW_INSTRUM_RECORD_HIT_139CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_129DAA_133_137_139Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_129(...) (__MW_INSTRUM_RECORD_HIT_129DAA_133_137_139Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_129(exp) (__MW_INSTRUM_RECORD_HIT_129DAA_133_137_139Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_150CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_150(...) (__MW_INSTRUM_RECORD_HIT_150CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_150(exp) (__MW_INSTRUM_RECORD_HIT_150CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_154CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_154(...) (__MW_INSTRUM_RECORD_HIT_154CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_154(exp) (__MW_INSTRUM_RECORD_HIT_154CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_156CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_156(...) (__MW_INSTRUM_RECORD_HIT_156CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_156(exp) (__MW_INSTRUM_RECORD_HIT_156CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_146DAA_150_154_156Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_146(...) (__MW_INSTRUM_RECORD_HIT_146DAA_150_154_156Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_146(exp) (__MW_INSTRUM_RECORD_HIT_146DAA_150_154_156Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_166CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_166(...) (__MW_INSTRUM_RECORD_HIT_166CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_166(exp) (__MW_INSTRUM_RECORD_HIT_166CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_168CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_168(...) (__MW_INSTRUM_RECORD_HIT_168CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_168(exp) (__MW_INSTRUM_RECORD_HIT_168CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_164DA_166_168Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_164(...) (__MW_INSTRUM_RECORD_HIT_164DA_166_168Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_164(exp) (__MW_INSTRUM_RECORD_HIT_164DA_166_168Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_188CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_188(...) (__MW_INSTRUM_RECORD_HIT_188CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_188(exp) (__MW_INSTRUM_RECORD_HIT_188CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_190CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_190(...) (__MW_INSTRUM_RECORD_HIT_190CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_190(exp) (__MW_INSTRUM_RECORD_HIT_190CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_186DA_188_190Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_186(...) (__MW_INSTRUM_RECORD_HIT_186DA_188_190Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_186(exp) (__MW_INSTRUM_RECORD_HIT_186DA_188_190Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_200CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_200(...) (__MW_INSTRUM_RECORD_HIT_200CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_200(exp) (__MW_INSTRUM_RECORD_HIT_200CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_202CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_202(...) (__MW_INSTRUM_RECORD_HIT_202CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_202(exp) (__MW_INSTRUM_RECORD_HIT_202CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_196DAN_200_202Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_196(...) (__MW_INSTRUM_RECORD_HIT_196DAN_200_202Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_196(exp) (__MW_INSTRUM_RECORD_HIT_196DAN_200_202Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif


#define __MW_INSTRUM_FCN_ENTER_1() 

#define __MW_INSTRUM_FCN_ENTER_2() 

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_1EZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_1() __MW_INSTRUM_RECORD_HIT_1EZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_2DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_2(...) (__MW_INSTRUM_RECORD_HIT_2DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_2(exp) (__MW_INSTRUM_RECORD_HIT_2DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_4FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_4(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_4FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_3() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_6DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_6(...) (__MW_INSTRUM_RECORD_HIT_6DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_6(exp) (__MW_INSTRUM_RECORD_HIT_6DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_8FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_8(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_8FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_10DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_10(...) (__MW_INSTRUM_RECORD_HIT_10DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_10(exp) (__MW_INSTRUM_RECORD_HIT_10DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_12IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_12(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_11() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_15DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_15() __MW_INSTRUM_RECORD_HIT_15DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_16DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_16(...) (__MW_INSTRUM_RECORD_HIT_16DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_16(exp) (__MW_INSTRUM_RECORD_HIT_16DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_18IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_18(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_17() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_21DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_21() __MW_INSTRUM_RECORD_HIT_21DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_22DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_22(...) (__MW_INSTRUM_RECORD_HIT_22DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_22(exp) (__MW_INSTRUM_RECORD_HIT_22DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_24FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_24(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_24FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_23() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_26DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_26(...) (__MW_INSTRUM_RECORD_HIT_26DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_26(exp) (__MW_INSTRUM_RECORD_HIT_26DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_27() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_28DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_28() __MW_INSTRUM_RECORD_HIT_28DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_29DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_29(...) (__MW_INSTRUM_RECORD_HIT_29DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_29(exp) (__MW_INSTRUM_RECORD_HIT_29DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_31FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_31(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_31FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_30() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_33DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_33(...) (__MW_INSTRUM_RECORD_HIT_33DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_33(exp) (__MW_INSTRUM_RECORD_HIT_33DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_35FLEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_35(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_35FLEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_37() ((void)0)


#define __MW_INSTRUM_NODE_34() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_38DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_38(...) (__MW_INSTRUM_RECORD_HIT_38DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_38(exp) (__MW_INSTRUM_RECORD_HIT_38DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_39() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_40DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_40() __MW_INSTRUM_RECORD_HIT_40DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_41CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_41(...) (__MW_INSTRUM_RECORD_HIT_41CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_41(exp) (__MW_INSTRUM_RECORD_HIT_41CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_43CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_43(...) (__MW_INSTRUM_RECORD_HIT_43CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_43(exp) (__MW_INSTRUM_RECORD_HIT_43CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_49FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_49(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_49FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_46() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_57FLEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_57(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_57FLEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_54() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_61DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_61() __MW_INSTRUM_RECORD_HIT_61DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_62DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_62(...) (__MW_INSTRUM_RECORD_HIT_62DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_62(exp) (__MW_INSTRUM_RECORD_HIT_62DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_64FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_64(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_64FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_63() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_66DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_66() __MW_INSTRUM_RECORD_HIT_66DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_71IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_71(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_76FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_76(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_76FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_68() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_78DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_78(...) (__MW_INSTRUM_RECORD_HIT_78DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_78(exp) (__MW_INSTRUM_RECORD_HIT_78DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_80IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_80(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_79() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_83DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_83(...) (__MW_INSTRUM_RECORD_HIT_83DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_83(exp) (__MW_INSTRUM_RECORD_HIT_83DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_85IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_85(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_94FEQZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_94(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_94FEQZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_96DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_96(...) (__MW_INSTRUM_RECORD_HIT_96DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_96(exp) (__MW_INSTRUM_RECORD_HIT_96DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_97() ((void)0)


#define __MW_INSTRUM_NODE_84() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_102FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_102(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_102FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_104CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_104(...) (__MW_INSTRUM_RECORD_HIT_104CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_104(exp) (__MW_INSTRUM_RECORD_HIT_104CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_108DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_108(...) (__MW_INSTRUM_RECORD_HIT_108DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_108(exp) (__MW_INSTRUM_RECORD_HIT_108DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_109() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_110DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_110() __MW_INSTRUM_RECORD_HIT_110DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_115FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_115(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_115FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_117() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_118CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_118(...) (__MW_INSTRUM_RECORD_HIT_118CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_118(exp) (__MW_INSTRUM_RECORD_HIT_118CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_124IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_124(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_127DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_127(...) (__MW_INSTRUM_RECORD_HIT_127DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_127(exp) (__MW_INSTRUM_RECORD_HIT_127DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_128() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_131CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_131(...) (__MW_INSTRUM_RECORD_HIT_131CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_131(exp) (__MW_INSTRUM_RECORD_HIT_131CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_135FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_135(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_135FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_141IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_141(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_144DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_144(...) (__MW_INSTRUM_RECORD_HIT_144DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_144(exp) (__MW_INSTRUM_RECORD_HIT_144DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_145() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_148CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_148(...) (__MW_INSTRUM_RECORD_HIT_148CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_148(exp) (__MW_INSTRUM_RECORD_HIT_148CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_152FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_152(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_152FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_158IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_158(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_161DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_161(...) (__MW_INSTRUM_RECORD_HIT_161DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_161(exp) (__MW_INSTRUM_RECORD_HIT_161DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_162() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_163DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_163() __MW_INSTRUM_RECORD_HIT_163DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_170IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_170(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_173DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_173(...) (__MW_INSTRUM_RECORD_HIT_173DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_173(exp) (__MW_INSTRUM_RECORD_HIT_173DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_174() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_175DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_175() __MW_INSTRUM_RECORD_HIT_175DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_176DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_176(...) (__MW_INSTRUM_RECORD_HIT_176DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_176(exp) (__MW_INSTRUM_RECORD_HIT_176DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_178IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_178(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_177() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_181DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_181(...) (__MW_INSTRUM_RECORD_HIT_181DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_181(exp) (__MW_INSTRUM_RECORD_HIT_181DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_183IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_183(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_192FEQZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_192(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_192FEQZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_194DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_194(...) (__MW_INSTRUM_RECORD_HIT_194DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_194(exp) (__MW_INSTRUM_RECORD_HIT_194DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_195() ((void)0)


#define __MW_INSTRUM_NODE_182() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_198CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_198(...) (__MW_INSTRUM_RECORD_HIT_198CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_198(exp) (__MW_INSTRUM_RECORD_HIT_198CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_204FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_204(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_204FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_206DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_206(...) (__MW_INSTRUM_RECORD_HIT_206DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_206(exp) (__MW_INSTRUM_RECORD_HIT_206DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_207() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_208DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_208(...) (__MW_INSTRUM_RECORD_HIT_208DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_208(exp) (__MW_INSTRUM_RECORD_HIT_208DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_210IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_210(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_213DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_213(...) (__MW_INSTRUM_RECORD_HIT_213DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_213(exp) (__MW_INSTRUM_RECORD_HIT_213DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_215IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_215(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_214() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_218DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_218() __MW_INSTRUM_RECORD_HIT_218DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_219DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_219(...) (__MW_INSTRUM_RECORD_HIT_219DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_219(exp) (__MW_INSTRUM_RECORD_HIT_219DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_221IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_221(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_220() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_224DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_224(...) (__MW_INSTRUM_RECORD_HIT_224DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_224(exp) (__MW_INSTRUM_RECORD_HIT_224DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_226IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_226(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_229CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_229(...) (__MW_INSTRUM_RECORD_HIT_229CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_229(exp) (__MW_INSTRUM_RECORD_HIT_229CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_231CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_231(...) (__MW_INSTRUM_RECORD_HIT_231CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_231(exp) (__MW_INSTRUM_RECORD_HIT_231CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_233DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_233() __MW_INSTRUM_RECORD_HIT_233DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_234DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_234() __MW_INSTRUM_RECORD_HIT_234DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_235DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_235(...) (__MW_INSTRUM_RECORD_HIT_235DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_235(exp) (__MW_INSTRUM_RECORD_HIT_235DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_237FNEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_237(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_237FNEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_236() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_239DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_239(...) (__MW_INSTRUM_RECORD_HIT_239DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_239(exp) (__MW_INSTRUM_RECORD_HIT_239DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_241IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_241(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_244CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_244(...) (__MW_INSTRUM_RECORD_HIT_244CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_244(exp) (__MW_INSTRUM_RECORD_HIT_244CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_246CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_246(...) (__MW_INSTRUM_RECORD_HIT_246CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_246(exp) (__MW_INSTRUM_RECORD_HIT_246CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_240() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_248DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_248(...) (__MW_INSTRUM_RECORD_HIT_248DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_248(exp) (__MW_INSTRUM_RECORD_HIT_248DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_250IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_250(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_249() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_253DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_253() __MW_INSTRUM_RECORD_HIT_253DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_254DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_254(...) (__MW_INSTRUM_RECORD_HIT_254DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_254(exp) (__MW_INSTRUM_RECORD_HIT_254DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_256IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_256(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_255() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_259DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_259(...) (__MW_INSTRUM_RECORD_HIT_259DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_259(exp) (__MW_INSTRUM_RECORD_HIT_259DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_261FEQZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_261(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_261FEQZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_263DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_263() __MW_INSTRUM_RECORD_HIT_263DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_264DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_264(...) (__MW_INSTRUM_RECORD_HIT_264DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_264(exp) (__MW_INSTRUM_RECORD_HIT_264DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_266IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_266(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_265() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_269DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_269(...) (__MW_INSTRUM_RECORD_HIT_269DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_269(exp) (__MW_INSTRUM_RECORD_HIT_269DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_271CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_271(...) (__MW_INSTRUM_RECORD_HIT_271CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_271(exp) (__MW_INSTRUM_RECORD_HIT_271CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_273FNEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_273(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_273FNEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_275DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_275(...) (__MW_INSTRUM_RECORD_HIT_275DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_275(exp) (__MW_INSTRUM_RECORD_HIT_275DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_277CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_277(...) (__MW_INSTRUM_RECORD_HIT_277CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_277(exp) (__MW_INSTRUM_RECORD_HIT_277CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_279FNEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_279(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_279FNEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_276() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_281DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_281(...) (__MW_INSTRUM_RECORD_HIT_281DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_281(exp) (__MW_INSTRUM_RECORD_HIT_281DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_283FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_283(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_283FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_282() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_285DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_285(...) (__MW_INSTRUM_RECORD_HIT_285DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_285(exp) (__MW_INSTRUM_RECORD_HIT_285DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_287FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_287(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_287FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_286() ((void)0)


#define __MW_INSTRUM_NODE_270() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_289DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_289(...) (__MW_INSTRUM_RECORD_HIT_289DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_289(exp) (__MW_INSTRUM_RECORD_HIT_289DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_291CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_291(...) (__MW_INSTRUM_RECORD_HIT_291CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_291(exp) (__MW_INSTRUM_RECORD_HIT_291CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_293FNEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_293(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_293FNEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_290() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_295XZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_295() __MW_INSTRUM_RECORD_HIT_295XZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_296EZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_296() __MW_INSTRUM_RECORD_HIT_296EZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_297XZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_297() __MW_INSTRUM_RECORD_HIT_297XZ_controller_0020_0028ModelRefSIL_0029()


#endif /* __MW_INTERNAL_SLDV_PS_ANALYSIS__ */

#line 1 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\SIL_TESTS\\slprj\\ert\\controller\\controller.c"
#line 20 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\SIL_TESTS\\slprj\\ert\\controller\\controller.h"
#ifndef RTW_HEADER_controller_h_
#define RTW_HEADER_controller_h_
#ifndef controller_COMMON_INCLUDES_
#define controller_COMMON_INCLUDES_
#line 15 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\SIL_TESTS\\slprj\\ert\\_sharedutils\\rtwtypes.h"
#ifndef RTWTYPES_H
#define RTWTYPES_H



#ifndef false
#define false (0U)
#endif /* false */

#ifndef true
#define true (1U)
#endif /* true */
#line 46
typedef char int8_T; 
typedef unsigned char uint8_T; 
typedef short int16_T; 
typedef unsigned short uint16_T; 
typedef int int32_T; 
typedef unsigned uint32_T; 
typedef float real32_T; 
typedef double real64_T; 
#line 59
typedef double real_T; 
typedef double time_T; 
typedef unsigned char boolean_T; 
typedef int int_T; 
typedef unsigned uint_T; 
typedef unsigned long ulong_T; 
typedef char char_T; 
typedef unsigned char uchar_T; 
typedef char_T byte_T; 
#line 77
typedef 
#line 74
struct { 
real32_T re; 
real32_T im; 
} creal32_T; 




typedef 
#line 79
struct { 
real64_T re; 
real64_T im; 
} creal64_T; 




typedef 
#line 84
struct { 
real_T re; 
real_T im; 
} creal_T; 
#line 94
typedef 
#line 91
struct { 
int8_T re; 
int8_T im; 
} cint8_T; 
#line 101
typedef 
#line 98
struct { 
uint8_T re; 
uint8_T im; 
} cuint8_T; 
#line 108
typedef 
#line 105
struct { 
int16_T re; 
int16_T im; 
} cint16_T; 
#line 115
typedef 
#line 112
struct { 
uint16_T re; 
uint16_T im; 
} cuint16_T; 
#line 122
typedef 
#line 119
struct { 
int32_T re; 
int32_T im; 
} cint32_T; 
#line 129
typedef 
#line 126
struct { 
uint32_T re; 
uint32_T im; 
} cuint32_T; 
#line 147
typedef void *pointer_T; 

#endif /* RTWTYPES_H */
#line 25 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\SIL_TESTS\\slprj\\ert\\controller\\controller.h"
#endif /* controller_COMMON_INCLUDES_ */
#line 20 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\SIL_TESTS\\slprj\\ert\\controller\\controller_types.h"
#ifndef RTW_HEADER_controller_types_h_
#define RTW_HEADER_controller_types_h_

#ifndef DEFINED_TYPEDEF_FOR_TransmissionState_
#define DEFINED_TYPEDEF_FOR_TransmissionState_
#line 32
typedef 
#line 26
enum { 
Park, 
Reverse, 
Neutral, 
Drive, 
Brake
} TransmissionState; 

#endif /* DEFINED_TYPEDEF_FOR_TransmissionState_ */


typedef struct tag_RTM_controller_T RT_MODEL_controller_T; 

#endif /* RTW_HEADER_controller_types_h_ */
#line 36 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\SIL_TESTS\\slprj\\ert\\controller\\controller.h"
typedef 
#line 30
struct { 
real_T TargetSpeed_km_h; 
real32_T TorqueRequest_Nm; 
real32_T TorqueRequest_Nm_e; 
real32_T StoppedControllerMode; 
int32_T AutomaticTransmissionState; 
} B_controller_c_T; 
#line 48
typedef 
#line 39
struct { 
uint16_T temporalCounter_i1; 
uint8_T is_c1_controller; 
uint8_T is_active_c1_controller; 
uint8_T is_c3_controller; 
uint8_T is_Reverse; 
uint8_T is_Drive; 
uint8_T is_Brake; 
uint8_T is_active_c3_controller; 
} DW_controller_f_T; 


struct tag_RTM_controller_T { 
const char_T **errorStatus; 
}; 
#line 59
typedef 
#line 55
struct { 
B_controller_c_T rtb; 
DW_controller_f_T rtdw; 
RT_MODEL_controller_T rtm; 
} MdlrefDW_controller_T; 


extern void controller_initialize(const char_T ** rt_errorStatus, RT_MODEL_controller_T *const controller_M); 

extern void controller(const boolean_T * rtu_BrakePedalPressed, const real32_T * rtu_ThrottlePedalPosition, const TransmissionState * rtu_AutomaticTransmissionSelect, const boolean_T * rtu_BrakePedalPressed_Backup, const real32_T * rtu_ThrottlePedalPosition_Backu, const real32_T * rtu_VehicleSpeed_km_h, real32_T * rty_TorqueRequest_Nm, TransmissionState * rty_AutomaticTransmissionState, real32_T * rty_Error, real32_T * rty_Error_TS, B_controller_c_T * localB, DW_controller_f_T * localDW); 
#line 90
#endif /* RTW_HEADER_controller_h_ */
#line 2 "C:\\Program Files\\MATLAB\\R2022b\\sys\\lcc64\\lcc64\\include64\\math.h"
#ifndef __math_h__
#define __math_h__

#ifndef HUGE_VAL
#define HUGE_VAL 1.7976931348623157e+308
#endif /* HUGE_VAL */




#pragma extensions(push,on)




typedef float float_t; 
typedef double double_t; 


double atan(double); 
double _atani(int); 
long double atanl(long double); 
float atanf(float); 


long double tanl(long double); 
double tan(double); 
float tanf(float); 


double cos(double); 
long double cosl(long double); 
float cosf(float); 
double _cosi(int); 
double _cosu(unsigned); 
double _cosll(long long); 
double _cosull(unsigned long long); 

long double sinl(long double); 
float sinf(float); 
double sin(double); 
double _sini(int); 
double _sinu(unsigned); 
double _sinll(long long); 
double _sinull(unsigned long long); 


long double exp2l(long double); 
double exp2(double); 
float exp2f(float); 


double exp10(double); 
float exp10f(float); 
long double exp10l(long double); 


long double expm1l(long double); 
double expm1(double); 
float expm1f(float); 
double _expm1i(int); 


double tanh(double); 
long double tanhl(long double); 
float tanhf(float); 


double frexp(double, int *); 
long double frexpl(long double, int *); 
double _frexpi(int, int *); 
float frexpf(float, int *); 


long double fdiml(long double x, long double y); 
double fdim(double x, double y); 
float fdimf(float x, float y); 

double modf(double, double *); 
long double modfl(long double, long double *); 


double ceil(double); 
long double ceill(long double); 
float ceilf(float); 
double _ceili(int); 


double cbrt(double); 
long double cbrtl(long double); 
float cbrtf(float); 


long double fabsl(long double); 
double fabsd(double); 
float fabsf(float); 
double fabs(double); 
double _fabsi(int); 
double _fabsull(unsigned long long); 
double _fabsll(long long); 
double _fabsu(unsigned); 


long double floorl(long double); 
double floord(double); 
float floorf(float); 
double floor(double); 
double _floori(int); 
double _flooru(unsigned); 


long double fmal(long double, long double, long double); 
double fma(double, double, double); 
float fmaf(float, float, float); 
double _fmai(int, int, int); 


long double fmaxl(long double, long double); 
double fmax(double, double); 
float fmaxf(float, float); 

double acos(double); 
float acosf(float); 
long double acosl(long double); 


double asin(double); 
long double asinl(long double); 
float asinf(float); 

double atan2(double, double); 
long double atan2l(long double, long double); 
float atan2f(float, float); 


double cosh(double); 
long double coshl(long double); 
float coshf(float); 
double _coshi(int); 


double sinh(double); 
long double sinhl(long double); 
float sinhf(float); 
double _sinhi(int); 
double _sinhll(long long); 


long double expl(long double); 
float expf(float); 
double exp(double); 


double ldexp(double, int); 
long double ldexpl(long double, int); 
float ldexpf(float, int); 


long double logl(long double); 
float logf(float); 
double log(double); 
double _logi(int); 


double log10(double); 
long double log10l(long double); 
float log10f(float); 


double log1p(double); 
long double log1pl(long double); 
float log1pf(float); 


long double log10l(long double); 
float log10f(float); 
double _log10i(int); 
double log10(double); 


double pow(double, double); 
long double powl(long double, long double); 
double powd(double, double); 
long double powlli(long double, int); 
double ipow(double, int); 
double powdi(double, int); 
long double ipowl(long double, int); 
float ipowf(float, int); 
float powf(float, float); 
double powii(int, int); 
long double powlld(long double, double); 
long double powlli(long double, int); 
long double powdll(double, long double); 
double powid(int, double); 


double scalb(double, double); 
long double scalbl(long double, long double); 
float scalbf(float, float); 


double scalbn(double, int); 
long double scalbnl(long double, int); 
float scalbnf(float, int); 


double scalbln(double, long); 
long double scalblnl(long double, long); 
float scalblnf(float, long); 


long double sqrtl(long double); 
double _sqrti(int); 
double _sqrtu(unsigned); 
double _sqrtll(long long); 
double _sqrtull(unsigned long long); 
float sqrtf(float); 
double sqrt(double); 


double fmod(double, double); 
long double fmodl(long double, long double); 
float fmodf(float, float); 

double infinity(void); 
long double infinityl(void); 
float infinityf(void); 
long double max_normall(void); 
double max_normal(void); 
float max_normalf(void); 
long double min_normall(void); 
double min_normal(void); 
float min_normalf(void); 

int isnand(double); 
int isnanl(long double); 
int isnanf(float); 
int isnan(double); 

int finite(double); 

int isnormalf(float); 
int isnormal(double); 
int isnormall(long double); 

double copysign(double, double); 
long double copysignl(long double, long double); 
float copysignf(float, float); 

int ilogb(double); 
int ilogbf(float); 
int ilogbl(long double); 

double logb(double); 
long double logbl(long double); 
float logbf(float); 

double erf(double); 
long double erfl(long double); 
float erff(float); 


double erfc(double); 
long double erfcl(long double); 
float erfcf(float); 

int _signbit(double); 



double asinh(double); 
long double asinhl(long double); 
long double sinhl(long double); 
float asinhf(float); 


double nextafter(double, double); 
long double nextafterl(long double, long double); 
float nextafterf(float, float); 


double nexttoward(double, long double); 
long double nexttowardl(long double, long double); 
float nexttowardf(float, long double); 


double acosh(double); 
long double acoshl(long double); 
long double acoshl(long double); 
float acoshf(float); 


double atanh(double); 
long double atanhl(long double); 
float atanhf(float); 


double lgamma(double); 
long double lgammal(long double); 
float lgammaf(float); 

long double tgammal(long double); 
double tgamma(double); 
float tgammaf(float); 


double _y0(double); 
long double y0l(long double); 
double y1(double); 
long double y1l(long double); 
double yn(int, double); 
long double ynl(int, long double); 
double j0(double); 
double j1(double); 
long double j1l(long double); 
double jn(int, double); 
long double jnl(int, long double); 



long double log2l(long double); 
double log2(double); 
float log2f(float); 
double _log2i(int); 
double _log2ll(long long); 


long double nearbyintl(long double); 
double nearbyint(double); 
float nearbyintf(float); 


double hypot(double, double); 
long double hypotl(long double, long double); 
float hypotf(float, float); 

double _rint(double); 



int isinf(double); 
int _isinfd(double); 
int isinfl(long double); 
int isinff(float); 
int _isinfi(int); 


int isfinite(double); 
int isfinitef(float); 
int isfinitel(long double); 

int __fpclassifyl(long double); 
int __fpclassifyd(double); 
int __fpclassifyf(float); 


double round(double); 
float roundf(float); 
long double roundl(long double); 
double _roundi(int); 


double remainder(double, double); 
long double remainderl(long double, long double); 
float remainderf(float, float); 

int lrint(double); 
int lrintf(float); 
long lrintl(long double); 
long long llrintl(long double); 
long long llrintf(float); 
long long llrint(double); 

long lround(double); 
long lroundf(float); 
long lroundl(long double); 

long long llround(double); 
long long llroundf(float); 
long long llroundl(long double); 

long double remquol(long double, long double, int *); 
double remquo(double, double, int *); 
float remquof(float, float, int *); 

double trunc(double x); 
long double truncl(long double); 
float truncf(float); 


long double fminl(long double, long double); 
float fminf(float, float); 
double fmin(double, double); 
#line 406
void ldtoa(long double, char *); 
double cabs(double _Complex); 
float cabsf(float _Complex); 
long double cabsl(long double _Complex); 




struct exception { 

int type; 
char *name; 
double arg1; 
double arg2; 
double retval; 
int err; 
}; 

int matherr(struct exception * e); 

extern float __nan__; 

extern float __infinity__; 
double nan(const char *); 
float nanf(const char *); 
long double nanl(const char *); 



int fcmp(double, double, double); 
int fcmpl(long double, long double, long double); 
void sincos(double x, double * sin, double * cos); 
void sincosf(float x, float * sin, float * cos); 
void sincosl(long double x, long double * sin, long double * cos); 
#line 446
int _isgreater(long double, long double); 


int _isgreaterequal(long double, long double); 


int _isless(long double, long double); 


int _islessequal(long double, long double); 


int _islessgreater(long double, long double); 


int _isunordered(long double, long double); 
#line 474
double atof(const char *); 

int cubic(double a, double b, double c, double d, double * x); 




int cubicl(long double a, long double b, long double c, long double d, long double * x); 
#line 537
#endif /* __math_h__ */
#line 20 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\SIL_TESTS\\slprj\\ert\\controller\\controller_private.h"
#ifndef RTW_HEADER_controller_private_h_
#define RTW_HEADER_controller_private_h_




#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm) (*((rtm)->errorStatus))
#endif /* rtmGetErrorStatus */

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm,val) (*((rtm)->errorStatus) = (val))
#endif /* rtmSetErrorStatus */

#ifndef rtmGetErrorStatusPointer
#define rtmGetErrorStatusPointer(rtm) (rtm)->errorStatus
#endif /* rtmGetErrorStatusPointer */

#ifndef rtmSetErrorStatusPointer
#define rtmSetErrorStatusPointer(rtm,val) ((rtm)->errorStatus = (val))
#endif /* rtmSetErrorStatusPointer */
#endif /* RTW_HEADER_controller_private_h_ */
#line 535 "C:\\Program Files\\MATLAB\\R2022b\\sys\\lcc64\\lcc64\\include64\\math.h"
#pragma extensions(pop)
#line 49 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\SIL_TESTS\\slprj\\ert\\controller\\controller.c"
void controller(const boolean_T *rtu_BrakePedalPressed, const real32_T *
rtu_ThrottlePedalPosition, const TransmissionState *
rtu_AutomaticTransmissionSelect, const boolean_T *
rtu_BrakePedalPressed_Backup, const real32_T *
rtu_ThrottlePedalPosition_Backu, const real32_T *
rtu_VehicleSpeed_km_h, real32_T *rty_TorqueRequest_Nm, TransmissionState *
rty_AutomaticTransmissionState, real32_T *
rty_Error, real32_T *rty_Error_TS, B_controller_c_T *localB, DW_controller_f_T *
localDW) 
{ float __mw_tmp_for_expr_31; double __mw_tmp_for_expr_30; float __mw_tmp_for_expr_29; float __mw_tmp_for_expr_28; float __mw_tmp_for_expr_27; unsigned __mw_tmp_for_expr_26; int __mw_tmp_for_expr_25; int __mw_tmp_for_expr_24; float __mw_tmp_for_expr_23; int __mw_tmp_for_expr_22; int __mw_tmp_for_expr_21; unsigned __mw_tmp_for_expr_20; unsigned __mw_tmp_for_expr_19; unsigned __mw_tmp_for_expr_18; int __mw_tmp_for_expr_17; int __mw_tmp_for_expr_16; float __mw_tmp_for_expr_15; float __mw_tmp_for_expr_14; float __mw_tmp_for_expr_13; float __mw_tmp_for_expr_12; int __mw_tmp_for_expr_11; int __mw_tmp_for_expr_10; double __mw_tmp_for_expr_9; double __mw_tmp_for_expr_8; double __mw_tmp_for_expr_7; double __mw_tmp_for_expr_6; float __mw_tmp_for_expr_5; double __mw_tmp_for_expr_4; double __mw_tmp_for_expr_3; unsigned __mw_tmp_for_expr_2; float __mw_tmp_for_expr_1; __MW_INSTRUM_FCN_ENTER_1(); __MW_INSTRUM_NODE_1(); { 
int32_T rtb_AutomaticTransmissionState; 
int32_T rtb_DataTypeConversion1; 
real32_T rtb_Saturation; 


rtb_Saturation = *rtu_ThrottlePedalPosition; 
if (__MW_INSTRUM_NODE_2((__MW_INSTRUM_NODE_4(rtb_Saturation, (0.5F)), (rtb_Saturation > (0.5F))))) { 
rtb_Saturation = (0.5F); 
} else { if (__MW_INSTRUM_NODE_6(((__mw_tmp_for_expr_1 = -(0.5F)), (__MW_INSTRUM_NODE_8(rtb_Saturation, __mw_tmp_for_expr_1), (rtb_Saturation < __mw_tmp_for_expr_1))))) { 
rtb_Saturation = -(0.5F); 
}  }  




rtb_DataTypeConversion1 = (int32_T)(*rtu_AutomaticTransmissionSelect); 


if (__MW_INSTRUM_NODE_10(((__mw_tmp_for_expr_2 = localDW->is_active_c3_controller), (__MW_INSTRUM_NODE_12(__mw_tmp_for_expr_2, 0U), (__mw_tmp_for_expr_2 == 0U))))) { 
localDW->is_active_c3_controller = (1U); 
localDW->is_c3_controller = (uint8_T)4U; 
rtb_AutomaticTransmissionState = 0; 
} else { 
switch (localDW->is_c3_controller) { 
case (uint8_T)1U:  __MW_INSTRUM_NODE_15(); 
{ 
rtb_AutomaticTransmissionState = 4; 
if (__MW_INSTRUM_NODE_16((__MW_INSTRUM_NODE_18(rtb_DataTypeConversion1, 4), (rtb_DataTypeConversion1 != 4)))) { 
localDW->is_Brake = (uint8_T)0U; 
localDW->is_c3_controller = (uint8_T)2U; 
rtb_AutomaticTransmissionState = 3; 
localDW->is_Drive = (uint8_T)1U; 
} else { 
switch (localDW->is_Brake) { 
case (uint8_T)1U:  __MW_INSTRUM_NODE_21(); 
if (__MW_INSTRUM_NODE_22(((__mw_tmp_for_expr_3 = rtb_Saturation), (__MW_INSTRUM_NODE_24(__mw_tmp_for_expr_3, (0.33333333333333331)), (__mw_tmp_for_expr_3 < (0.33333333333333331)))))) { 
localDW->is_Brake = (uint8_T)2U; 
localB->StoppedControllerMode = (0.0F); 
} else { if (__MW_INSTRUM_NODE_26(*rtu_BrakePedalPressed)) { 
localDW->is_Brake = (uint8_T)3U; 
} else { 
localB->TorqueRequest_Nm_e = (rtb_Saturation - (0.333333343F)) * (120.0F); 

}  }  
break; 

case (uint8_T)2U:  __MW_INSTRUM_NODE_28(); 
if (__MW_INSTRUM_NODE_29(((__mw_tmp_for_expr_4 = rtb_Saturation), (__MW_INSTRUM_NODE_31(__mw_tmp_for_expr_4, (0.33333333333333331)), (__mw_tmp_for_expr_4 > (0.33333333333333331)))))) { 
localDW->is_Brake = (uint8_T)1U; 
localB->StoppedControllerMode = (0.0F); 
} else { if (__MW_INSTRUM_NODE_33(((__mw_tmp_for_expr_5 = (__MW_INSTRUM_NODE_37(), fabsf(*rtu_VehicleSpeed_km_h))), (__MW_INSTRUM_NODE_35(__mw_tmp_for_expr_5, (1.0F)), (__mw_tmp_for_expr_5 <= (1.0F)))))) { 
localDW->is_Brake = (uint8_T)4U; 
localB->StoppedControllerMode = (1.0F); 
} else { if (__MW_INSTRUM_NODE_38(*rtu_BrakePedalPressed)) { 
localDW->is_Brake = (uint8_T)3U; 
} else { 
localB->TorqueRequest_Nm_e = ((1.0F) - (3.0F) * rtb_Saturation) * -(80.0F); 

}  }  }  
break; 

case (uint8_T)3U:  __MW_INSTRUM_NODE_40(); 
{ 
boolean_T i_out; 
i_out = __MW_INSTRUM_NODE_41(!__MW_INSTRUM_NODE_43(*rtu_BrakePedalPressed)); 
if (__MW_INSTRUM_NODE_45(__MW_INSTRUM_NODE_47(((__mw_tmp_for_expr_6 = rtb_Saturation), (__MW_INSTRUM_NODE_49(__mw_tmp_for_expr_6, (0.33333333333333331)), (__mw_tmp_for_expr_6 > (0.33333333333333331))))) && (__MW_INSTRUM_NODE_51(i_out)))) { 
localDW->is_Brake = (uint8_T)1U; 
localB->StoppedControllerMode = (0.0F); 
} else { if (__MW_INSTRUM_NODE_53(__MW_INSTRUM_NODE_55(((__mw_tmp_for_expr_7 = rtb_Saturation), (__MW_INSTRUM_NODE_57(__mw_tmp_for_expr_7, (0.33333333333333331)), (__mw_tmp_for_expr_7 <= (0.33333333333333331))))) && (__MW_INSTRUM_NODE_59(i_out)))) { 
localDW->is_Brake = (uint8_T)2U; 
localB->StoppedControllerMode = (0.0F); 
} else { 
localB->StoppedControllerMode = (1.0F); 
localB->TargetSpeed_km_h = (0.0); 
}  }  
} 
break; 

default:  __MW_INSTRUM_NODE_61(); 

if (__MW_INSTRUM_NODE_62(((__mw_tmp_for_expr_8 = rtb_Saturation), (__MW_INSTRUM_NODE_64(__mw_tmp_for_expr_8, (0.33333333333333331)), (__mw_tmp_for_expr_8 > (0.33333333333333331)))))) { 
localDW->is_Brake = (uint8_T)1U; 
localB->StoppedControllerMode = (0.0F); 
} else { 
localB->TargetSpeed_km_h = (0.0); 
}  
break; 
}  
}  
} 
break; 

case (uint8_T)2U:  __MW_INSTRUM_NODE_66(); 
{ 
rtb_AutomaticTransmissionState = 3; 
if (__MW_INSTRUM_NODE_67(__MW_INSTRUM_NODE_69((__MW_INSTRUM_NODE_71(rtb_DataTypeConversion1, 4), (rtb_DataTypeConversion1 == 4))) && __MW_INSTRUM_NODE_74(((__mw_tmp_for_expr_9 = rtb_Saturation), (__MW_INSTRUM_NODE_76(__mw_tmp_for_expr_9, (0.33333333333333331)), (__mw_tmp_for_expr_9 > (0.33333333333333331))))))) 
{ 
localDW->is_Drive = (uint8_T)0U; 
localDW->is_c3_controller = (uint8_T)1U; 
rtb_AutomaticTransmissionState = 4; 
localDW->is_Brake = (uint8_T)2U; 
localB->StoppedControllerMode = (0.0F); 
} else { if (__MW_INSTRUM_NODE_78((__MW_INSTRUM_NODE_80(rtb_DataTypeConversion1, 3), (rtb_DataTypeConversion1 < 3)))) { 
localDW->is_Drive = (uint8_T)0U; 
localDW->is_c3_controller = (uint8_T)3U; 
rtb_AutomaticTransmissionState = 2; 
} else { if (__MW_INSTRUM_NODE_83(((__mw_tmp_for_expr_10 = localDW->is_Drive), ((__mw_tmp_for_expr_11 = (uint8_T)1U), (__MW_INSTRUM_NODE_85(__mw_tmp_for_expr_10, __mw_tmp_for_expr_11), (__mw_tmp_for_expr_10 == __mw_tmp_for_expr_11)))))) { 
boolean_T i_out; 
i_out = __MW_INSTRUM_NODE_88((__MW_INSTRUM_NODE_90(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_92((__MW_INSTRUM_NODE_94(rtb_Saturation, (0.0F)), (rtb_Saturation == (0.0F))))); 
if (__MW_INSTRUM_NODE_96(i_out)) { 
localDW->is_Drive = (uint8_T)2U; 
} else { 
localB->TorqueRequest_Nm_e = (80.0F) * rtb_Saturation; 
}  
} else { 
boolean_T i_out; 


i_out = __MW_INSTRUM_NODE_98(__MW_INSTRUM_NODE_100((__MW_INSTRUM_NODE_102(rtb_Saturation, (0.0F)), (rtb_Saturation > (0.0F)))) && __MW_INSTRUM_NODE_104(!__MW_INSTRUM_NODE_106(*rtu_BrakePedalPressed))); 
if (__MW_INSTRUM_NODE_108(i_out)) { 
localDW->is_Drive = (uint8_T)1U; 
} else { 
localB->StoppedControllerMode = (1.0F); 
localB->TargetSpeed_km_h = (0.0); 
}  
}  }  }  
} 
break; 

case (uint8_T)3U:  __MW_INSTRUM_NODE_110(); 
{ 
boolean_T i_out; 
rtb_AutomaticTransmissionState = 2; 
i_out = __MW_INSTRUM_NODE_111(__MW_INSTRUM_NODE_113(((__mw_tmp_for_expr_12 = (__MW_INSTRUM_NODE_117(), fabsf(*rtu_VehicleSpeed_km_h))), (__MW_INSTRUM_NODE_115(__mw_tmp_for_expr_12, (5.0F)), (__mw_tmp_for_expr_12 < (5.0F))))) && __MW_INSTRUM_NODE_118((__MW_INSTRUM_NODE_120(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_122((__MW_INSTRUM_NODE_124(rtb_DataTypeConversion1, 0), (rtb_DataTypeConversion1 == 0))))); 

if (__MW_INSTRUM_NODE_127(i_out)) { 
localDW->is_c3_controller = (uint8_T)4U; 
rtb_AutomaticTransmissionState = 0; 
} else { 
i_out = __MW_INSTRUM_NODE_129(__MW_INSTRUM_NODE_131(__MW_INSTRUM_NODE_133(((__mw_tmp_for_expr_13 = *rtu_VehicleSpeed_km_h), (__MW_INSTRUM_NODE_135(__mw_tmp_for_expr_13, (5.0F)), (__mw_tmp_for_expr_13 < (5.0F))))) && (__MW_INSTRUM_NODE_137(*rtu_BrakePedalPressed))) && __MW_INSTRUM_NODE_139((__MW_INSTRUM_NODE_141(rtb_DataTypeConversion1, 1), (rtb_DataTypeConversion1 == 1)))); 

if (__MW_INSTRUM_NODE_144(i_out)) { 
localDW->is_c3_controller = (uint8_T)5U; 
rtb_AutomaticTransmissionState = 1; 
localDW->is_Reverse = (uint8_T)1U; 
} else { 
i_out = __MW_INSTRUM_NODE_146(__MW_INSTRUM_NODE_148(__MW_INSTRUM_NODE_150(((__mw_tmp_for_expr_14 = *rtu_VehicleSpeed_km_h), ((__mw_tmp_for_expr_15 = -(5.0F)), (__MW_INSTRUM_NODE_152(__mw_tmp_for_expr_14, __mw_tmp_for_expr_15), (__mw_tmp_for_expr_14 > __mw_tmp_for_expr_15))))) && (__MW_INSTRUM_NODE_154(*rtu_BrakePedalPressed))) && __MW_INSTRUM_NODE_156((__MW_INSTRUM_NODE_158(rtb_DataTypeConversion1, 2), (rtb_DataTypeConversion1 > 2)))); 

if (__MW_INSTRUM_NODE_161(i_out)) { 
localDW->is_c3_controller = (uint8_T)2U; 
rtb_AutomaticTransmissionState = 3; 
localDW->is_Drive = (uint8_T)1U; 
} else { 
localB->TorqueRequest_Nm_e = (0.0F); 
}  
}  
}  
} 
break; 

case (uint8_T)4U:  __MW_INSTRUM_NODE_163(); 
{ 
boolean_T i_out; 
rtb_AutomaticTransmissionState = 0; 
i_out = __MW_INSTRUM_NODE_164((__MW_INSTRUM_NODE_166(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_168((__MW_INSTRUM_NODE_170(rtb_DataTypeConversion1, 0), (rtb_DataTypeConversion1 != 0)))); 
if (__MW_INSTRUM_NODE_173(i_out)) { 
localDW->is_c3_controller = (uint8_T)3U; 
rtb_AutomaticTransmissionState = 2; 
} else { 
localB->TorqueRequest_Nm_e = (0.0F); 
}  
} 
break; 

default:  __MW_INSTRUM_NODE_175(); 
{ 

rtb_AutomaticTransmissionState = 1; 
if (__MW_INSTRUM_NODE_176((__MW_INSTRUM_NODE_178(rtb_DataTypeConversion1, 1), (rtb_DataTypeConversion1 != 1)))) { 
localDW->is_Reverse = (uint8_T)0U; 
localDW->is_c3_controller = (uint8_T)3U; 
rtb_AutomaticTransmissionState = 2; 
} else { if (__MW_INSTRUM_NODE_181(((__mw_tmp_for_expr_16 = localDW->is_Reverse), ((__mw_tmp_for_expr_17 = (uint8_T)1U), (__MW_INSTRUM_NODE_183(__mw_tmp_for_expr_16, __mw_tmp_for_expr_17), (__mw_tmp_for_expr_16 == __mw_tmp_for_expr_17)))))) { 
boolean_T i_out; 
i_out = __MW_INSTRUM_NODE_186((__MW_INSTRUM_NODE_188(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_190((__MW_INSTRUM_NODE_192(rtb_Saturation, (0.0F)), (rtb_Saturation == (0.0F))))); 
if (__MW_INSTRUM_NODE_194(i_out)) { 
localDW->is_Reverse = (uint8_T)2U; 
} else { 
localB->StoppedControllerMode = (0.0F); 
localB->TorqueRequest_Nm_e = -rtb_Saturation * (40.0F); 
}  
} else { 
boolean_T i_out; 


i_out = __MW_INSTRUM_NODE_196(__MW_INSTRUM_NODE_198(!__MW_INSTRUM_NODE_200(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_202((__MW_INSTRUM_NODE_204(rtb_Saturation, (0.0F)), (rtb_Saturation > (0.0F))))); 
if (__MW_INSTRUM_NODE_206(i_out)) { 
localDW->is_Reverse = (uint8_T)1U; 
} else { 
localB->StoppedControllerMode = (1.0F); 
localB->TargetSpeed_km_h = (0.0); 
}  
}  }  
} 
break; 
}  
}  




if (__MW_INSTRUM_NODE_208(((__mw_tmp_for_expr_18 = localDW->temporalCounter_i1), (__MW_INSTRUM_NODE_210(__mw_tmp_for_expr_18, 511U), (__mw_tmp_for_expr_18 < 511U))))) { 
(localDW->temporalCounter_i1)++; 
}  

if (__MW_INSTRUM_NODE_213(((__mw_tmp_for_expr_19 = localDW->is_active_c1_controller), (__MW_INSTRUM_NODE_215(__mw_tmp_for_expr_19, 0U), (__mw_tmp_for_expr_19 == 0U))))) { 
localDW->is_active_c1_controller = (1U); 
localDW->is_c1_controller = (uint8_T)3U; 
} else { 
switch (localDW->is_c1_controller) { 
case (uint8_T)1U:  __MW_INSTRUM_NODE_218(); 
if (__MW_INSTRUM_NODE_219(((__mw_tmp_for_expr_20 = localDW->temporalCounter_i1), (__MW_INSTRUM_NODE_221(__mw_tmp_for_expr_20, 100U), (__mw_tmp_for_expr_20 >= 100U))))) { 
localDW->is_c1_controller = (uint8_T)2U; 
} else { if (__MW_INSTRUM_NODE_224(((__mw_tmp_for_expr_21 = __MW_INSTRUM_NODE_229(*rtu_BrakePedalPressed_Backup)), ((__mw_tmp_for_expr_22 = __MW_INSTRUM_NODE_231(*rtu_BrakePedalPressed)), (__MW_INSTRUM_NODE_226(__mw_tmp_for_expr_21, __mw_tmp_for_expr_22), (__mw_tmp_for_expr_21 == __mw_tmp_for_expr_22)))))) { 
localDW->is_c1_controller = (uint8_T)3U; 
}  }  
break; 

case (uint8_T)2U:  __MW_INSTRUM_NODE_233(); 
*rty_Error = (1.0F); 
localB->AutomaticTransmissionState = 2; 
localB->TorqueRequest_Nm = (0.0F); 
break; 

case (uint8_T)3U:  __MW_INSTRUM_NODE_234(); 
if (__MW_INSTRUM_NODE_235(((__mw_tmp_for_expr_23 = *rtu_ThrottlePedalPosition_Backu), (__MW_INSTRUM_NODE_237(__mw_tmp_for_expr_23, rtb_Saturation), (__mw_tmp_for_expr_23 != rtb_Saturation))))) { 
localDW->is_c1_controller = (uint8_T)4U; 
localDW->temporalCounter_i1 = (0U); 
} else { if (__MW_INSTRUM_NODE_239(((__mw_tmp_for_expr_24 = __MW_INSTRUM_NODE_244(*rtu_BrakePedalPressed_Backup)), ((__mw_tmp_for_expr_25 = __MW_INSTRUM_NODE_246(*rtu_BrakePedalPressed)), (__MW_INSTRUM_NODE_241(__mw_tmp_for_expr_24, __mw_tmp_for_expr_25), (__mw_tmp_for_expr_24 != __mw_tmp_for_expr_25)))))) { 
localDW->is_c1_controller = (uint8_T)1U; 
localDW->temporalCounter_i1 = (0U); 
} else { if (__MW_INSTRUM_NODE_248((__MW_INSTRUM_NODE_250(rtb_DataTypeConversion1, rtb_AutomaticTransmissionState), (rtb_DataTypeConversion1 != rtb_AutomaticTransmissionState)))) { 
localDW->is_c1_controller = (uint8_T)5U; 
localDW->temporalCounter_i1 = (0U); 
} else { 
*rty_Error = (0.0F); 
*rty_Error_TS = (0.0F); 
}  }  }  
break; 

case (uint8_T)4U:  __MW_INSTRUM_NODE_253(); 
if (__MW_INSTRUM_NODE_254(((__mw_tmp_for_expr_26 = localDW->temporalCounter_i1), (__MW_INSTRUM_NODE_256(__mw_tmp_for_expr_26, 100U), (__mw_tmp_for_expr_26 >= 100U))))) { 
localDW->is_c1_controller = (uint8_T)2U; 
} else { if (__MW_INSTRUM_NODE_259(((__mw_tmp_for_expr_27 = *rtu_ThrottlePedalPosition_Backu), (__MW_INSTRUM_NODE_261(__mw_tmp_for_expr_27, rtb_Saturation), (__mw_tmp_for_expr_27 == rtb_Saturation))))) { 
localDW->is_c1_controller = (uint8_T)3U; 
}  }  
break; 

default:  __MW_INSTRUM_NODE_263(); 

if (__MW_INSTRUM_NODE_264((__MW_INSTRUM_NODE_266(rtb_DataTypeConversion1, rtb_AutomaticTransmissionState), (rtb_DataTypeConversion1 == rtb_AutomaticTransmissionState)))) { 
localDW->is_c1_controller = (uint8_T)3U; 
} else { 
*rty_Error_TS = (1.0F); 
localB->TorqueRequest_Nm = (0.0F); 
}  
break; 
}  
}  
#line 336
if (__MW_INSTRUM_NODE_269(!__MW_INSTRUM_NODE_271(((__mw_tmp_for_expr_28 = *rty_Error + *rty_Error_TS), (__MW_INSTRUM_NODE_273(__mw_tmp_for_expr_28, (0.0F)), (__mw_tmp_for_expr_28 != (0.0F))))))) { 
real_T rtb_Sum; 
#line 343
if (__MW_INSTRUM_NODE_275(!__MW_INSTRUM_NODE_277(((__mw_tmp_for_expr_29 = localB->StoppedControllerMode), (__MW_INSTRUM_NODE_279(__mw_tmp_for_expr_29, (0.0F)), (__mw_tmp_for_expr_29 != (0.0F))))))) { 
rtb_Sum = localB->TorqueRequest_Nm_e; 
} else { 

rtb_Sum = localB->TargetSpeed_km_h - *rtu_VehicleSpeed_km_h; 
rtb_Sum *= (30.0); 
}  




if (__MW_INSTRUM_NODE_281((__MW_INSTRUM_NODE_283(rtb_Sum, (80.0)), (rtb_Sum > (80.0))))) { 
*rty_TorqueRequest_Nm = (80.0F); 
} else { if (__MW_INSTRUM_NODE_285(((__mw_tmp_for_expr_30 = -(80.0)), (__MW_INSTRUM_NODE_287(rtb_Sum, __mw_tmp_for_expr_30), (rtb_Sum < __mw_tmp_for_expr_30))))) { 
*rty_TorqueRequest_Nm = -(80.0F); 
} else { 
*rty_TorqueRequest_Nm = (real32_T)rtb_Sum; 
}  }  


} else { 
*rty_TorqueRequest_Nm = localB->TorqueRequest_Nm; 
}  
#line 374
if (__MW_INSTRUM_NODE_289(!__MW_INSTRUM_NODE_291(((__mw_tmp_for_expr_31 = *rty_Error), (__MW_INSTRUM_NODE_293(__mw_tmp_for_expr_31, (0.0F)), (__mw_tmp_for_expr_31 != (0.0F))))))) { 
*rty_AutomaticTransmissionState = (TransmissionState)rtb_AutomaticTransmissionState; 

} else { 
*rty_AutomaticTransmissionState = (TransmissionState)(localB->AutomaticTransmissionState); 

}  } __MW_INSTRUM_NODE_295(); 


} 


void controller_initialize(const char_T **rt_errorStatus, RT_MODEL_controller_T *const 
controller_M) 
{ __MW_INSTRUM_FCN_ENTER_2(); __MW_INSTRUM_NODE_296(); 



controller_M->errorStatus = rt_errorStatus; __MW_INSTRUM_NODE_297(); 
} 

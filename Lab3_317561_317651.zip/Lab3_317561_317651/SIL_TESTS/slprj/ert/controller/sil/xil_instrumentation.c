/*
 * File: xil_instrumentation.c
 *
 * Code generated for instrumentation.
 *
 * This file contains stub implementations of the instrumentation utility
 * functions. These stubs allow instrumented code to be compiled
 * into an executable that does not support collection of execution
 * instrumentation data.
 *
 */

#include "xil_instrumentation.h"

/* Code instrumentation offset(s) for model controller (ModelRefSIL) */
#define _MW_INSTRUM_R_0df40a7408140e24_offset 0
#include <string.h>

void __MW_INSTRUM_RECORD_HIT(uint32_T sectionId)
{
  /* Send information that instrumentation point was hit to host */
  xilUploadCodeInstrData((void *)0, (uint32_T)(0), sectionId);
}

#ifdef __cplusplus

extern "C"
{

#endif

  const unsigned int __mw_instrum_controller_hits_size = 333;

#ifdef __cplusplus

}

#endif

unsigned int __mw_instrum_controller_hits[333];

#ifdef __cplusplus

extern "C"
{

#endif

  unsigned int* __mw_instrum_controller_phits = &__mw_instrum_controller_hits[0];

#ifdef __cplusplus

}

#endif

void xilUploadCoverageSynthesis(void)
{
  uint32_T sz;
  sz = (uint32_T)(__mw_instrum_controller_hits_size * sizeof(uint32_T));
  xilUploadCodeInstrData((void *)__mw_instrum_controller_hits, sz, 1);
  memset((void *) __mw_instrum_controller_hits, 0, sz);
}

void xilInitCoverage(void)
{
  uint32_T sz;
  sz = (uint32_T)(__mw_instrum_controller_hits_size * sizeof(uint32_T));
  memset((void *) __mw_instrum_controller_hits, 0, sz);
}

/* Code instrumentation method(s) for model controller (ModelRefSIL) */
void _MW_INSTRUM_R_0df40a7408140e24(uint32_T sectionId)
{
  __MW_INSTRUM_RECORD_HIT(_MW_INSTRUM_R_0df40a7408140e24_offset + sectionId);
}

void InitEvent (void)
{
  /* callbacks executed when the sim starts */
  xilInitCoverage();
}

void PauseEvent (void)
{
  /* callbacks executed when the sim is paused */
  xilUploadCoverageSynthesis();
}

void TerminateEvent (void)
{
  /* callbacks executed when the sim ends */
  xilUploadCoverageSynthesis();
}

void StepCompletedEvent (void)
{
  /* callbacks executed when a step ends */
  xilUploadCoverageSynthesis();
}

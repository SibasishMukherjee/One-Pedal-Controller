/*
 * Code generation for system model 'plant'
 * For more details, see corresponding source file plant.c
 *
 */

#ifndef RTW_HEADER_plant_h_
#define RTW_HEADER_plant_h_
#ifndef plant_COMMON_INCLUDES_
#define plant_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* plant_COMMON_INCLUDES_ */

#include "plant_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "model_reference_types.h"
#include "rtGetInf.h"
#include <string.h>

/* Block signals for model 'plant' */
typedef struct {
  real_T km_h_2_m_s;                   /* '<Root>/km_h_2_m_s' */
  real_T Integrator_o2;                /* '<Root>/Integrator' */
  real_T Gain1;                        /* '<Root>/Gain1' */
  real_T Gain;                         /* '<Root>/Gain' */
} B_plant_c_T;

/* Block states (default storage) for model 'plant' */
typedef struct {
  int32_T clockTickCounter;            /* '<Root>/Pulse Generator' */
  int_T Integrator_IWORK;              /* '<Root>/Integrator' */
} DW_plant_f_T;

/* Continuous states for model 'plant' */
typedef struct {
  real_T vehicle_speed;                /* '<Root>/Integrator' */
} X_plant_n_T;

/* State derivatives for model 'plant' */
typedef struct {
  real_T vehicle_speed;                /* '<Root>/Integrator' */
} XDot_plant_n_T;

/* State Disabled for model 'plant' */
typedef struct {
  boolean_T vehicle_speed;             /* '<Root>/Integrator' */
} XDis_plant_n_T;

/* Parameters (default storage) */
struct P_plant_T_ {
  real_T v0_km_h_Value;                /* Expression: 0
                                        * Referenced by: '<Root>/v0_km_h'
                                        */
  real_T km_h_2_m_s_Gain;              /* Expression: 1/3.6
                                        * Referenced by: '<Root>/km_h_2_m_s'
                                        */
  real_T PulseGenerator_Amp;           /* Expression: 0
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period;     /* Computed Parameter: PulseGenerator_Period
                                     * Referenced by: '<Root>/Pulse Generator'
                                     */
  real_T PulseGenerator_Duty;         /* Computed Parameter: PulseGenerator_Duty
                                       * Referenced by: '<Root>/Pulse Generator'
                                       */
  real_T PulseGenerator_PhaseDelay;    /* Expression: 5
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
  real_T Gain2_Gain;                   /* Expression: pi/180
                                        * Referenced by: '<Root>/Gain2'
                                        */
  real_T avoid0_Value;                 /* Expression: 1
                                        * Referenced by: '<Root>/avoid0'
                                        */
  real32_T engine_force_gain_Gain; /* Computed Parameter: engine_force_gain_Gain
                                    * Referenced by: '<Root>/engine_force_gain'
                                    */
  real32_T m_s_2_km_h_Gain;            /* Computed Parameter: m_s_2_km_h_Gain
                                        * Referenced by: '<Root>/m_s_2_km_h'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_plant_T {
  const char_T **errorStatus;
  RTWSolverInfo *solverInfo;
  const rtTimingBridge *timingBridge;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize0;
    SimTimeStep *simTimeStep;
    boolean_T *stopRequestedFlag;
  } Timing;
};

typedef struct {
  B_plant_c_T rtb;
  DW_plant_f_T rtdw;
  RT_MODEL_plant_T rtm;
} MdlrefDW_plant_T;

/* Model block global parameters (default storage) */
extern real_T rtP_MAX_SPEED_BACKWARD;  /* Variable: MAX_SPEED_BACKWARD
                                        * Referenced by: '<Root>/Integrator'
                                        */
extern real_T rtP_MAX_SPEED_FORWARD;   /* Variable: MAX_SPEED_FORWARD
                                        * Referenced by: '<Root>/Integrator'
                                        */
extern real_T rtP_m;                   /* Variable: m
                                        * Referenced by:
                                        *   '<Root>/Gain'
                                        *   '<Root>/Gain1'
                                        */
extern real32_T rtP_TRANSMISSION_RATIO;/* Variable: TRANSMISSION_RATIO
                                        * Referenced by: '<Root>/transmission_gears_ratio'
                                        */
extern real32_T rtP_X_air;             /* Variable: X_air
                                        * Referenced by: '<Root>/drag_force_gain_air'
                                        */
extern real32_T rtP_X_tyres;           /* Variable: X_tyres
                                        * Referenced by: '<Root>/drag_force_gain_tires'
                                        */

/* Model reference registration function */
extern void plant_initialize(const char_T **rt_errorStatus, boolean_T
  *rt_stopRequested, RTWSolverInfo *rt_solverInfo, const rtTimingBridge
  *timingBridge, RT_MODEL_plant_T *const plant_M, B_plant_c_T *localB,
  DW_plant_f_T *localDW);
extern void plant_Init(RT_MODEL_plant_T * const plant_M, DW_plant_f_T *localDW,
  X_plant_n_T *localX);
extern void plant_Reset(RT_MODEL_plant_T * const plant_M, DW_plant_f_T *localDW,
  X_plant_n_T *localX);
extern void plant_Deriv(B_plant_c_T *localB, X_plant_n_T *localX, XDot_plant_n_T
  *localXdot);
extern void plant_Update(DW_plant_f_T *localDW);
extern void plant(RT_MODEL_plant_T * const plant_M, const real32_T
                  *rtu_TorqueRequest_Nm, real32_T *rty_Vehicle_Speed_km_h,
                  B_plant_c_T *localB, DW_plant_f_T *localDW, X_plant_n_T
                  *localX);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'plant'
 */
#endif                                 /* RTW_HEADER_plant_h_ */

/*
 * Code generation for system model 'plant'
 *
 * Model                      : plant
 * Model version              : 3.20
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Thu May 25 21:24:10 2023
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "plant.h"
#include "rtwtypes.h"
#include "plant_private.h"
#include "rt_nonfinite.h"
#include <math.h>
#include <string.h>

P_plant_T plant_P = {
  /* Expression: 0
   * Referenced by: '<Root>/v0_km_h'
   */
  0.0,

  /* Expression: 1/3.6
   * Referenced by: '<Root>/km_h_2_m_s'
   */
  0.27777777777777779,

  /* Expression: 0
   * Referenced by: '<Root>/Pulse Generator'
   */
  0.0,

  /* Computed Parameter: PulseGenerator_Period
   * Referenced by: '<Root>/Pulse Generator'
   */
  2.0,

  /* Computed Parameter: PulseGenerator_Duty
   * Referenced by: '<Root>/Pulse Generator'
   */
  1.0,

  /* Expression: 5
   * Referenced by: '<Root>/Pulse Generator'
   */
  5.0,

  /* Expression: pi/180
   * Referenced by: '<Root>/Gain2'
   */
  0.017453292519943295,

  /* Expression: 1
   * Referenced by: '<Root>/avoid0'
   */
  1.0,

  /* Computed Parameter: engine_force_gain_Gain
   * Referenced by: '<Root>/engine_force_gain'
   */
  3.33333325F,

  /* Computed Parameter: m_s_2_km_h_Gain
   * Referenced by: '<Root>/m_s_2_km_h'
   */
  3.6F
};

/* System initialize for referenced model: 'plant' */
void plant_Init(RT_MODEL_plant_T * const plant_M, DW_plant_f_T *localDW,
                X_plant_n_T *localX)
{
  /* Start for DiscretePulseGenerator: '<Root>/Pulse Generator' */
  localDW->clockTickCounter = -5;

  /* InitializeConditions for Integrator: '<Root>/Integrator' */
  if (rtmIsFirstInitCond(plant_M)) {
    localX->vehicle_speed = 0.0;
  }

  localDW->Integrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<Root>/Integrator' */
}

/* System reset for referenced model: 'plant' */
void plant_Reset(RT_MODEL_plant_T * const plant_M, DW_plant_f_T *localDW,
                 X_plant_n_T *localX)
{
  /* InitializeConditions for Integrator: '<Root>/Integrator' */
  if (rtmIsFirstInitCond(plant_M)) {
    localX->vehicle_speed = 0.0;
  }

  localDW->Integrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<Root>/Integrator' */
}

/* Outputs for referenced model: 'plant' */
void plant(RT_MODEL_plant_T * const plant_M, const real32_T
           *rtu_TorqueRequest_Nm, real32_T *rty_Vehicle_Speed_km_h, B_plant_c_T *
           localB, DW_plant_f_T *localDW, X_plant_n_T *localX)
{
  real_T rtb_PulseGenerator;
  real32_T rtb_Sign;
  real32_T rtb_transmission_gears_ratio;
  if (rtmIsMajorTimeStep(plant_M)) {
    /* Gain: '<Root>/km_h_2_m_s' incorporates:
     *  Constant: '<Root>/v0_km_h'
     */
    localB->km_h_2_m_s = plant_P.km_h_2_m_s_Gain * plant_P.v0_km_h_Value;
  }

  /* Integrator: '<Root>/Integrator' */
  /* Limited  Integrator  (w/ Saturation Port) */
  if (localDW->Integrator_IWORK != 0) {
    localX->vehicle_speed = localB->km_h_2_m_s;
  }

  if (localX->vehicle_speed >= rtP_MAX_SPEED_FORWARD / 3.6) {
    localX->vehicle_speed = rtP_MAX_SPEED_FORWARD / 3.6;

    /* Integrator: '<Root>/Integrator' */
    localB->Integrator_o2 = 1.0;
  } else {
    rtb_PulseGenerator = -rtP_MAX_SPEED_BACKWARD / 3.6;
    if (localX->vehicle_speed <= rtb_PulseGenerator) {
      localX->vehicle_speed = rtb_PulseGenerator;

      /* Integrator: '<Root>/Integrator' */
      localB->Integrator_o2 = -1.0;
    } else {
      /* Integrator: '<Root>/Integrator' */
      localB->Integrator_o2 = 0.0;
    }
  }

  if (rtmIsMajorTimeStep(plant_M)) {
    /* Stop: '<Root>/Stop Simulation' */
    if (localB->Integrator_o2 != 0.0) {
      rtmSetStopRequested(plant_M, 1);
    }

    /* End of Stop: '<Root>/Stop Simulation' */

    /* DiscretePulseGenerator: '<Root>/Pulse Generator' */
    rtb_PulseGenerator = (localDW->clockTickCounter <
                          plant_P.PulseGenerator_Duty) &&
      (localDW->clockTickCounter >= 0) ? plant_P.PulseGenerator_Amp : 0.0;
    if (localDW->clockTickCounter >= plant_P.PulseGenerator_Period - 1.0) {
      localDW->clockTickCounter = 0;
    } else {
      localDW->clockTickCounter++;
    }

    /* End of DiscretePulseGenerator: '<Root>/Pulse Generator' */

    /* Gain: '<Root>/Gain1' incorporates:
     *  Gain: '<Root>/Gain2'
     *  Trigonometry: '<Root>/Sin'
     */
    localB->Gain1 = rtP_m * 9.81 * sin(plant_P.Gain2_Gain * rtb_PulseGenerator);
  }

  /* Gain: '<Root>/transmission_gears_ratio' */
  rtb_transmission_gears_ratio = rtP_TRANSMISSION_RATIO * *rtu_TorqueRequest_Nm;

  /* Signum: '<Root>/Sign' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  Integrator: '<Root>/Integrator'
   */
  if (rtIsNaNF((real32_T)localX->vehicle_speed)) {
    rtb_Sign = (rtNaNF);
  } else if ((real32_T)localX->vehicle_speed < 0.0F) {
    rtb_Sign = -1.0F;
  } else {
    rtb_Sign = (real32_T)((real32_T)localX->vehicle_speed > 0.0F);
  }

  /* End of Signum: '<Root>/Sign' */

  /* Switch: '<Root>/Switch' incorporates:
   *  Constant: '<Root>/avoid0'
   */
  if (rtb_Sign != 0.0F) {
    rtb_PulseGenerator = rtb_Sign;
  } else {
    rtb_PulseGenerator = plant_P.avoid0_Value;
  }

  /* Gain: '<Root>/Gain' incorporates:
   *  Abs: '<Root>/Abs'
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  Gain: '<Root>/drag_force_gain_air'
   *  Gain: '<Root>/drag_force_gain_tires'
   *  Gain: '<Root>/engine_force_gain'
   *  Integrator: '<Root>/Integrator'
   *  Math: '<Root>/Square'
   *  Product: '<Root>/Product1'
   *  Sum: '<Root>/Add'
   *  Sum: '<Root>/Add1'
   *  Switch: '<Root>/Switch'
   */
  localB->Gain = ((plant_P.engine_force_gain_Gain * rtb_transmission_gears_ratio
                   + localB->Gain1) - ((real32_T)localX->vehicle_speed *
    (real32_T)localX->vehicle_speed * rtP_X_air + rtP_X_tyres * fabsf((real32_T)
    localX->vehicle_speed)) * rtb_PulseGenerator) * (1.0 / rtP_m);

  /* Gain: '<Root>/m_s_2_km_h' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  Integrator: '<Root>/Integrator'
   */
  *rty_Vehicle_Speed_km_h = plant_P.m_s_2_km_h_Gain * (real32_T)
    localX->vehicle_speed;
}

/* Update for referenced model: 'plant' */
void plant_Update(DW_plant_f_T *localDW)
{
  /* Update for Integrator: '<Root>/Integrator' */
  localDW->Integrator_IWORK = 0;
}

/* Derivatives for referenced model: 'plant' */
void plant_Deriv(B_plant_c_T *localB, X_plant_n_T *localX, XDot_plant_n_T
                 *localXdot)
{
  boolean_T lsat;
  boolean_T usat;

  /* Derivatives for Integrator: '<Root>/Integrator' */
  lsat = (localX->vehicle_speed <= -rtP_MAX_SPEED_BACKWARD / 3.6);
  usat = (localX->vehicle_speed >= rtP_MAX_SPEED_FORWARD / 3.6);
  if (((!lsat) && (!usat)) || (lsat && (localB->Gain > 0.0)) || (usat &&
       (localB->Gain < 0.0))) {
    localXdot->vehicle_speed = localB->Gain;
  } else {
    /* in saturation */
    localXdot->vehicle_speed = 0.0;
  }

  /* End of Derivatives for Integrator: '<Root>/Integrator' */
}

/* Model initialize function */
void plant_initialize(const char_T **rt_errorStatus, boolean_T *rt_stopRequested,
                      RTWSolverInfo *rt_solverInfo, const rtTimingBridge
                      *timingBridge, RT_MODEL_plant_T *const plant_M,
                      B_plant_c_T *localB, DW_plant_f_T *localDW)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)plant_M, 0,
                sizeof(RT_MODEL_plant_T));
  plant_M->timingBridge = (timingBridge);

  /* initialize error status */
  rtmSetErrorStatusPointer(plant_M, rt_errorStatus);

  /* initialize stop requested flag */
  rtmSetStopRequestedPtr(plant_M, rt_stopRequested);

  /* initialize RTWSolverInfo */
  plant_M->solverInfo = (rt_solverInfo);

  /* Set the Timing fields to the appropriate data in the RTWSolverInfo */
  rtmSetSimTimeStepPointer(plant_M, rtsiGetSimTimeStepPtr(plant_M->solverInfo));
  plant_M->Timing.stepSize0 = (rtsiGetStepSize(plant_M->solverInfo));

  /* block I/O */
  (void) memset(((void *) localB), 0,
                sizeof(B_plant_c_T));

  /* states (dwork) */
  (void) memset((void *)localDW, 0,
                sizeof(DW_plant_f_T));
}

#ifndef __MW_INTERNAL_SLDV_PS_ANALYSIS__
#ifdef __cplusplus
extern "C"
#else
extern
#endif
unsigned int* __mw_instrum_controller_phits;

#define __MW_INSTRUM_RECORD_HIT_NO_TEST(id) ((void)((++__mw_instrum_controller_phits[id - 1u]) || ((__mw_instrum_controller_phits[id - 1u] = (~0u))!=0)))
#define __MW_INSTRUM_RECORD_HIT(id) (__mw_instrum_controller_phits ? __MW_INSTRUM_RECORD_HIT_NO_TEST(id) : (void) 0)

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_49() \
  __MW_INSTRUM_RECORD_HIT(295U + __mw_instrum_controller_curr_combination_idx_49)

#define __MW_INSTRUM_NODE_51(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(51U), (__mw_instrum_controller_curr_combination_idx_49 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(52U), (__mw_instrum_controller_curr_combination_idx_49 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_55(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(55U), (__mw_instrum_controller_curr_combination_idx_49 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(56U), (0 == 1)))
#define __MW_INSTRUM_NODE_49(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(49U), __MW_INSTRUM_RECORD_COMBINATION_HIT_49(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(50U), __MW_INSTRUM_RECORD_COMBINATION_HIT_49(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_57() \
  __MW_INSTRUM_RECORD_HIT(298U + __mw_instrum_controller_curr_combination_idx_57)

#define __MW_INSTRUM_NODE_59(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(59U), (__mw_instrum_controller_curr_combination_idx_57 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(60U), (__mw_instrum_controller_curr_combination_idx_57 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_63(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(63U), (__mw_instrum_controller_curr_combination_idx_57 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(64U), (0 == 1)))
#define __MW_INSTRUM_NODE_57(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(57U), __MW_INSTRUM_RECORD_COMBINATION_HIT_57(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(58U), __MW_INSTRUM_RECORD_COMBINATION_HIT_57(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_71() \
  __MW_INSTRUM_RECORD_HIT(301U + __mw_instrum_controller_curr_combination_idx_71)

#define __MW_INSTRUM_NODE_73(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(73U), (__mw_instrum_controller_curr_combination_idx_71 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(74U), (__mw_instrum_controller_curr_combination_idx_71 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_78(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(78U), (__mw_instrum_controller_curr_combination_idx_71 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(79U), (0 == 1)))
#define __MW_INSTRUM_NODE_71(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(71U), __MW_INSTRUM_RECORD_COMBINATION_HIT_71(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(72U), __MW_INSTRUM_RECORD_COMBINATION_HIT_71(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_92() \
  __MW_INSTRUM_RECORD_HIT(304U + __mw_instrum_controller_curr_combination_idx_92)

#define __MW_INSTRUM_NODE_94(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(94U), (__mw_instrum_controller_curr_combination_idx_92 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(95U), (__mw_instrum_controller_curr_combination_idx_92 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_96(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(96U), (__mw_instrum_controller_curr_combination_idx_92 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(97U), (0 == 1)))
#define __MW_INSTRUM_NODE_92(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(92U), __MW_INSTRUM_RECORD_COMBINATION_HIT_92(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(93U), __MW_INSTRUM_RECORD_COMBINATION_HIT_92(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_102() \
  __MW_INSTRUM_RECORD_HIT(307U + __mw_instrum_controller_curr_combination_idx_102)

#define __MW_INSTRUM_NODE_104(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(104U), (__mw_instrum_controller_curr_combination_idx_102 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(105U), (__mw_instrum_controller_curr_combination_idx_102 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_110(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(110U), (__mw_instrum_controller_curr_combination_idx_102 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(111U), (0 == 1)))
#define __MW_INSTRUM_NODE_102(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(102U), __MW_INSTRUM_RECORD_COMBINATION_HIT_102(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(103U), __MW_INSTRUM_RECORD_COMBINATION_HIT_102(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_115() \
  __MW_INSTRUM_RECORD_HIT(310U + __mw_instrum_controller_curr_combination_idx_115)

#define __MW_INSTRUM_NODE_117(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(117U), (__mw_instrum_controller_curr_combination_idx_115 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(118U), (__mw_instrum_controller_curr_combination_idx_115 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_124(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(124U), (__mw_instrum_controller_curr_combination_idx_115 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(125U), (0 == 1)))
#define __MW_INSTRUM_NODE_126(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(126U), (__mw_instrum_controller_curr_combination_idx_115 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(127U), (0 == 1)))
#define __MW_INSTRUM_NODE_115(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(115U), __MW_INSTRUM_RECORD_COMBINATION_HIT_115(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(116U), __MW_INSTRUM_RECORD_COMBINATION_HIT_115(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_131() \
  __MW_INSTRUM_RECORD_HIT(314U + __mw_instrum_controller_curr_combination_idx_131)

#define __MW_INSTRUM_NODE_135(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(135U), (__mw_instrum_controller_curr_combination_idx_131 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(136U), (__mw_instrum_controller_curr_combination_idx_131 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_139(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(139U), (__mw_instrum_controller_curr_combination_idx_131 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(140U), (0 == 1)))
#define __MW_INSTRUM_NODE_141(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(141U), (__mw_instrum_controller_curr_combination_idx_131 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(142U), (0 == 1)))
#define __MW_INSTRUM_NODE_131(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(131U), __MW_INSTRUM_RECORD_COMBINATION_HIT_131(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(132U), __MW_INSTRUM_RECORD_COMBINATION_HIT_131(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_148() \
  __MW_INSTRUM_RECORD_HIT(318U + __mw_instrum_controller_curr_combination_idx_148)

#define __MW_INSTRUM_NODE_152(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(152U), (__mw_instrum_controller_curr_combination_idx_148 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(153U), (__mw_instrum_controller_curr_combination_idx_148 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_156(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(156U), (__mw_instrum_controller_curr_combination_idx_148 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(157U), (0 == 1)))
#define __MW_INSTRUM_NODE_158(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(158U), (__mw_instrum_controller_curr_combination_idx_148 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(159U), (0 == 1)))
#define __MW_INSTRUM_NODE_148(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(148U), __MW_INSTRUM_RECORD_COMBINATION_HIT_148(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(149U), __MW_INSTRUM_RECORD_COMBINATION_HIT_148(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_166() \
  __MW_INSTRUM_RECORD_HIT(322U + __mw_instrum_controller_curr_combination_idx_166)

#define __MW_INSTRUM_NODE_168(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(168U), (__mw_instrum_controller_curr_combination_idx_166 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(169U), (__mw_instrum_controller_curr_combination_idx_166 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_170(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(170U), (__mw_instrum_controller_curr_combination_idx_166 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(171U), (0 == 1)))
#define __MW_INSTRUM_NODE_166(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(166U), __MW_INSTRUM_RECORD_COMBINATION_HIT_166(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(167U), __MW_INSTRUM_RECORD_COMBINATION_HIT_166(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_188() \
  __MW_INSTRUM_RECORD_HIT(325U + __mw_instrum_controller_curr_combination_idx_188)

#define __MW_INSTRUM_NODE_190(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(190U), (__mw_instrum_controller_curr_combination_idx_188 = 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(191U), (__mw_instrum_controller_curr_combination_idx_188 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_192(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(192U), (__mw_instrum_controller_curr_combination_idx_188 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(193U), (0 == 1)))
#define __MW_INSTRUM_NODE_188(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(188U), __MW_INSTRUM_RECORD_COMBINATION_HIT_188(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(189U), __MW_INSTRUM_RECORD_COMBINATION_HIT_188(), (0 == 1)))

#define __MW_INSTRUM_RECORD_COMBINATION_HIT_198() \
  __MW_INSTRUM_RECORD_HIT(328U + __mw_instrum_controller_curr_combination_idx_198)

#define __MW_INSTRUM_NODE_202(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(202U), (__mw_instrum_controller_curr_combination_idx_198 = 2U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(203U), (__mw_instrum_controller_curr_combination_idx_198 = 0U), (0 == 1)))
#define __MW_INSTRUM_NODE_204(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(204U), (__mw_instrum_controller_curr_combination_idx_198 += 1U), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(205U), (0 == 1)))
#define __MW_INSTRUM_NODE_198(expr) \
  ((expr) ?\
   (__MW_INSTRUM_RECORD_HIT(198U), __MW_INSTRUM_RECORD_COMBINATION_HIT_198(), (1 == 1)) :\
   (__MW_INSTRUM_RECORD_HIT(199U), __MW_INSTRUM_RECORD_COMBINATION_HIT_198(), (0 == 1)))


#define __MW_INSTRUM_FCN_ENTER_1() 
#define __MW_INSTRUM_FCN_ENTER_2() 
#define __MW_INSTRUM_FCN_ENTER_3() \
  unsigned int __mw_instrum_controller_curr_combination_idx_49 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_57 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_71 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_92 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_102 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_115 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_131 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_148 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_166 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_188 = 0U; \
  unsigned int __mw_instrum_controller_curr_combination_idx_198 = 0U; 
#define __MW_INSTRUM_FCN_ENTER_4() 

#define __MW_INSTRUM_NODE_1() (__MW_INSTRUM_RECORD_HIT(1U))
#define __MW_INSTRUM_NODE_2() (__MW_INSTRUM_RECORD_HIT(2U))
#define __MW_INSTRUM_NODE_3() (__MW_INSTRUM_RECORD_HIT(3U))
#define __MW_INSTRUM_NODE_4() (__MW_INSTRUM_RECORD_HIT(4U))
#define __MW_INSTRUM_NODE_5() (__MW_INSTRUM_RECORD_HIT(5U))
#define __MW_INSTRUM_NODE_6(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(6U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(7U), (0 == 1)))
#define __MW_INSTRUM_NODE_8(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_7() (__MW_INSTRUM_RECORD_HIT(7U))
#define __MW_INSTRUM_NODE_10(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(10U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(11U), (0 == 1)))
#define __MW_INSTRUM_NODE_12(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_14(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(14U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(15U), (0 == 1)))
#define __MW_INSTRUM_NODE_16(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_15() (__MW_INSTRUM_RECORD_HIT(15U))
#define __MW_INSTRUM_NODE_19() (__MW_INSTRUM_RECORD_HIT(19U))
#define __MW_INSTRUM_NODE_20(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(20U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(21U), (0 == 1)))
#define __MW_INSTRUM_NODE_22(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_21() (__MW_INSTRUM_RECORD_HIT(21U))
#define __MW_INSTRUM_NODE_25() (__MW_INSTRUM_RECORD_HIT(25U))
#define __MW_INSTRUM_NODE_26(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(26U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(27U), (0 == 1)))
#define __MW_INSTRUM_NODE_28(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_27() (__MW_INSTRUM_RECORD_HIT(27U))
#define __MW_INSTRUM_NODE_30(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(30U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(31U), (0 == 1)))
#define __MW_INSTRUM_NODE_31() (__MW_INSTRUM_RECORD_HIT(31U))
#define __MW_INSTRUM_NODE_32() (__MW_INSTRUM_RECORD_HIT(32U))
#define __MW_INSTRUM_NODE_33(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(33U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(34U), (0 == 1)))
#define __MW_INSTRUM_NODE_35(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_34() (__MW_INSTRUM_RECORD_HIT(34U))
#define __MW_INSTRUM_NODE_37(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(37U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(38U), (0 == 1)))
#define __MW_INSTRUM_NODE_39(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_41() (__MW_INSTRUM_RECORD_HIT(41U))
#define __MW_INSTRUM_NODE_38() (__MW_INSTRUM_RECORD_HIT(38U))
#define __MW_INSTRUM_NODE_42(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(42U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(43U), (0 == 1)))
#define __MW_INSTRUM_NODE_43() (__MW_INSTRUM_RECORD_HIT(43U))
#define __MW_INSTRUM_NODE_44() (__MW_INSTRUM_RECORD_HIT(44U))
#define __MW_INSTRUM_NODE_45(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(45U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(46U), (0 == 1)))
#define __MW_INSTRUM_NODE_47(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(47U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(48U), (0 == 1)))
#define __MW_INSTRUM_NODE_53(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_50() (__MW_INSTRUM_RECORD_HIT(50U))
#define __MW_INSTRUM_NODE_61(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_58() (__MW_INSTRUM_RECORD_HIT(58U))
#define __MW_INSTRUM_NODE_65() (__MW_INSTRUM_RECORD_HIT(65U))
#define __MW_INSTRUM_NODE_66(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(66U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(67U), (0 == 1)))
#define __MW_INSTRUM_NODE_68(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_67() (__MW_INSTRUM_RECORD_HIT(67U))
#define __MW_INSTRUM_NODE_70() (__MW_INSTRUM_RECORD_HIT(70U))
#define __MW_INSTRUM_NODE_75(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_80(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_72() (__MW_INSTRUM_RECORD_HIT(72U))
#define __MW_INSTRUM_NODE_82(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(82U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(83U), (0 == 1)))
#define __MW_INSTRUM_NODE_84(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_83() (__MW_INSTRUM_RECORD_HIT(83U))
#define __MW_INSTRUM_NODE_87(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(87U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(88U), (0 == 1)))
#define __MW_INSTRUM_NODE_89(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_98(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_100(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(100U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(101U), (0 == 1)))
#define __MW_INSTRUM_NODE_101() (__MW_INSTRUM_RECORD_HIT(101U))
#define __MW_INSTRUM_NODE_88() (__MW_INSTRUM_RECORD_HIT(88U))
#define __MW_INSTRUM_NODE_106(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_108(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(108U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(109U), (0 == 1)))
#define __MW_INSTRUM_NODE_112(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(112U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(113U), (0 == 1)))
#define __MW_INSTRUM_NODE_113() (__MW_INSTRUM_RECORD_HIT(113U))
#define __MW_INSTRUM_NODE_114() (__MW_INSTRUM_RECORD_HIT(114U))
#define __MW_INSTRUM_NODE_119(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_121() (__MW_INSTRUM_RECORD_HIT(121U))
#define __MW_INSTRUM_NODE_122(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(122U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(123U), (0 == 1)))
#define __MW_INSTRUM_NODE_128(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_116() (__MW_INSTRUM_RECORD_HIT(116U))
#define __MW_INSTRUM_NODE_133(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(133U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(134U), (0 == 1)))
#define __MW_INSTRUM_NODE_137(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_143(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_146(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(146U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(147U), (0 == 1)))
#define __MW_INSTRUM_NODE_147() (__MW_INSTRUM_RECORD_HIT(147U))
#define __MW_INSTRUM_NODE_150(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(150U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(151U), (0 == 1)))
#define __MW_INSTRUM_NODE_154(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_160(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_163(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(163U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(164U), (0 == 1)))
#define __MW_INSTRUM_NODE_164() (__MW_INSTRUM_RECORD_HIT(164U))
#define __MW_INSTRUM_NODE_165() (__MW_INSTRUM_RECORD_HIT(165U))
#define __MW_INSTRUM_NODE_172(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_175(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(175U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(176U), (0 == 1)))
#define __MW_INSTRUM_NODE_176() (__MW_INSTRUM_RECORD_HIT(176U))
#define __MW_INSTRUM_NODE_177() (__MW_INSTRUM_RECORD_HIT(177U))
#define __MW_INSTRUM_NODE_178(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(178U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(179U), (0 == 1)))
#define __MW_INSTRUM_NODE_180(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_179() (__MW_INSTRUM_RECORD_HIT(179U))
#define __MW_INSTRUM_NODE_183(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(183U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(184U), (0 == 1)))
#define __MW_INSTRUM_NODE_185(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_194(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_196(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(196U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(197U), (0 == 1)))
#define __MW_INSTRUM_NODE_197() (__MW_INSTRUM_RECORD_HIT(197U))
#define __MW_INSTRUM_NODE_184() (__MW_INSTRUM_RECORD_HIT(184U))
#define __MW_INSTRUM_NODE_200(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(200U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(201U), (0 == 1)))
#define __MW_INSTRUM_NODE_206(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_208(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(208U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(209U), (0 == 1)))
#define __MW_INSTRUM_NODE_209() (__MW_INSTRUM_RECORD_HIT(209U))
#define __MW_INSTRUM_NODE_210(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(210U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(211U), (0 == 1)))
#define __MW_INSTRUM_NODE_212(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_215(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(215U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(216U), (0 == 1)))
#define __MW_INSTRUM_NODE_217(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_216() (__MW_INSTRUM_RECORD_HIT(216U))
#define __MW_INSTRUM_NODE_220() (__MW_INSTRUM_RECORD_HIT(220U))
#define __MW_INSTRUM_NODE_221(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(221U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(222U), (0 == 1)))
#define __MW_INSTRUM_NODE_223(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_222() (__MW_INSTRUM_RECORD_HIT(222U))
#define __MW_INSTRUM_NODE_226(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(226U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(227U), (0 == 1)))
#define __MW_INSTRUM_NODE_228(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_231(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(231U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(232U), (0 == 1)))
#define __MW_INSTRUM_NODE_233(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(233U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(234U), (0 == 1)))
#define __MW_INSTRUM_NODE_235() (__MW_INSTRUM_RECORD_HIT(235U))
#define __MW_INSTRUM_NODE_236() (__MW_INSTRUM_RECORD_HIT(236U))
#define __MW_INSTRUM_NODE_237(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(237U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(238U), (0 == 1)))
#define __MW_INSTRUM_NODE_239(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_238() (__MW_INSTRUM_RECORD_HIT(238U))
#define __MW_INSTRUM_NODE_241(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(241U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(242U), (0 == 1)))
#define __MW_INSTRUM_NODE_243(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_246(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(246U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(247U), (0 == 1)))
#define __MW_INSTRUM_NODE_248(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(248U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(249U), (0 == 1)))
#define __MW_INSTRUM_NODE_242() (__MW_INSTRUM_RECORD_HIT(242U))
#define __MW_INSTRUM_NODE_250(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(250U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(251U), (0 == 1)))
#define __MW_INSTRUM_NODE_252(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_251() (__MW_INSTRUM_RECORD_HIT(251U))
#define __MW_INSTRUM_NODE_254() (__MW_INSTRUM_RECORD_HIT(254U))
#define __MW_INSTRUM_NODE_255(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(255U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(256U), (0 == 1)))
#define __MW_INSTRUM_NODE_257(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_256() (__MW_INSTRUM_RECORD_HIT(256U))
#define __MW_INSTRUM_NODE_260(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(260U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(261U), (0 == 1)))
#define __MW_INSTRUM_NODE_262(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_264(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(264U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(265U), (0 == 1)))
#define __MW_INSTRUM_NODE_266(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(266U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(267U), (0 == 1)))
#define __MW_INSTRUM_NODE_268(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_270(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(270U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(271U), (0 == 1)))
#define __MW_INSTRUM_NODE_272(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(272U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(273U), (0 == 1)))
#define __MW_INSTRUM_NODE_274(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_271() (__MW_INSTRUM_RECORD_HIT(271U))
#define __MW_INSTRUM_NODE_276(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(276U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(277U), (0 == 1)))
#define __MW_INSTRUM_NODE_278(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_277() (__MW_INSTRUM_RECORD_HIT(277U))
#define __MW_INSTRUM_NODE_280(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(280U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(281U), (0 == 1)))
#define __MW_INSTRUM_NODE_282(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_281() (__MW_INSTRUM_RECORD_HIT(281U))
#define __MW_INSTRUM_NODE_265() (__MW_INSTRUM_RECORD_HIT(265U))
#define __MW_INSTRUM_NODE_284(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(284U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(285U), (0 == 1)))
#define __MW_INSTRUM_NODE_286(expr) ((expr) ? (__MW_INSTRUM_RECORD_HIT(286U), (1 == 1)) : (__MW_INSTRUM_RECORD_HIT(287U), (0 == 1)))
#define __MW_INSTRUM_NODE_288(lhs, rhs) ((void)0)
#define __MW_INSTRUM_NODE_285() (__MW_INSTRUM_RECORD_HIT(285U))
#define __MW_INSTRUM_NODE_290() (__MW_INSTRUM_RECORD_HIT(290U))
#define __MW_INSTRUM_NODE_291() (__MW_INSTRUM_RECORD_HIT(291U))
#define __MW_INSTRUM_NODE_292() (__MW_INSTRUM_RECORD_HIT(292U))
#define __MW_INSTRUM_NODE_293() (__MW_INSTRUM_RECORD_HIT(293U))
#define __MW_INSTRUM_NODE_294() (__MW_INSTRUM_RECORD_HIT(294U))
#else /* __MW_INTERNAL_SLDV_PS_ANALYSIS__ */
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_51CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_51(...) (__MW_INSTRUM_RECORD_HIT_51CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_51(exp) (__MW_INSTRUM_RECORD_HIT_51CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_55CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_55(...) (__MW_INSTRUM_RECORD_HIT_55CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_55(exp) (__MW_INSTRUM_RECORD_HIT_55CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_49DA_51_55Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_49(...) (__MW_INSTRUM_RECORD_HIT_49DA_51_55Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_49(exp) (__MW_INSTRUM_RECORD_HIT_49DA_51_55Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_59CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_59(...) (__MW_INSTRUM_RECORD_HIT_59CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_59(exp) (__MW_INSTRUM_RECORD_HIT_59CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_63CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_63(...) (__MW_INSTRUM_RECORD_HIT_63CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_63(exp) (__MW_INSTRUM_RECORD_HIT_63CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_57DA_59_63Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_57(...) (__MW_INSTRUM_RECORD_HIT_57DA_59_63Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_57(exp) (__MW_INSTRUM_RECORD_HIT_57DA_59_63Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_73CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_73(...) (__MW_INSTRUM_RECORD_HIT_73CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_73(exp) (__MW_INSTRUM_RECORD_HIT_73CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_78CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_78(...) (__MW_INSTRUM_RECORD_HIT_78CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_78(exp) (__MW_INSTRUM_RECORD_HIT_78CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_71DA_73_78Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_71(...) (__MW_INSTRUM_RECORD_HIT_71DA_73_78Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_71(exp) (__MW_INSTRUM_RECORD_HIT_71DA_73_78Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_94CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_94(...) (__MW_INSTRUM_RECORD_HIT_94CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_94(exp) (__MW_INSTRUM_RECORD_HIT_94CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_96CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_96(...) (__MW_INSTRUM_RECORD_HIT_96CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_96(exp) (__MW_INSTRUM_RECORD_HIT_96CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_92DA_94_96Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_92(...) (__MW_INSTRUM_RECORD_HIT_92DA_94_96Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_92(exp) (__MW_INSTRUM_RECORD_HIT_92DA_94_96Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_104CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_104(...) (__MW_INSTRUM_RECORD_HIT_104CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_104(exp) (__MW_INSTRUM_RECORD_HIT_104CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_110CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_110(...) (__MW_INSTRUM_RECORD_HIT_110CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_110(exp) (__MW_INSTRUM_RECORD_HIT_110CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_102DA_104N_110Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_102(...) (__MW_INSTRUM_RECORD_HIT_102DA_104N_110Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_102(exp) (__MW_INSTRUM_RECORD_HIT_102DA_104N_110Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_117CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_117(...) (__MW_INSTRUM_RECORD_HIT_117CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_117(exp) (__MW_INSTRUM_RECORD_HIT_117CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_124CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_124(...) (__MW_INSTRUM_RECORD_HIT_124CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_124(exp) (__MW_INSTRUM_RECORD_HIT_124CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_126CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_126(...) (__MW_INSTRUM_RECORD_HIT_126CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_126(exp) (__MW_INSTRUM_RECORD_HIT_126CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_115DA_117A_124_126Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_115(...) (__MW_INSTRUM_RECORD_HIT_115DA_117A_124_126Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_115(exp) (__MW_INSTRUM_RECORD_HIT_115DA_117A_124_126Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_135CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_135(...) (__MW_INSTRUM_RECORD_HIT_135CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_135(exp) (__MW_INSTRUM_RECORD_HIT_135CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_139CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_139(...) (__MW_INSTRUM_RECORD_HIT_139CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_139(exp) (__MW_INSTRUM_RECORD_HIT_139CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_141CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_141(...) (__MW_INSTRUM_RECORD_HIT_141CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_141(exp) (__MW_INSTRUM_RECORD_HIT_141CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_131DAA_135_139_141Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_131(...) (__MW_INSTRUM_RECORD_HIT_131DAA_135_139_141Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_131(exp) (__MW_INSTRUM_RECORD_HIT_131DAA_135_139_141Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_152CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_152(...) (__MW_INSTRUM_RECORD_HIT_152CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_152(exp) (__MW_INSTRUM_RECORD_HIT_152CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_156CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_156(...) (__MW_INSTRUM_RECORD_HIT_156CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_156(exp) (__MW_INSTRUM_RECORD_HIT_156CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_158CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_158(...) (__MW_INSTRUM_RECORD_HIT_158CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_158(exp) (__MW_INSTRUM_RECORD_HIT_158CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_148DAA_152_156_158Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_148(...) (__MW_INSTRUM_RECORD_HIT_148DAA_152_156_158Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_148(exp) (__MW_INSTRUM_RECORD_HIT_148DAA_152_156_158Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_168CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_168(...) (__MW_INSTRUM_RECORD_HIT_168CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_168(exp) (__MW_INSTRUM_RECORD_HIT_168CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_170CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_170(...) (__MW_INSTRUM_RECORD_HIT_170CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_170(exp) (__MW_INSTRUM_RECORD_HIT_170CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_166DA_168_170Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_166(...) (__MW_INSTRUM_RECORD_HIT_166DA_168_170Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_166(exp) (__MW_INSTRUM_RECORD_HIT_166DA_168_170Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_190CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_190(...) (__MW_INSTRUM_RECORD_HIT_190CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_190(exp) (__MW_INSTRUM_RECORD_HIT_190CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_192CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_192(...) (__MW_INSTRUM_RECORD_HIT_192CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_192(exp) (__MW_INSTRUM_RECORD_HIT_192CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_188DA_190_192Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_188(...) (__MW_INSTRUM_RECORD_HIT_188DA_190_192Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_188(exp) (__MW_INSTRUM_RECORD_HIT_188DA_190_192Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_202CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_202(...) (__MW_INSTRUM_RECORD_HIT_202CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_202(exp) (__MW_INSTRUM_RECORD_HIT_202CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_204CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_204(...) (__MW_INSTRUM_RECORD_HIT_204CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_204(exp) (__MW_INSTRUM_RECORD_HIT_204CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif
#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_198DAN_202_204Z_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_198(...) (__MW_INSTRUM_RECORD_HIT_198DAN_202_204Z_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_198(exp) (__MW_INSTRUM_RECORD_HIT_198DAN_202_204Z_controller_0020_0028ModelRefSIL_0029(exp))
#endif


#define __MW_INSTRUM_FCN_ENTER_1() 

#define __MW_INSTRUM_FCN_ENTER_2() 

#define __MW_INSTRUM_FCN_ENTER_3() 

#define __MW_INSTRUM_FCN_ENTER_4() 

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_1EZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_1() __MW_INSTRUM_RECORD_HIT_1EZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_2XZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_2() __MW_INSTRUM_RECORD_HIT_2XZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_3EZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_3() __MW_INSTRUM_RECORD_HIT_3EZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_4XZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_4() __MW_INSTRUM_RECORD_HIT_4XZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_5EZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_5() __MW_INSTRUM_RECORD_HIT_5EZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_6DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_6(...) (__MW_INSTRUM_RECORD_HIT_6DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_6(exp) (__MW_INSTRUM_RECORD_HIT_6DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_8FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_8(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_8FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_7() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_10DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_10(...) (__MW_INSTRUM_RECORD_HIT_10DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_10(exp) (__MW_INSTRUM_RECORD_HIT_10DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_12FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_12(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_12FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_14DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_14(...) (__MW_INSTRUM_RECORD_HIT_14DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_14(exp) (__MW_INSTRUM_RECORD_HIT_14DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_16IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_16(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_15() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_19DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_19() __MW_INSTRUM_RECORD_HIT_19DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_20DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_20(...) (__MW_INSTRUM_RECORD_HIT_20DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_20(exp) (__MW_INSTRUM_RECORD_HIT_20DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_22IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_22(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_21() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_25DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_25() __MW_INSTRUM_RECORD_HIT_25DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_26DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_26(...) (__MW_INSTRUM_RECORD_HIT_26DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_26(exp) (__MW_INSTRUM_RECORD_HIT_26DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_28FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_28(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_28FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_27() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_30DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_30(...) (__MW_INSTRUM_RECORD_HIT_30DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_30(exp) (__MW_INSTRUM_RECORD_HIT_30DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_31() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_32DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_32() __MW_INSTRUM_RECORD_HIT_32DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_33DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_33(...) (__MW_INSTRUM_RECORD_HIT_33DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_33(exp) (__MW_INSTRUM_RECORD_HIT_33DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_35FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_35(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_35FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_34() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_37DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_37(...) (__MW_INSTRUM_RECORD_HIT_37DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_37(exp) (__MW_INSTRUM_RECORD_HIT_37DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_39FLEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_39(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_39FLEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_41() ((void)0)


#define __MW_INSTRUM_NODE_38() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_42DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_42(...) (__MW_INSTRUM_RECORD_HIT_42DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_42(exp) (__MW_INSTRUM_RECORD_HIT_42DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_43() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_44DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_44() __MW_INSTRUM_RECORD_HIT_44DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_45CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_45(...) (__MW_INSTRUM_RECORD_HIT_45CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_45(exp) (__MW_INSTRUM_RECORD_HIT_45CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_47CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_47(...) (__MW_INSTRUM_RECORD_HIT_47CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_47(exp) (__MW_INSTRUM_RECORD_HIT_47CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_53FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_53(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_53FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_50() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_61FLEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_61(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_61FLEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_58() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_65DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_65() __MW_INSTRUM_RECORD_HIT_65DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_66DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_66(...) (__MW_INSTRUM_RECORD_HIT_66DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_66(exp) (__MW_INSTRUM_RECORD_HIT_66DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_68FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_68(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_68FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_67() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_70DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_70() __MW_INSTRUM_RECORD_HIT_70DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_75IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_75(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_80FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_80(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_80FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_72() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_82DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_82(...) (__MW_INSTRUM_RECORD_HIT_82DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_82(exp) (__MW_INSTRUM_RECORD_HIT_82DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_84IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_84(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_83() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_87DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_87(...) (__MW_INSTRUM_RECORD_HIT_87DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_87(exp) (__MW_INSTRUM_RECORD_HIT_87DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_89IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_89(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_98FEQZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_98(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_98FEQZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_100DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_100(...) (__MW_INSTRUM_RECORD_HIT_100DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_100(exp) (__MW_INSTRUM_RECORD_HIT_100DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_101() ((void)0)


#define __MW_INSTRUM_NODE_88() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_106FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_106(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_106FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_108CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_108(...) (__MW_INSTRUM_RECORD_HIT_108CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_108(exp) (__MW_INSTRUM_RECORD_HIT_108CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_112DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_112(...) (__MW_INSTRUM_RECORD_HIT_112DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_112(exp) (__MW_INSTRUM_RECORD_HIT_112DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_113() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_114DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_114() __MW_INSTRUM_RECORD_HIT_114DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_119FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_119(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_119FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_121() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_122CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_122(...) (__MW_INSTRUM_RECORD_HIT_122CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_122(exp) (__MW_INSTRUM_RECORD_HIT_122CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_128IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_128(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_116() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_133CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_133(...) (__MW_INSTRUM_RECORD_HIT_133CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_133(exp) (__MW_INSTRUM_RECORD_HIT_133CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_137FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_137(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_137FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_143IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_143(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_146DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_146(...) (__MW_INSTRUM_RECORD_HIT_146DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_146(exp) (__MW_INSTRUM_RECORD_HIT_146DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_147() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_150CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_150(...) (__MW_INSTRUM_RECORD_HIT_150CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_150(exp) (__MW_INSTRUM_RECORD_HIT_150CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_154FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_154(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_154FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_160IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_160(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_163DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_163(...) (__MW_INSTRUM_RECORD_HIT_163DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_163(exp) (__MW_INSTRUM_RECORD_HIT_163DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_164() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_165DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_165() __MW_INSTRUM_RECORD_HIT_165DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_172IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_172(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_175DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_175(...) (__MW_INSTRUM_RECORD_HIT_175DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_175(exp) (__MW_INSTRUM_RECORD_HIT_175DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_176() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_177DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_177() __MW_INSTRUM_RECORD_HIT_177DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_178DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_178(...) (__MW_INSTRUM_RECORD_HIT_178DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_178(exp) (__MW_INSTRUM_RECORD_HIT_178DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_180IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_180(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_179() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_183DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_183(...) (__MW_INSTRUM_RECORD_HIT_183DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_183(exp) (__MW_INSTRUM_RECORD_HIT_183DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_185IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_185(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_194FEQZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_194(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_194FEQZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_196DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_196(...) (__MW_INSTRUM_RECORD_HIT_196DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_196(exp) (__MW_INSTRUM_RECORD_HIT_196DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_197() ((void)0)


#define __MW_INSTRUM_NODE_184() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_200CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_200(...) (__MW_INSTRUM_RECORD_HIT_200CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_200(exp) (__MW_INSTRUM_RECORD_HIT_200CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_206FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_206(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_206FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_208DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_208(...) (__MW_INSTRUM_RECORD_HIT_208DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_208(exp) (__MW_INSTRUM_RECORD_HIT_208DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_209() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_210DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_210(...) (__MW_INSTRUM_RECORD_HIT_210DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_210(exp) (__MW_INSTRUM_RECORD_HIT_210DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_212IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_212(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_215DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_215(...) (__MW_INSTRUM_RECORD_HIT_215DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_215(exp) (__MW_INSTRUM_RECORD_HIT_215DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_217IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_217(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_216() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_220DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_220() __MW_INSTRUM_RECORD_HIT_220DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_221DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_221(...) (__MW_INSTRUM_RECORD_HIT_221DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_221(exp) (__MW_INSTRUM_RECORD_HIT_221DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_223IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_223(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_222() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_226DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_226(...) (__MW_INSTRUM_RECORD_HIT_226DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_226(exp) (__MW_INSTRUM_RECORD_HIT_226DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_228IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_228(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_231CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_231(...) (__MW_INSTRUM_RECORD_HIT_231CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_231(exp) (__MW_INSTRUM_RECORD_HIT_231CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_233CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_233(...) (__MW_INSTRUM_RECORD_HIT_233CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_233(exp) (__MW_INSTRUM_RECORD_HIT_233CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_235DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_235() __MW_INSTRUM_RECORD_HIT_235DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_236DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_236() __MW_INSTRUM_RECORD_HIT_236DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_237DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_237(...) (__MW_INSTRUM_RECORD_HIT_237DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_237(exp) (__MW_INSTRUM_RECORD_HIT_237DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_239FNEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_239(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_239FNEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_238() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_241DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_241(...) (__MW_INSTRUM_RECORD_HIT_241DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_241(exp) (__MW_INSTRUM_RECORD_HIT_241DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_243IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_243(lhs, rhs)(void)0

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_246CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_246(...) (__MW_INSTRUM_RECORD_HIT_246CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_246(exp) (__MW_INSTRUM_RECORD_HIT_246CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_248CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_248(...) (__MW_INSTRUM_RECORD_HIT_248CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_248(exp) (__MW_INSTRUM_RECORD_HIT_248CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#define __MW_INSTRUM_NODE_242() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_250DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_250(...) (__MW_INSTRUM_RECORD_HIT_250DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_250(exp) (__MW_INSTRUM_RECORD_HIT_250DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_252FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_252(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_252FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_251() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_254DZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_254() __MW_INSTRUM_RECORD_HIT_254DZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_255DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_255(...) (__MW_INSTRUM_RECORD_HIT_255DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_255(exp) (__MW_INSTRUM_RECORD_HIT_255DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_257IZ_controller_0020_0028ModelRefSIL_0029(int out1, int out2, int out3) { }
#define __MW_INSTRUM_NODE_257(lhs, rhs)(void)0

#define __MW_INSTRUM_NODE_256() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_260DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_260(...) (__MW_INSTRUM_RECORD_HIT_260DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_260(exp) (__MW_INSTRUM_RECORD_HIT_260DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_262FEQZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_262(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_262FEQZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_264DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_264(...) (__MW_INSTRUM_RECORD_HIT_264DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_264(exp) (__MW_INSTRUM_RECORD_HIT_264DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_266CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_266(...) (__MW_INSTRUM_RECORD_HIT_266CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_266(exp) (__MW_INSTRUM_RECORD_HIT_266CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_268FNEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_268(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_268FNEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_270DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_270(...) (__MW_INSTRUM_RECORD_HIT_270DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_270(exp) (__MW_INSTRUM_RECORD_HIT_270DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_272CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_272(...) (__MW_INSTRUM_RECORD_HIT_272CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_272(exp) (__MW_INSTRUM_RECORD_HIT_272CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_274FNEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_274(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_274FNEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_271() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_276DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_276(...) (__MW_INSTRUM_RECORD_HIT_276DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_276(exp) (__MW_INSTRUM_RECORD_HIT_276DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_278FGTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_278(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_278FGTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_277() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_280DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_280(...) (__MW_INSTRUM_RECORD_HIT_280DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_280(exp) (__MW_INSTRUM_RECORD_HIT_280DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_282FLTZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_282(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_282FLTZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_281() ((void)0)


#define __MW_INSTRUM_NODE_265() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_284DZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_284(...) (__MW_INSTRUM_RECORD_HIT_284DZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_284(exp) (__MW_INSTRUM_RECORD_HIT_284DZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
int __MW_INSTRUM_RECORD_HIT_286CZ_controller_0020_0028ModelRefSIL_0029(int condValue) { return condValue; }
#ifdef __cplusplus
#define __MW_INSTRUM_NODE_286(...) (__MW_INSTRUM_RECORD_HIT_286CZ_controller_0020_0028ModelRefSIL_0029(__VA_ARGS__))
#else
#define __MW_INSTRUM_NODE_286(exp) (__MW_INSTRUM_RECORD_HIT_286CZ_controller_0020_0028ModelRefSIL_0029(exp))
#endif

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_288FNEZ_controller_0020_0028ModelRefSIL_0029(double lhs, double rhs) { }
#define __MW_INSTRUM_NODE_288(lhs, rhs) (__MW_INSTRUM_RECORD_HIT_288FNEZ_controller_0020_0028ModelRefSIL_0029(lhs, rhs))

#define __MW_INSTRUM_NODE_285() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_290XZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_290() __MW_INSTRUM_RECORD_HIT_290XZ_controller_0020_0028ModelRefSIL_0029()

#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_291EZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_291() __MW_INSTRUM_RECORD_HIT_291EZ_controller_0020_0028ModelRefSIL_0029()

#define __MW_INSTRUM_NODE_292() ((void)0)


#define __MW_INSTRUM_NODE_293() ((void)0)


#ifdef __cplusplus
extern "C"
#else
extern
#endif
void __MW_INSTRUM_RECORD_HIT_294XZ_controller_0020_0028ModelRefSIL_0029(void) { }
#define __MW_INSTRUM_NODE_294() __MW_INSTRUM_RECORD_HIT_294XZ_controller_0020_0028ModelRefSIL_0029()


#endif /* __MW_INTERNAL_SLDV_PS_ANALYSIS__ */

#line 1 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\controller\\controller.c"
#line 7 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\controller\\controller.h"
#ifndef RTW_HEADER_controller_h_
#define RTW_HEADER_controller_h_
#ifndef controller_COMMON_INCLUDES_
#define controller_COMMON_INCLUDES_
#line 15 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\_sharedutils\\rtwtypes.h"
#ifndef RTWTYPES_H
#define RTWTYPES_H
#line 12 "C:\\Program Files\\MATLAB\\R2022b\\extern\\include\\tmwtypes.h"
#ifndef tmwtypes_h
#define tmwtypes_h

#ifndef __TMWTYPES__
#define __TMWTYPES__
#line 4 "C:\\Program Files\\MATLAB\\R2022b\\sys\\lcc64\\lcc64\\include64\\limits.h"
#ifndef MB_LEN_MAX
#define MB_LEN_MAX 2
#endif /* MB_LEN_MAX */
#line 2 "C:\\Program Files\\MATLAB\\R2022b\\sys\\lcc64\\lcc64\\include64\\float.h"
#ifndef __float_h__
#define __float_h__
#line 24
extern int __fltrounds(void); 
#line 163
double _chgsign(double); 
double _copysign(double, double); 
double _logb(double); 
double _nextafter(double, double); 
double _scalb(double, long); 
extern int *__fpecode(void); 
int _finite(double); 
int _fpclass(double); 
int _isnan(double); 
unsigned _clearfp(void); 
unsigned _controlfp(unsigned, unsigned); 
unsigned _statusfp(void); 
unsigned _control87(unsigned, unsigned); 
void _fpreset(void); 
#line 185
typedef 
#line 178
struct { 
unsigned mantissa1; 
unsigned mantissa0:31; 
unsigned one:1; 
unsigned exponent:15; 
unsigned negative:1; 
unsigned empty:16; 
} _longDouble; 
#line 191
typedef 
#line 186
struct { 
unsigned mantissa1; 
unsigned mantissa0:20; 
unsigned exponent:11; 
unsigned sign:1; 
} _Double; 
#line 197
typedef 
#line 193
struct { 
unsigned mantissa:23; 
unsigned exponent:8; 
unsigned sign:1; 
} _Float; 
#line 211
#endif /* __float_h__ */
#line 89 "C:\\Program Files\\MATLAB\\R2022b\\extern\\include\\tmwtypes.h"
typedef unsigned char uchar_T; 
typedef unsigned short ushort_T; 
typedef unsigned long ulong_T; 
#line 97
typedef unsigned long long ulonglong_T; 
#line 222
typedef char int8_T; 
#line 239
typedef unsigned char uint8_T; 
#line 257
typedef short int16_T; 
#line 275
typedef unsigned short uint16_T; 
#line 293
typedef int int32_T; 
#line 311
typedef unsigned uint32_T; 
#line 372
typedef float real32_T; 
#line 386
typedef double real64_T; 
#line 447
#ifndef INT64_T
#define INT64_T long long
#endif /* INT64_T */
#ifndef UINT64_T
#define UINT64_T unsigned long long
#endif /* UINT64_T */
#ifndef FMT64
#define FMT64 "ll"
#endif /* FMT64 */
#line 465
typedef long long int64_T; 
#line 479
typedef unsigned long long uint64_T; 
#line 535
typedef real64_T real_T; 
#line 544
typedef real_T time_T; 
#line 556
typedef unsigned char boolean_T; 


#ifndef CHARACTER_T
#define CHARACTER_T char
#endif /* CHARACTER_T */
typedef char char_T; 


#ifndef INTEGER_T
#define INTEGER_T int
#endif /* INTEGER_T */
typedef int int_T; 


#ifndef UINTEGER_T
#define UINTEGER_T unsigned
#endif /* UINTEGER_T */
typedef unsigned uint_T; 


#ifndef BYTE_T
#define BYTE_T unsigned char
#endif /* BYTE_T */
typedef unsigned char byte_T; 
#line 592
typedef 
#line 590
struct { 
real32_T re, im; 
} creal32_T; 
#line 601
typedef 
#line 599
struct { 
real64_T re, im; 
} creal64_T; 
#line 610
typedef 
#line 608
struct { 
real_T re, im; 
} creal_T; 
#line 621
typedef 
#line 619
struct { 
int8_T re, im; 
} cint8_T; 
#line 630
typedef 
#line 628
struct { 
uint8_T re, im; 
} cuint8_T; 
#line 639
typedef 
#line 637
struct { 
int16_T re, im; 
} cint16_T; 
#line 648
typedef 
#line 646
struct { 
uint16_T re, im; 
} cuint16_T; 
#line 657
typedef 
#line 655
struct { 
int32_T re, im; 
} cint32_T; 
#line 666
typedef 
#line 664
struct { 
uint32_T re, im; 
} cuint32_T; 
#line 675
typedef 
#line 673
struct { 
int64_T re, im; 
} cint64_T; 
#line 684
typedef 
#line 682
struct { 
uint64_T re, im; 
} cuint64_T; 
#line 794
#ifndef _bool_T
#define _bool_T

typedef boolean_T bool; 

#ifndef false
#define false (0)
#endif /* false */
#ifndef true
#define true (1)
#endif /* true */

#endif /* _bool_T */
#line 1 "C:\\Program Files\\MATLAB\\R2022b\\sys\\lcc64\\lcc64\\include64\\stddef.h"
#ifndef __STDDEF_H
#define __STDDEF_H
#ifndef _SIZE_T_DEFINED
#define _SIZE_T_DEFINED
#line 4
typedef unsigned long long size_t; 

#endif /* _SIZE_T_DEFINED */
typedef long long ptrdiff_t; 

#ifndef NULL
#define NULL (void *)0
#endif /* NULL */
#ifndef _RSIZE_T_DEFINED
#define _RSIZE_T_DEFINED
typedef size_t rsize_t; 
#endif /* _RSIZE_T_DEFINED */
#endif /* __STDDEF_H */
#line 834 "C:\\Program Files\\MATLAB\\R2022b\\extern\\include\\tmwtypes.h"
typedef size_t mwSize; 
typedef size_t mwIndex; 
typedef ptrdiff_t mwSignedIndex; 





#ifndef SLSIZE_SLINDEX
#define SLSIZE_SLINDEX

typedef int64_T SLIndex; 
typedef int64_T SLSize; 




#endif /* SLSIZE_SLINDEX */
#line 883
typedef unsigned short CHAR16_T; 


#endif /* __TMWTYPES__ */

#endif /* tmwtypes_h */
#line 18 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\_sharedutils\\rtwtypes.h"
#ifndef POINTER_T
#define POINTER_T

typedef void *pointer_T; 

#endif /* POINTER_T */
#line 35
#endif /* RTWTYPES_H */
#line 11 "C:\\Program Files\\MATLAB\\R2022b\\simulink\\include\\rtw_continuous.h"
#ifndef RTW_CONTINUOUS_H__
#define RTW_CONTINUOUS_H__
#line 26
typedef 
#line 21
enum { 
SS_MATRIX_NONE, 
SS_MATRIX_CONSTANT, 
SS_MATRIX_TIMEDEP, 
SS_MATRIX_STATEDEP
} ssMatrixType; 
#line 33
typedef 
#line 28
enum { 
SOLVER_MODE_AUTO, 

SOLVER_MODE_SINGLETASKING, 
SOLVER_MODE_MULTITASKING
} SolverMode; 

typedef enum { MINOR_TIME_STEP, MAJOR_TIME_STEP} SimTimeStep; 
#line 41
typedef void (*rtMdlInitializeSizesFcn)(void * rtModel); 
typedef void (*rtMdlInitializeSampleTimesFcn)(void * rtModel); 
typedef void (*rtMdlStartFcn)(void * rtModel); 
typedef void (*rtMdlOutputsFcn)(void * rtModel, int_T tid); 
typedef void (*rtMdlUpdateFcn)(void * rtModel, int_T tid); 
typedef void (*rtMdlDerivativesFcn)(void * rtModel); 
typedef void (*rtMdlProjectionFcn)(void * rtModel); 
typedef void (*rtMdlMassMatrixFcn)(void * rtModel); 
typedef void (*rtMdlForcingFunctionFcn)(void * rtModel); 
typedef void (*rtMdlTerminateFcn)(void * rtModel); 
#line 74
typedef 
#line 59
struct _RTWRTModelMethodsInfo_tag { 
void *rtModelPtr; 
rtMdlInitializeSizesFcn rtmInitSizesFcn; 
rtMdlInitializeSampleTimesFcn rtmInitSampTimesFcn; 
rtMdlStartFcn rtmStartFcn; 
rtMdlOutputsFcn rtmOutputsFcn; 
rtMdlUpdateFcn rtmUpdateFcn; 
rtMdlDerivativesFcn rtmDervisFcn; 
rtMdlProjectionFcn rtmProjectionFcn; 
rtMdlMassMatrixFcn rtmMassMatrixFcn; 
rtMdlForcingFunctionFcn rtmForcingFunctionFcn; 
rtMdlTerminateFcn rtmTerminateFcn; 



} RTWRTModelMethodsInfo; 
#line 109
#endif /* RTW_CONTINUOUS_H__ */
#line 11 "C:\\Program Files\\MATLAB\\R2022b\\simulink\\include\\rtw_solver.h"
#ifndef RTW_SOLVER_H__
#define RTW_SOLVER_H__
#line 29
typedef 
#line 24
enum { 
SL_SOLVER_TOLERANCE_AUTO, 
SL_SOLVER_TOLERANCE_LOCAL, 
SL_SOLVER_TOLERANCE_GLOBAL, 
SL_SOLVER_TOLERANCE_UNDEFINED = 255
} SL_SolverToleranceControlFlag_T; 
#line 41
typedef 
#line 35
enum { 
SL_JM_BD_AUTO, 
SL_JM_BD_SPARSE_PERTURBATION, 
SL_JM_BD_FULL_PERTURBATION, 
SL_JM_BD_SPARSE_ANALYTICAL, 
SL_JM_BD_FULL_ANALYTICAL
} slJmBdControl; 
#line 124
typedef 
#line 44
struct _ssSolverInfo_tag { 
void *rtModelPtr; 

SimTimeStep *simTimeStepPtr; 
void *solverData; 
const char_T *solverName; 
boolean_T isVariableStepSolver; 
boolean_T solverNeedsReset; 
SolverMode solverMode; 

time_T solverStopTime; 
time_T *stepSizePtr; 
time_T minStepSize; 
time_T maxStepSize; 
time_T fixedStepSize; 

int_T solverShapePreserveControl; 
int_T solverMaxConsecutiveMinStep; 
int_T maxNumMinSteps; 
int_T solverMaxOrder; 
real_T solverConsecutiveZCsStepRelTol; 
int_T solverMaxConsecutiveZCs; 

int_T solverExtrapolationOrder; 
int_T solverNumberNewtonIterations; 

int_T solverRefineFactor; 
real_T solverRelTol; 
real_T unused_real_T_1; 

real_T **dXPtr; 
time_T **tPtr; 

int_T *numContStatesPtr; 
real_T **contStatesPtr; 

int_T *numPeriodicContStatesPtr; 
int_T **periodicContStateIndicesPtr; 
real_T **periodicContStateRangesPtr; 

real_T *zcSignalVector; 
uint8_T *zcEventsVector; 
uint8_T *zcSignalAttrib; 
int_T zcSignalVectorLength; 
uint8_T *reserved; 

boolean_T foundContZcEvents; 
boolean_T isAtLeftPostOfContZcEvent; 
boolean_T isAtRightPostOfContZcEvent; 
boolean_T adaptiveZcDetection; 

int_T numZcSignals; 

boolean_T stateProjection; 
boolean_T robustResetMethod; 
boolean_T updateJacobianAtReset; 
boolean_T consistencyChecking; 

ssMatrixType massMatrixType; 
int_T massMatrixNzMax; 
int_T *massMatrixIr; 
int_T *massMatrixJc; 
real_T *massMatrixPr; 

const char_T **errStatusPtr; 

RTWRTModelMethodsInfo *modelMethodsPtr; 
real_T zcThreshold; 
int_T reserved_1; 
int_T consecutiveZCsError; 
boolean_T CTOutputIncnstWithState; 
boolean_T isComputingJacobian; 
slJmBdControl solverJacobianMethodControl; 
int_T ignoredZcDiagnostic; 
int_T maskedZcDiagnostic; 
boolean_T isOutputMethodComputed; 
int_T maxZcBracketingIterations; 
boolean_T isMinorTimeStepWithModeChange; 
int_T maxZcPerStep; 
real_T **zcSignalPtr; 
} ssSolverInfo; 


typedef ssSolverInfo RTWSolverInfo; 
#line 292
#endif /* RTW_SOLVER_H__ */
#line 14 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\controller\\controller.h"
#endif /* controller_COMMON_INCLUDES_ */
#line 21 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\controller\\controller_types.h"
#ifndef RTW_HEADER_controller_types_h_
#define RTW_HEADER_controller_types_h_

#ifndef DEFINED_TYPEDEF_FOR_TransmissionState_
#define DEFINED_TYPEDEF_FOR_TransmissionState_
#line 33
typedef 
#line 27
enum { 
Park, 
Reverse, 
Neutral, 
Drive, 
Brake
} TransmissionState; 

#endif /* DEFINED_TYPEDEF_FOR_TransmissionState_ */


typedef struct P_controller_T_ P_controller_T; 


typedef struct tag_RTM_controller_T RT_MODEL_controller_T; 

#endif /* RTW_HEADER_controller_types_h_ */
#line 2 "C:\\Program Files\\MATLAB\\R2022b\\sys\\lcc64\\lcc64\\include64\\string.h"
#ifndef __string_h__
#define __string_h__
#line 11
void *memchr(const void *, int, size_t); 

short *memshort(const short *, short, size_t); 
unsigned short *memushort(const unsigned short *, unsigned short, size_t); 
int *memint(const int *, int, size_t); 
unsigned *memuint(const unsigned *, unsigned, size_t); 
long long *memll(const long long *, long long, size_t); 
unsigned long long *memull(const unsigned long long *, unsigned long long, size_t); 
char *strupr(char *); 
char *strlwr(char *); 
char *strnupr(char *, size_t); 
char *strnlwr(char *, size_t); 
int strtrim(char *); 
char *strrev(char *); 

int memcmp(const void *, const void *, size_t); 
void *memcpy(void *, const void *, size_t); 
void *mempcpy(void *, const void *, size_t); 
void *memmove(void *, const void *, size_t); 
void *memset(void *, int, size_t); 
char *strcat(char *, const char *); 
char *strchr(const char *, int); 
int strcmp(const char *, const char *); 
int strcoll(const char *, const char *); 
char *strcpy(char *, const char *); 
unsigned strlcpy(char * destination, const char * source, unsigned bufsize); 
size_t strcspn(const char *, const char *); 
char *strerror(int); 
size_t strlen(const char *); 
size_t strnlen_s(const char *, size_t); 
char *strncat(char *, const char *, size_t); 
unsigned strlcat(char * destination, const char * source, unsigned bufsize); 
int strncmp(const char *, const char *, size_t); 
char *strncpy(char *, const char *, size_t); 
char *strpbrk(const char *, const char *); 
char *strrchr(const char *, int); 
size_t strspn(const char *, const char *); 
char *strstr(const char *, const char *); 
char *stristr(const char *, const char *); 
char *strtok(char *, const char *); 
void *memccpy(void *, const void *, int, size_t); 
void *_memccpy(void *, void *, unsigned); 
char *strdup(const char *); 
char *strndup(const char *, size_t siz); 
int strnicmp(const char *, const char *, size_t); 
void swab(const char *, char *, size_t); 
int stricmp(const char *, const char *); 
char *_strset(char *, int); 
int strcmpi(const char *, const char *); 

int _memicmp(const void *, const void *, size_t); 
int strrepl(char * InputString, char * StringToFind, char * Replacement, char * OutputString); 
int strtobase64(char * dst, size_t destsiz, unsigned char * src, size_t srcsiz); 
int strfrombase64(char * dst, size_t destsiz, unsigned char * src, size_t srcsiz); 
#line 1 "C:\\Program Files\\MATLAB\\R2022b\\sys\\lcc64\\lcc64\\include64\\safelib.h"
#ifndef __safelib_h__
#define __safelib_h__
int ConstraintFailed(const char * fn, const char * reason, void * reserved); 

#ifndef _ERRNO_T_DEFINED
#define _ERRNO_T_DEFINED
#line 6
typedef int errno_t; 

#endif /* _ERRNO_T_DEFINED */





#endif /* __safelib_h__ */
#line 68 "C:\\Program Files\\MATLAB\\R2022b\\sys\\lcc64\\lcc64\\include64\\string.h"
errno_t memmove_s(void * s1, rsize_t s1max, const void * s2, rsize_t n); 
errno_t strcpy_s(char *restrict s1, rsize_t s1max, const char *restrict s2); 
errno_t strcat_s(char *restrict s1, rsize_t s1max, const char *restrict s2); 
char *strtok_s(char *restrict s1, rsize_t *restrict s1max, const char *restrict s2, char **restrict ptr); 
errno_t memcpy_s(void *restrict s1, rsize_t s1max, const void *restrict s2, rsize_t n); 
errno_t strerror_s(char * s, rsize_t maxsize, errno_t errnum); 
size_t strnlen_s(const char * s, size_t maxsize); 
size_t strerrorlen_s(errno_t errnum); 
errno_t strerror_s(char * s, rsize_t maxsize, errno_t errnum); 
errno_t strncpy_s(char *restrict s1, rsize_t s1max, const char *restrict s2, rsize_t n); 
errno_t strncpy_s(char *restrict s1, rsize_t s1max, const char *restrict s2, rsize_t n); 
errno_t strncat_s(char *restrict s1, rsize_t s1max, const char *restrict s2, rsize_t n); 
errno_t strerror_s(char * s, rsize_t maxsize, errno_t errnum); 

#endif /* __string_h__ */
#line 26 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\controller\\controller.h"
typedef 
#line 20
struct { 
real_T TargetSpeed_km_h; 
real32_T TorqueRequest_Nm; 
real32_T TorqueRequest_Nm_e; 
real32_T StoppedControllerMode; 
int32_T AutomaticTransmissionState; 
} B_controller_c_T; 
#line 38
typedef 
#line 29
struct { 
uint8_T is_c1_controller; 
uint8_T is_active_c1_controller; 
uint8_T temporalCounter_i1; 
uint8_T is_c3_controller; 
uint8_T is_Reverse; 
uint8_T is_Drive; 
uint8_T is_Brake; 
uint8_T is_active_c3_controller; 
} DW_controller_f_T; 


struct P_controller_T_ { 
real_T Gain_Gain; 


real_T Saturation1_UpperSat; 


real_T Saturation1_LowerSat; 


real32_T Saturation_UpperSat; 


real32_T Saturation_LowerSat; 


}; 


struct tag_RTM_controller_T { 
const char_T **errorStatus; 
}; 
#line 68
typedef 
#line 64
struct { 
B_controller_c_T rtb; 
DW_controller_f_T rtdw; 
RT_MODEL_controller_T rtm; 
} MdlrefDW_controller_T; 


extern real_T rtP_MAX_TORQUE; 


extern real_T rtP_MAX_TORQUE_REVERSE; 




extern void controller_initialize(const char_T ** rt_errorStatus, RT_MODEL_controller_T *const controller_M, B_controller_c_T * localB, DW_controller_f_T * localDW); 


extern void controller_Init(real32_T * rty_Error, B_controller_c_T * localB, DW_controller_f_T * localDW); 

extern void controller_Reset(real32_T * rty_Error, B_controller_c_T * localB, DW_controller_f_T * localDW); 

extern void controller(const boolean_T * rtu_BrakePedalPressed, const real32_T * rtu_ThrottlePedalPosition, const TransmissionState * rtu_AutomaticTransmissionSelect, const boolean_T * rtu_BrakePedalPressed_Backup, const real32_T * rtu_ThrottlePedalPosition_Backu, const real32_T * rtu_VehicleSpeed_km_h, real32_T * rty_TorqueRequest_Nm, TransmissionState * rty_AutomaticTransmissionState, real32_T * rty_Error, B_controller_c_T * localB, DW_controller_f_T * localDW); 
#line 112
#endif /* RTW_HEADER_controller_h_ */
#line 21 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\controller\\controller_private.h"
#ifndef RTW_HEADER_controller_private_h_
#define RTW_HEADER_controller_private_h_
#line 15 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\_sharedutils\\multiword_types.h"
#ifndef MULTIWORD_TYPES_H
#define MULTIWORD_TYPES_H





typedef long long_T; 
#line 29
typedef 
#line 27
struct { 
uint32_T chunks[2]; 
} int64m_T; 




typedef 
#line 31
struct { 
int64m_T re; 
int64m_T im; 
} cint64m_T; 



typedef 
#line 36
struct { 
uint32_T chunks[2]; 
} uint64m_T; 




typedef 
#line 40
struct { 
uint64m_T re; 
uint64m_T im; 
} cuint64m_T; 



typedef 
#line 45
struct { 
uint32_T chunks[3]; 
} int96m_T; 




typedef 
#line 49
struct { 
int96m_T re; 
int96m_T im; 
} cint96m_T; 



typedef 
#line 54
struct { 
uint32_T chunks[3]; 
} uint96m_T; 




typedef 
#line 58
struct { 
uint96m_T re; 
uint96m_T im; 
} cuint96m_T; 



typedef 
#line 63
struct { 
uint32_T chunks[4]; 
} int128m_T; 




typedef 
#line 67
struct { 
int128m_T re; 
int128m_T im; 
} cint128m_T; 



typedef 
#line 72
struct { 
uint32_T chunks[4]; 
} uint128m_T; 




typedef 
#line 76
struct { 
uint128m_T re; 
uint128m_T im; 
} cuint128m_T; 



typedef 
#line 81
struct { 
uint32_T chunks[5]; 
} int160m_T; 




typedef 
#line 85
struct { 
int160m_T re; 
int160m_T im; 
} cint160m_T; 



typedef 
#line 90
struct { 
uint32_T chunks[5]; 
} uint160m_T; 




typedef 
#line 94
struct { 
uint160m_T re; 
uint160m_T im; 
} cuint160m_T; 



typedef 
#line 99
struct { 
uint32_T chunks[6]; 
} int192m_T; 




typedef 
#line 103
struct { 
int192m_T re; 
int192m_T im; 
} cint192m_T; 



typedef 
#line 108
struct { 
uint32_T chunks[6]; 
} uint192m_T; 




typedef 
#line 112
struct { 
uint192m_T re; 
uint192m_T im; 
} cuint192m_T; 



typedef 
#line 117
struct { 
uint32_T chunks[7]; 
} int224m_T; 




typedef 
#line 121
struct { 
int224m_T re; 
int224m_T im; 
} cint224m_T; 



typedef 
#line 126
struct { 
uint32_T chunks[7]; 
} uint224m_T; 




typedef 
#line 130
struct { 
uint224m_T re; 
uint224m_T im; 
} cuint224m_T; 



typedef 
#line 135
struct { 
uint32_T chunks[8]; 
} int256m_T; 




typedef 
#line 139
struct { 
int256m_T re; 
int256m_T im; 
} cint256m_T; 



typedef 
#line 144
struct { 
uint32_T chunks[8]; 
} uint256m_T; 




typedef 
#line 148
struct { 
uint256m_T re; 
uint256m_T im; 
} cuint256m_T; 



typedef 
#line 153
struct { 
uint32_T chunks[9]; 
} int288m_T; 




typedef 
#line 157
struct { 
int288m_T re; 
int288m_T im; 
} cint288m_T; 



typedef 
#line 162
struct { 
uint32_T chunks[9]; 
} uint288m_T; 




typedef 
#line 166
struct { 
uint288m_T re; 
uint288m_T im; 
} cuint288m_T; 



typedef 
#line 171
struct { 
uint32_T chunks[10]; 
} int320m_T; 




typedef 
#line 175
struct { 
int320m_T re; 
int320m_T im; 
} cint320m_T; 



typedef 
#line 180
struct { 
uint32_T chunks[10]; 
} uint320m_T; 




typedef 
#line 184
struct { 
uint320m_T re; 
uint320m_T im; 
} cuint320m_T; 



typedef 
#line 189
struct { 
uint32_T chunks[11]; 
} int352m_T; 




typedef 
#line 193
struct { 
int352m_T re; 
int352m_T im; 
} cint352m_T; 



typedef 
#line 198
struct { 
uint32_T chunks[11]; 
} uint352m_T; 




typedef 
#line 202
struct { 
uint352m_T re; 
uint352m_T im; 
} cuint352m_T; 



typedef 
#line 207
struct { 
uint32_T chunks[12]; 
} int384m_T; 




typedef 
#line 211
struct { 
int384m_T re; 
int384m_T im; 
} cint384m_T; 



typedef 
#line 216
struct { 
uint32_T chunks[12]; 
} uint384m_T; 




typedef 
#line 220
struct { 
uint384m_T re; 
uint384m_T im; 
} cuint384m_T; 



typedef 
#line 225
struct { 
uint32_T chunks[13]; 
} int416m_T; 




typedef 
#line 229
struct { 
int416m_T re; 
int416m_T im; 
} cint416m_T; 



typedef 
#line 234
struct { 
uint32_T chunks[13]; 
} uint416m_T; 




typedef 
#line 238
struct { 
uint416m_T re; 
uint416m_T im; 
} cuint416m_T; 



typedef 
#line 243
struct { 
uint32_T chunks[14]; 
} int448m_T; 




typedef 
#line 247
struct { 
int448m_T re; 
int448m_T im; 
} cint448m_T; 



typedef 
#line 252
struct { 
uint32_T chunks[14]; 
} uint448m_T; 




typedef 
#line 256
struct { 
uint448m_T re; 
uint448m_T im; 
} cuint448m_T; 



typedef 
#line 261
struct { 
uint32_T chunks[15]; 
} int480m_T; 




typedef 
#line 265
struct { 
int480m_T re; 
int480m_T im; 
} cint480m_T; 



typedef 
#line 270
struct { 
uint32_T chunks[15]; 
} uint480m_T; 




typedef 
#line 274
struct { 
uint480m_T re; 
uint480m_T im; 
} cuint480m_T; 



typedef 
#line 279
struct { 
uint32_T chunks[16]; 
} int512m_T; 




typedef 
#line 283
struct { 
int512m_T re; 
int512m_T im; 
} cint512m_T; 



typedef 
#line 288
struct { 
uint32_T chunks[16]; 
} uint512m_T; 




typedef 
#line 292
struct { 
uint512m_T re; 
uint512m_T im; 
} cuint512m_T; 



typedef 
#line 297
struct { 
uint32_T chunks[17]; 
} int544m_T; 




typedef 
#line 301
struct { 
int544m_T re; 
int544m_T im; 
} cint544m_T; 



typedef 
#line 306
struct { 
uint32_T chunks[17]; 
} uint544m_T; 




typedef 
#line 310
struct { 
uint544m_T re; 
uint544m_T im; 
} cuint544m_T; 



typedef 
#line 315
struct { 
uint32_T chunks[18]; 
} int576m_T; 




typedef 
#line 319
struct { 
int576m_T re; 
int576m_T im; 
} cint576m_T; 



typedef 
#line 324
struct { 
uint32_T chunks[18]; 
} uint576m_T; 




typedef 
#line 328
struct { 
uint576m_T re; 
uint576m_T im; 
} cuint576m_T; 



typedef 
#line 333
struct { 
uint32_T chunks[19]; 
} int608m_T; 




typedef 
#line 337
struct { 
int608m_T re; 
int608m_T im; 
} cint608m_T; 



typedef 
#line 342
struct { 
uint32_T chunks[19]; 
} uint608m_T; 




typedef 
#line 346
struct { 
uint608m_T re; 
uint608m_T im; 
} cuint608m_T; 



typedef 
#line 351
struct { 
uint32_T chunks[20]; 
} int640m_T; 




typedef 
#line 355
struct { 
int640m_T re; 
int640m_T im; 
} cint640m_T; 



typedef 
#line 360
struct { 
uint32_T chunks[20]; 
} uint640m_T; 




typedef 
#line 364
struct { 
uint640m_T re; 
uint640m_T im; 
} cuint640m_T; 



typedef 
#line 369
struct { 
uint32_T chunks[21]; 
} int672m_T; 




typedef 
#line 373
struct { 
int672m_T re; 
int672m_T im; 
} cint672m_T; 



typedef 
#line 378
struct { 
uint32_T chunks[21]; 
} uint672m_T; 




typedef 
#line 382
struct { 
uint672m_T re; 
uint672m_T im; 
} cuint672m_T; 



typedef 
#line 387
struct { 
uint32_T chunks[22]; 
} int704m_T; 




typedef 
#line 391
struct { 
int704m_T re; 
int704m_T im; 
} cint704m_T; 



typedef 
#line 396
struct { 
uint32_T chunks[22]; 
} uint704m_T; 




typedef 
#line 400
struct { 
uint704m_T re; 
uint704m_T im; 
} cuint704m_T; 



typedef 
#line 405
struct { 
uint32_T chunks[23]; 
} int736m_T; 




typedef 
#line 409
struct { 
int736m_T re; 
int736m_T im; 
} cint736m_T; 



typedef 
#line 414
struct { 
uint32_T chunks[23]; 
} uint736m_T; 




typedef 
#line 418
struct { 
uint736m_T re; 
uint736m_T im; 
} cuint736m_T; 



typedef 
#line 423
struct { 
uint32_T chunks[24]; 
} int768m_T; 




typedef 
#line 427
struct { 
int768m_T re; 
int768m_T im; 
} cint768m_T; 



typedef 
#line 432
struct { 
uint32_T chunks[24]; 
} uint768m_T; 




typedef 
#line 436
struct { 
uint768m_T re; 
uint768m_T im; 
} cuint768m_T; 



typedef 
#line 441
struct { 
uint32_T chunks[25]; 
} int800m_T; 




typedef 
#line 445
struct { 
int800m_T re; 
int800m_T im; 
} cint800m_T; 



typedef 
#line 450
struct { 
uint32_T chunks[25]; 
} uint800m_T; 




typedef 
#line 454
struct { 
uint800m_T re; 
uint800m_T im; 
} cuint800m_T; 



typedef 
#line 459
struct { 
uint32_T chunks[26]; 
} int832m_T; 




typedef 
#line 463
struct { 
int832m_T re; 
int832m_T im; 
} cint832m_T; 



typedef 
#line 468
struct { 
uint32_T chunks[26]; 
} uint832m_T; 




typedef 
#line 472
struct { 
uint832m_T re; 
uint832m_T im; 
} cuint832m_T; 



typedef 
#line 477
struct { 
uint32_T chunks[27]; 
} int864m_T; 




typedef 
#line 481
struct { 
int864m_T re; 
int864m_T im; 
} cint864m_T; 



typedef 
#line 486
struct { 
uint32_T chunks[27]; 
} uint864m_T; 




typedef 
#line 490
struct { 
uint864m_T re; 
uint864m_T im; 
} cuint864m_T; 



typedef 
#line 495
struct { 
uint32_T chunks[28]; 
} int896m_T; 




typedef 
#line 499
struct { 
int896m_T re; 
int896m_T im; 
} cint896m_T; 



typedef 
#line 504
struct { 
uint32_T chunks[28]; 
} uint896m_T; 




typedef 
#line 508
struct { 
uint896m_T re; 
uint896m_T im; 
} cuint896m_T; 



typedef 
#line 513
struct { 
uint32_T chunks[29]; 
} int928m_T; 




typedef 
#line 517
struct { 
int928m_T re; 
int928m_T im; 
} cint928m_T; 



typedef 
#line 522
struct { 
uint32_T chunks[29]; 
} uint928m_T; 




typedef 
#line 526
struct { 
uint928m_T re; 
uint928m_T im; 
} cuint928m_T; 



typedef 
#line 531
struct { 
uint32_T chunks[30]; 
} int960m_T; 




typedef 
#line 535
struct { 
int960m_T re; 
int960m_T im; 
} cint960m_T; 



typedef 
#line 540
struct { 
uint32_T chunks[30]; 
} uint960m_T; 




typedef 
#line 544
struct { 
uint960m_T re; 
uint960m_T im; 
} cuint960m_T; 



typedef 
#line 549
struct { 
uint32_T chunks[31]; 
} int992m_T; 




typedef 
#line 553
struct { 
int992m_T re; 
int992m_T im; 
} cint992m_T; 



typedef 
#line 558
struct { 
uint32_T chunks[31]; 
} uint992m_T; 




typedef 
#line 562
struct { 
uint992m_T re; 
uint992m_T im; 
} cuint992m_T; 



typedef 
#line 567
struct { 
uint32_T chunks[32]; 
} int1024m_T; 




typedef 
#line 571
struct { 
int1024m_T re; 
int1024m_T im; 
} cint1024m_T; 



typedef 
#line 576
struct { 
uint32_T chunks[32]; 
} uint1024m_T; 




typedef 
#line 580
struct { 
uint1024m_T re; 
uint1024m_T im; 
} cuint1024m_T; 



typedef 
#line 585
struct { 
uint32_T chunks[33]; 
} int1056m_T; 




typedef 
#line 589
struct { 
int1056m_T re; 
int1056m_T im; 
} cint1056m_T; 



typedef 
#line 594
struct { 
uint32_T chunks[33]; 
} uint1056m_T; 




typedef 
#line 598
struct { 
uint1056m_T re; 
uint1056m_T im; 
} cuint1056m_T; 



typedef 
#line 603
struct { 
uint32_T chunks[34]; 
} int1088m_T; 




typedef 
#line 607
struct { 
int1088m_T re; 
int1088m_T im; 
} cint1088m_T; 



typedef 
#line 612
struct { 
uint32_T chunks[34]; 
} uint1088m_T; 




typedef 
#line 616
struct { 
uint1088m_T re; 
uint1088m_T im; 
} cuint1088m_T; 



typedef 
#line 621
struct { 
uint32_T chunks[35]; 
} int1120m_T; 




typedef 
#line 625
struct { 
int1120m_T re; 
int1120m_T im; 
} cint1120m_T; 



typedef 
#line 630
struct { 
uint32_T chunks[35]; 
} uint1120m_T; 




typedef 
#line 634
struct { 
uint1120m_T re; 
uint1120m_T im; 
} cuint1120m_T; 



typedef 
#line 639
struct { 
uint32_T chunks[36]; 
} int1152m_T; 




typedef 
#line 643
struct { 
int1152m_T re; 
int1152m_T im; 
} cint1152m_T; 



typedef 
#line 648
struct { 
uint32_T chunks[36]; 
} uint1152m_T; 




typedef 
#line 652
struct { 
uint1152m_T re; 
uint1152m_T im; 
} cuint1152m_T; 



typedef 
#line 657
struct { 
uint32_T chunks[37]; 
} int1184m_T; 




typedef 
#line 661
struct { 
int1184m_T re; 
int1184m_T im; 
} cint1184m_T; 



typedef 
#line 666
struct { 
uint32_T chunks[37]; 
} uint1184m_T; 




typedef 
#line 670
struct { 
uint1184m_T re; 
uint1184m_T im; 
} cuint1184m_T; 



typedef 
#line 675
struct { 
uint32_T chunks[38]; 
} int1216m_T; 




typedef 
#line 679
struct { 
int1216m_T re; 
int1216m_T im; 
} cint1216m_T; 



typedef 
#line 684
struct { 
uint32_T chunks[38]; 
} uint1216m_T; 




typedef 
#line 688
struct { 
uint1216m_T re; 
uint1216m_T im; 
} cuint1216m_T; 



typedef 
#line 693
struct { 
uint32_T chunks[39]; 
} int1248m_T; 




typedef 
#line 697
struct { 
int1248m_T re; 
int1248m_T im; 
} cint1248m_T; 



typedef 
#line 702
struct { 
uint32_T chunks[39]; 
} uint1248m_T; 




typedef 
#line 706
struct { 
uint1248m_T re; 
uint1248m_T im; 
} cuint1248m_T; 



typedef 
#line 711
struct { 
uint32_T chunks[40]; 
} int1280m_T; 




typedef 
#line 715
struct { 
int1280m_T re; 
int1280m_T im; 
} cint1280m_T; 



typedef 
#line 720
struct { 
uint32_T chunks[40]; 
} uint1280m_T; 




typedef 
#line 724
struct { 
uint1280m_T re; 
uint1280m_T im; 
} cuint1280m_T; 



typedef 
#line 729
struct { 
uint32_T chunks[41]; 
} int1312m_T; 




typedef 
#line 733
struct { 
int1312m_T re; 
int1312m_T im; 
} cint1312m_T; 



typedef 
#line 738
struct { 
uint32_T chunks[41]; 
} uint1312m_T; 




typedef 
#line 742
struct { 
uint1312m_T re; 
uint1312m_T im; 
} cuint1312m_T; 



typedef 
#line 747
struct { 
uint32_T chunks[42]; 
} int1344m_T; 




typedef 
#line 751
struct { 
int1344m_T re; 
int1344m_T im; 
} cint1344m_T; 



typedef 
#line 756
struct { 
uint32_T chunks[42]; 
} uint1344m_T; 




typedef 
#line 760
struct { 
uint1344m_T re; 
uint1344m_T im; 
} cuint1344m_T; 



typedef 
#line 765
struct { 
uint32_T chunks[43]; 
} int1376m_T; 




typedef 
#line 769
struct { 
int1376m_T re; 
int1376m_T im; 
} cint1376m_T; 



typedef 
#line 774
struct { 
uint32_T chunks[43]; 
} uint1376m_T; 




typedef 
#line 778
struct { 
uint1376m_T re; 
uint1376m_T im; 
} cuint1376m_T; 



typedef 
#line 783
struct { 
uint32_T chunks[44]; 
} int1408m_T; 




typedef 
#line 787
struct { 
int1408m_T re; 
int1408m_T im; 
} cint1408m_T; 



typedef 
#line 792
struct { 
uint32_T chunks[44]; 
} uint1408m_T; 




typedef 
#line 796
struct { 
uint1408m_T re; 
uint1408m_T im; 
} cuint1408m_T; 



typedef 
#line 801
struct { 
uint32_T chunks[45]; 
} int1440m_T; 




typedef 
#line 805
struct { 
int1440m_T re; 
int1440m_T im; 
} cint1440m_T; 



typedef 
#line 810
struct { 
uint32_T chunks[45]; 
} uint1440m_T; 




typedef 
#line 814
struct { 
uint1440m_T re; 
uint1440m_T im; 
} cuint1440m_T; 



typedef 
#line 819
struct { 
uint32_T chunks[46]; 
} int1472m_T; 




typedef 
#line 823
struct { 
int1472m_T re; 
int1472m_T im; 
} cint1472m_T; 



typedef 
#line 828
struct { 
uint32_T chunks[46]; 
} uint1472m_T; 




typedef 
#line 832
struct { 
uint1472m_T re; 
uint1472m_T im; 
} cuint1472m_T; 



typedef 
#line 837
struct { 
uint32_T chunks[47]; 
} int1504m_T; 




typedef 
#line 841
struct { 
int1504m_T re; 
int1504m_T im; 
} cint1504m_T; 



typedef 
#line 846
struct { 
uint32_T chunks[47]; 
} uint1504m_T; 




typedef 
#line 850
struct { 
uint1504m_T re; 
uint1504m_T im; 
} cuint1504m_T; 



typedef 
#line 855
struct { 
uint32_T chunks[48]; 
} int1536m_T; 




typedef 
#line 859
struct { 
int1536m_T re; 
int1536m_T im; 
} cint1536m_T; 



typedef 
#line 864
struct { 
uint32_T chunks[48]; 
} uint1536m_T; 




typedef 
#line 868
struct { 
uint1536m_T re; 
uint1536m_T im; 
} cuint1536m_T; 



typedef 
#line 873
struct { 
uint32_T chunks[49]; 
} int1568m_T; 




typedef 
#line 877
struct { 
int1568m_T re; 
int1568m_T im; 
} cint1568m_T; 



typedef 
#line 882
struct { 
uint32_T chunks[49]; 
} uint1568m_T; 




typedef 
#line 886
struct { 
uint1568m_T re; 
uint1568m_T im; 
} cuint1568m_T; 



typedef 
#line 891
struct { 
uint32_T chunks[50]; 
} int1600m_T; 




typedef 
#line 895
struct { 
int1600m_T re; 
int1600m_T im; 
} cint1600m_T; 



typedef 
#line 900
struct { 
uint32_T chunks[50]; 
} uint1600m_T; 




typedef 
#line 904
struct { 
uint1600m_T re; 
uint1600m_T im; 
} cuint1600m_T; 



typedef 
#line 909
struct { 
uint32_T chunks[51]; 
} int1632m_T; 




typedef 
#line 913
struct { 
int1632m_T re; 
int1632m_T im; 
} cint1632m_T; 



typedef 
#line 918
struct { 
uint32_T chunks[51]; 
} uint1632m_T; 




typedef 
#line 922
struct { 
uint1632m_T re; 
uint1632m_T im; 
} cuint1632m_T; 



typedef 
#line 927
struct { 
uint32_T chunks[52]; 
} int1664m_T; 




typedef 
#line 931
struct { 
int1664m_T re; 
int1664m_T im; 
} cint1664m_T; 



typedef 
#line 936
struct { 
uint32_T chunks[52]; 
} uint1664m_T; 




typedef 
#line 940
struct { 
uint1664m_T re; 
uint1664m_T im; 
} cuint1664m_T; 



typedef 
#line 945
struct { 
uint32_T chunks[53]; 
} int1696m_T; 




typedef 
#line 949
struct { 
int1696m_T re; 
int1696m_T im; 
} cint1696m_T; 



typedef 
#line 954
struct { 
uint32_T chunks[53]; 
} uint1696m_T; 




typedef 
#line 958
struct { 
uint1696m_T re; 
uint1696m_T im; 
} cuint1696m_T; 



typedef 
#line 963
struct { 
uint32_T chunks[54]; 
} int1728m_T; 




typedef 
#line 967
struct { 
int1728m_T re; 
int1728m_T im; 
} cint1728m_T; 



typedef 
#line 972
struct { 
uint32_T chunks[54]; 
} uint1728m_T; 




typedef 
#line 976
struct { 
uint1728m_T re; 
uint1728m_T im; 
} cuint1728m_T; 



typedef 
#line 981
struct { 
uint32_T chunks[55]; 
} int1760m_T; 




typedef 
#line 985
struct { 
int1760m_T re; 
int1760m_T im; 
} cint1760m_T; 



typedef 
#line 990
struct { 
uint32_T chunks[55]; 
} uint1760m_T; 




typedef 
#line 994
struct { 
uint1760m_T re; 
uint1760m_T im; 
} cuint1760m_T; 



typedef 
#line 999
struct { 
uint32_T chunks[56]; 
} int1792m_T; 




typedef 
#line 1003
struct { 
int1792m_T re; 
int1792m_T im; 
} cint1792m_T; 



typedef 
#line 1008
struct { 
uint32_T chunks[56]; 
} uint1792m_T; 




typedef 
#line 1012
struct { 
uint1792m_T re; 
uint1792m_T im; 
} cuint1792m_T; 



typedef 
#line 1017
struct { 
uint32_T chunks[57]; 
} int1824m_T; 




typedef 
#line 1021
struct { 
int1824m_T re; 
int1824m_T im; 
} cint1824m_T; 



typedef 
#line 1026
struct { 
uint32_T chunks[57]; 
} uint1824m_T; 




typedef 
#line 1030
struct { 
uint1824m_T re; 
uint1824m_T im; 
} cuint1824m_T; 



typedef 
#line 1035
struct { 
uint32_T chunks[58]; 
} int1856m_T; 




typedef 
#line 1039
struct { 
int1856m_T re; 
int1856m_T im; 
} cint1856m_T; 



typedef 
#line 1044
struct { 
uint32_T chunks[58]; 
} uint1856m_T; 




typedef 
#line 1048
struct { 
uint1856m_T re; 
uint1856m_T im; 
} cuint1856m_T; 



typedef 
#line 1053
struct { 
uint32_T chunks[59]; 
} int1888m_T; 




typedef 
#line 1057
struct { 
int1888m_T re; 
int1888m_T im; 
} cint1888m_T; 



typedef 
#line 1062
struct { 
uint32_T chunks[59]; 
} uint1888m_T; 




typedef 
#line 1066
struct { 
uint1888m_T re; 
uint1888m_T im; 
} cuint1888m_T; 



typedef 
#line 1071
struct { 
uint32_T chunks[60]; 
} int1920m_T; 




typedef 
#line 1075
struct { 
int1920m_T re; 
int1920m_T im; 
} cint1920m_T; 



typedef 
#line 1080
struct { 
uint32_T chunks[60]; 
} uint1920m_T; 




typedef 
#line 1084
struct { 
uint1920m_T re; 
uint1920m_T im; 
} cuint1920m_T; 



typedef 
#line 1089
struct { 
uint32_T chunks[61]; 
} int1952m_T; 




typedef 
#line 1093
struct { 
int1952m_T re; 
int1952m_T im; 
} cint1952m_T; 



typedef 
#line 1098
struct { 
uint32_T chunks[61]; 
} uint1952m_T; 




typedef 
#line 1102
struct { 
uint1952m_T re; 
uint1952m_T im; 
} cuint1952m_T; 



typedef 
#line 1107
struct { 
uint32_T chunks[62]; 
} int1984m_T; 




typedef 
#line 1111
struct { 
int1984m_T re; 
int1984m_T im; 
} cint1984m_T; 



typedef 
#line 1116
struct { 
uint32_T chunks[62]; 
} uint1984m_T; 




typedef 
#line 1120
struct { 
uint1984m_T re; 
uint1984m_T im; 
} cuint1984m_T; 



typedef 
#line 1125
struct { 
uint32_T chunks[63]; 
} int2016m_T; 




typedef 
#line 1129
struct { 
int2016m_T re; 
int2016m_T im; 
} cint2016m_T; 



typedef 
#line 1134
struct { 
uint32_T chunks[63]; 
} uint2016m_T; 




typedef 
#line 1138
struct { 
uint2016m_T re; 
uint2016m_T im; 
} cuint2016m_T; 



typedef 
#line 1143
struct { 
uint32_T chunks[64]; 
} int2048m_T; 




typedef 
#line 1147
struct { 
int2048m_T re; 
int2048m_T im; 
} cint2048m_T; 



typedef 
#line 1152
struct { 
uint32_T chunks[64]; 
} uint2048m_T; 




typedef 
#line 1156
struct { 
uint2048m_T re; 
uint2048m_T im; 
} cuint2048m_T; 

#endif /* MULTIWORD_TYPES_H */
#line 29 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\controller\\controller_private.h"
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm) (*((rtm)->errorStatus))
#endif /* rtmGetErrorStatus */

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm,val) (*((rtm)->errorStatus) = (val))
#endif /* rtmSetErrorStatus */

#ifndef rtmGetErrorStatusPointer
#define rtmGetErrorStatusPointer(rtm) (rtm)->errorStatus
#endif /* rtmGetErrorStatusPointer */

#ifndef rtmSetErrorStatusPointer
#define rtmSetErrorStatusPointer(rtm,val) ((rtm)->errorStatus = (val))
#endif /* rtmSetErrorStatusPointer */

extern P_controller_T controller_P; 

#endif /* RTW_HEADER_controller_private_h_ */
#line 2 "C:\\Program Files\\MATLAB\\R2022b\\sys\\lcc64\\lcc64\\include64\\math.h"
#ifndef __math_h__
#define __math_h__

#ifndef HUGE_VAL
#define HUGE_VAL 1.7976931348623157e+308
#endif /* HUGE_VAL */




#pragma extensions(push,on)




typedef float float_t; 
typedef double double_t; 


double atan(double); 
double _atani(int); 
long double atanl(long double); 
float atanf(float); 


long double tanl(long double); 
double tan(double); 
float tanf(float); 


double cos(double); 
long double cosl(long double); 
float cosf(float); 
double _cosi(int); 
double _cosu(unsigned); 
double _cosll(long long); 
double _cosull(unsigned long long); 

long double sinl(long double); 
float sinf(float); 
double sin(double); 
double _sini(int); 
double _sinu(unsigned); 
double _sinll(long long); 
double _sinull(unsigned long long); 


long double exp2l(long double); 
double exp2(double); 
float exp2f(float); 


double exp10(double); 
float exp10f(float); 
long double exp10l(long double); 


long double expm1l(long double); 
double expm1(double); 
float expm1f(float); 
double _expm1i(int); 


double tanh(double); 
long double tanhl(long double); 
float tanhf(float); 


double frexp(double, int *); 
long double frexpl(long double, int *); 
double _frexpi(int, int *); 
float frexpf(float, int *); 


long double fdiml(long double x, long double y); 
double fdim(double x, double y); 
float fdimf(float x, float y); 

double modf(double, double *); 
long double modfl(long double, long double *); 


double ceil(double); 
long double ceill(long double); 
float ceilf(float); 
double _ceili(int); 


double cbrt(double); 
long double cbrtl(long double); 
float cbrtf(float); 


long double fabsl(long double); 
double fabsd(double); 
float fabsf(float); 
double fabs(double); 
double _fabsi(int); 
double _fabsull(unsigned long long); 
double _fabsll(long long); 
double _fabsu(unsigned); 


long double floorl(long double); 
double floord(double); 
float floorf(float); 
double floor(double); 
double _floori(int); 
double _flooru(unsigned); 


long double fmal(long double, long double, long double); 
double fma(double, double, double); 
float fmaf(float, float, float); 
double _fmai(int, int, int); 


long double fmaxl(long double, long double); 
double fmax(double, double); 
float fmaxf(float, float); 

double acos(double); 
float acosf(float); 
long double acosl(long double); 


double asin(double); 
long double asinl(long double); 
float asinf(float); 

double atan2(double, double); 
long double atan2l(long double, long double); 
float atan2f(float, float); 


double cosh(double); 
long double coshl(long double); 
float coshf(float); 
double _coshi(int); 


double sinh(double); 
long double sinhl(long double); 
float sinhf(float); 
double _sinhi(int); 
double _sinhll(long long); 


long double expl(long double); 
float expf(float); 
double exp(double); 


double ldexp(double, int); 
long double ldexpl(long double, int); 
float ldexpf(float, int); 


long double logl(long double); 
float logf(float); 
double log(double); 
double _logi(int); 


double log10(double); 
long double log10l(long double); 
float log10f(float); 


double log1p(double); 
long double log1pl(long double); 
float log1pf(float); 


long double log10l(long double); 
float log10f(float); 
double _log10i(int); 
double log10(double); 


double pow(double, double); 
long double powl(long double, long double); 
double powd(double, double); 
long double powlli(long double, int); 
double ipow(double, int); 
double powdi(double, int); 
long double ipowl(long double, int); 
float ipowf(float, int); 
float powf(float, float); 
double powii(int, int); 
long double powlld(long double, double); 
long double powlli(long double, int); 
long double powdll(double, long double); 
double powid(int, double); 


double scalb(double, double); 
long double scalbl(long double, long double); 
float scalbf(float, float); 


double scalbn(double, int); 
long double scalbnl(long double, int); 
float scalbnf(float, int); 


double scalbln(double, long); 
long double scalblnl(long double, long); 
float scalblnf(float, long); 


long double sqrtl(long double); 
double _sqrti(int); 
double _sqrtu(unsigned); 
double _sqrtll(long long); 
double _sqrtull(unsigned long long); 
float sqrtf(float); 
double sqrt(double); 


double fmod(double, double); 
long double fmodl(long double, long double); 
float fmodf(float, float); 

double infinity(void); 
long double infinityl(void); 
float infinityf(void); 
long double max_normall(void); 
double max_normal(void); 
float max_normalf(void); 
long double min_normall(void); 
double min_normal(void); 
float min_normalf(void); 

int isnand(double); 
int isnanl(long double); 
int isnanf(float); 
int isnan(double); 

int finite(double); 

int isnormalf(float); 
int isnormal(double); 
int isnormall(long double); 

double copysign(double, double); 
long double copysignl(long double, long double); 
float copysignf(float, float); 

int ilogb(double); 
int ilogbf(float); 
int ilogbl(long double); 

double logb(double); 
long double logbl(long double); 
float logbf(float); 

double erf(double); 
long double erfl(long double); 
float erff(float); 


double erfc(double); 
long double erfcl(long double); 
float erfcf(float); 

int _signbit(double); 



double asinh(double); 
long double asinhl(long double); 
long double sinhl(long double); 
float asinhf(float); 


double nextafter(double, double); 
long double nextafterl(long double, long double); 
float nextafterf(float, float); 


double nexttoward(double, long double); 
long double nexttowardl(long double, long double); 
float nexttowardf(float, long double); 


double acosh(double); 
long double acoshl(long double); 
long double acoshl(long double); 
float acoshf(float); 


double atanh(double); 
long double atanhl(long double); 
float atanhf(float); 


double lgamma(double); 
long double lgammal(long double); 
float lgammaf(float); 

long double tgammal(long double); 
double tgamma(double); 
float tgammaf(float); 


double _y0(double); 
long double y0l(long double); 
double y1(double); 
long double y1l(long double); 
double yn(int, double); 
long double ynl(int, long double); 
double j0(double); 
double j1(double); 
long double j1l(long double); 
double jn(int, double); 
long double jnl(int, long double); 



long double log2l(long double); 
double log2(double); 
float log2f(float); 
double _log2i(int); 
double _log2ll(long long); 


long double nearbyintl(long double); 
double nearbyint(double); 
float nearbyintf(float); 


double hypot(double, double); 
long double hypotl(long double, long double); 
float hypotf(float, float); 

double _rint(double); 



int isinf(double); 
int _isinfd(double); 
int isinfl(long double); 
int isinff(float); 
int _isinfi(int); 


int isfinite(double); 
int isfinitef(float); 
int isfinitel(long double); 

int __fpclassifyl(long double); 
int __fpclassifyd(double); 
int __fpclassifyf(float); 


double round(double); 
float roundf(float); 
long double roundl(long double); 
double _roundi(int); 


double remainder(double, double); 
long double remainderl(long double, long double); 
float remainderf(float, float); 

int lrint(double); 
int lrintf(float); 
long lrintl(long double); 
long long llrintl(long double); 
long long llrintf(float); 
long long llrint(double); 

long lround(double); 
long lroundf(float); 
long lroundl(long double); 

long long llround(double); 
long long llroundf(float); 
long long llroundl(long double); 

long double remquol(long double, long double, int *); 
double remquo(double, double, int *); 
float remquof(float, float, int *); 

double trunc(double x); 
long double truncl(long double); 
float truncf(float); 


long double fminl(long double, long double); 
float fminf(float, float); 
double fmin(double, double); 
#line 406
void ldtoa(long double, char *); 
double cabs(double _Complex); 
float cabsf(float _Complex); 
long double cabsl(long double _Complex); 




struct exception { 

int type; 
char *name; 
double arg1; 
double arg2; 
double retval; 
int err; 
}; 

int matherr(struct exception * e); 

extern float __nan__; 

extern float __infinity__; 
double nan(const char *); 
float nanf(const char *); 
long double nanl(const char *); 



int fcmp(double, double, double); 
int fcmpl(long double, long double, long double); 
void sincos(double x, double * sin, double * cos); 
void sincosf(float x, float * sin, float * cos); 
void sincosl(long double x, long double * sin, long double * cos); 
#line 446
int _isgreater(long double, long double); 


int _isgreaterequal(long double, long double); 


int _isless(long double, long double); 


int _islessequal(long double, long double); 


int _islessgreater(long double, long double); 


int _isunordered(long double, long double); 
#line 474
double atof(const char *); 

int cubic(double a, double b, double c, double d, double * x); 




int cubicl(long double a, long double b, long double c, long double d, long double * x); 
#line 537
#endif /* __math_h__ */
#line 535
#pragma extensions(pop)
#line 41 "C:\\Users\\39375\\LM mechatronics 2nd semester\\MBSD\\Lab3_317561_317651\\Matlab\\slprj\\grt\\controller\\controller.c"
P_controller_T controller_P = {(30.0), (80.0), (-(80.0)), (1.0F), (0.0F)}; 
#line 69
void controller_Init(real32_T *rty_Error, B_controller_c_T *localB, DW_controller_f_T *
localDW) 
{ __MW_INSTRUM_FCN_ENTER_1(); __MW_INSTRUM_NODE_1(); 

localDW->is_Brake = (uint8_T)0U; 
localDW->is_Drive = (uint8_T)0U; 
localDW->is_Reverse = (uint8_T)0U; 
localDW->is_active_c3_controller = (0U); 
localDW->is_c3_controller = (uint8_T)0U; 
localB->TorqueRequest_Nm_e = (0.0F); 
localB->StoppedControllerMode = (0.0F); 
localB->TargetSpeed_km_h = (0.0); 


localDW->temporalCounter_i1 = (0U); 
localDW->is_active_c1_controller = (0U); 
localDW->is_c1_controller = (uint8_T)0U; 
*rty_Error = (0.0F); 
localB->TorqueRequest_Nm = (0.0F); 
localB->AutomaticTransmissionState = 0; __MW_INSTRUM_NODE_2(); 
} 


void controller_Reset(real32_T *rty_Error, B_controller_c_T *localB, DW_controller_f_T *
localDW) 
{ __MW_INSTRUM_FCN_ENTER_2(); __MW_INSTRUM_NODE_3(); 

localDW->is_Brake = (uint8_T)0U; 
localDW->is_Drive = (uint8_T)0U; 
localDW->is_Reverse = (uint8_T)0U; 
localDW->is_active_c3_controller = (0U); 
localDW->is_c3_controller = (uint8_T)0U; 
localB->TorqueRequest_Nm_e = (0.0F); 
localB->StoppedControllerMode = (0.0F); 
localB->TargetSpeed_km_h = (0.0); 


localDW->temporalCounter_i1 = (0U); 
localDW->is_active_c1_controller = (0U); 
localDW->is_c1_controller = (uint8_T)0U; 
*rty_Error = (0.0F); 
localB->TorqueRequest_Nm = (0.0F); 
localB->AutomaticTransmissionState = 0; __MW_INSTRUM_NODE_4(); 
} 


void controller(const boolean_T *rtu_BrakePedalPressed, const real32_T *
rtu_ThrottlePedalPosition, const TransmissionState *
rtu_AutomaticTransmissionSelect, const boolean_T *
rtu_BrakePedalPressed_Backup, const real32_T *
rtu_ThrottlePedalPosition_Backu, const real32_T *
rtu_VehicleSpeed_km_h, real32_T *rty_TorqueRequest_Nm, TransmissionState *
rty_AutomaticTransmissionState, real32_T *
rty_Error, B_controller_c_T *localB, DW_controller_f_T *localDW) 
{ float __mw_tmp_for_expr_33; double __mw_tmp_for_expr_32; double __mw_tmp_for_expr_31; float __mw_tmp_for_expr_30; float __mw_tmp_for_expr_29; float __mw_tmp_for_expr_28; unsigned __mw_tmp_for_expr_27; int __mw_tmp_for_expr_26; int __mw_tmp_for_expr_25; float __mw_tmp_for_expr_24; int __mw_tmp_for_expr_23; int __mw_tmp_for_expr_22; unsigned __mw_tmp_for_expr_21; unsigned __mw_tmp_for_expr_20; unsigned __mw_tmp_for_expr_19; int __mw_tmp_for_expr_18; int __mw_tmp_for_expr_17; float __mw_tmp_for_expr_16; float __mw_tmp_for_expr_15; float __mw_tmp_for_expr_14; float __mw_tmp_for_expr_13; int __mw_tmp_for_expr_12; int __mw_tmp_for_expr_11; double __mw_tmp_for_expr_10; double __mw_tmp_for_expr_9; double __mw_tmp_for_expr_8; double __mw_tmp_for_expr_7; float __mw_tmp_for_expr_6; double __mw_tmp_for_expr_5; double __mw_tmp_for_expr_4; unsigned __mw_tmp_for_expr_3; float __mw_tmp_for_expr_2; float __mw_tmp_for_expr_1; __MW_INSTRUM_FCN_ENTER_3(); __MW_INSTRUM_NODE_5(); { 
int32_T rtb_AutomaticTransmissionState; 
int32_T rtb_DataTypeConversion1; 
real32_T rtb_Saturation; 


rtb_Saturation = *rtu_ThrottlePedalPosition; 
if (__MW_INSTRUM_NODE_6(((__mw_tmp_for_expr_1 = controller_P.Saturation_UpperSat), (__MW_INSTRUM_NODE_8(rtb_Saturation, __mw_tmp_for_expr_1), (rtb_Saturation > __mw_tmp_for_expr_1))))) { 
rtb_Saturation = controller_P.Saturation_UpperSat; 
} else { if (__MW_INSTRUM_NODE_10(((__mw_tmp_for_expr_2 = controller_P.Saturation_LowerSat), (__MW_INSTRUM_NODE_12(rtb_Saturation, __mw_tmp_for_expr_2), (rtb_Saturation < __mw_tmp_for_expr_2))))) { 
rtb_Saturation = controller_P.Saturation_LowerSat; 
}  }  




rtb_DataTypeConversion1 = (int32_T)(*rtu_AutomaticTransmissionSelect); 


if (__MW_INSTRUM_NODE_14(((__mw_tmp_for_expr_3 = localDW->is_active_c3_controller), (__MW_INSTRUM_NODE_16(__mw_tmp_for_expr_3, 0U), (__mw_tmp_for_expr_3 == 0U))))) { 
localDW->is_active_c3_controller = (1U); 
localDW->is_c3_controller = (uint8_T)4U; 
rtb_AutomaticTransmissionState = 0; 
} else { 
switch (localDW->is_c3_controller) { 
case (uint8_T)1U:  __MW_INSTRUM_NODE_19(); 
{ 
rtb_AutomaticTransmissionState = 4; 
if (__MW_INSTRUM_NODE_20((__MW_INSTRUM_NODE_22(rtb_DataTypeConversion1, 4), (rtb_DataTypeConversion1 != 4)))) { 
localDW->is_Brake = (uint8_T)0U; 
localDW->is_c3_controller = (uint8_T)2U; 
rtb_AutomaticTransmissionState = 3; 
localDW->is_Drive = (uint8_T)1U; 
} else { 
switch (localDW->is_Brake) { 
case (uint8_T)1U:  __MW_INSTRUM_NODE_25(); 
if (__MW_INSTRUM_NODE_26(((__mw_tmp_for_expr_4 = rtb_Saturation), (__MW_INSTRUM_NODE_28(__mw_tmp_for_expr_4, (0.33333333333333331)), (__mw_tmp_for_expr_4 < (0.33333333333333331)))))) { 
localDW->is_Brake = (uint8_T)2U; 
localB->StoppedControllerMode = (0.0F); 
} else { if (__MW_INSTRUM_NODE_30(*rtu_BrakePedalPressed)) { 
localDW->is_Brake = (uint8_T)3U; 
} else { 
localB->TorqueRequest_Nm_e = (real32_T)(rtP_MAX_TORQUE * (1.5)) * (rtb_Saturation - (0.333333343F)); 

}  }  
break; 

case (uint8_T)2U:  __MW_INSTRUM_NODE_32(); 
if (__MW_INSTRUM_NODE_33(((__mw_tmp_for_expr_5 = rtb_Saturation), (__MW_INSTRUM_NODE_35(__mw_tmp_for_expr_5, (0.33333333333333331)), (__mw_tmp_for_expr_5 > (0.33333333333333331)))))) { 
localDW->is_Brake = (uint8_T)1U; 
localB->StoppedControllerMode = (0.0F); 
} else { if (__MW_INSTRUM_NODE_37(((__mw_tmp_for_expr_6 = (__MW_INSTRUM_NODE_41(), fabsf(*rtu_VehicleSpeed_km_h))), (__MW_INSTRUM_NODE_39(__mw_tmp_for_expr_6, (1.0F)), (__mw_tmp_for_expr_6 <= (1.0F)))))) { 
localDW->is_Brake = (uint8_T)4U; 
localB->StoppedControllerMode = (1.0F); 
} else { if (__MW_INSTRUM_NODE_42(*rtu_BrakePedalPressed)) { 
localDW->is_Brake = (uint8_T)3U; 
} else { 
localB->TorqueRequest_Nm_e = ((1.0F) - (3.0F) * rtb_Saturation) * (real32_T)(-rtP_MAX_TORQUE); 

}  }  }  
break; 

case (uint8_T)3U:  __MW_INSTRUM_NODE_44(); 
{ 
boolean_T i_out; 
i_out = __MW_INSTRUM_NODE_45(!__MW_INSTRUM_NODE_47(*rtu_BrakePedalPressed)); 
if (__MW_INSTRUM_NODE_49(__MW_INSTRUM_NODE_51(((__mw_tmp_for_expr_7 = rtb_Saturation), (__MW_INSTRUM_NODE_53(__mw_tmp_for_expr_7, (0.33333333333333331)), (__mw_tmp_for_expr_7 > (0.33333333333333331))))) && (__MW_INSTRUM_NODE_55(i_out)))) { 
localDW->is_Brake = (uint8_T)1U; 
localB->StoppedControllerMode = (0.0F); 
} else { if (__MW_INSTRUM_NODE_57(__MW_INSTRUM_NODE_59(((__mw_tmp_for_expr_8 = rtb_Saturation), (__MW_INSTRUM_NODE_61(__mw_tmp_for_expr_8, (0.33333333333333331)), (__mw_tmp_for_expr_8 <= (0.33333333333333331))))) && (__MW_INSTRUM_NODE_63(i_out)))) { 
localDW->is_Brake = (uint8_T)2U; 
localB->StoppedControllerMode = (0.0F); 
} else { 
localB->StoppedControllerMode = (1.0F); 
localB->TargetSpeed_km_h = (0.0); 
}  }  
} 
break; 

default:  __MW_INSTRUM_NODE_65(); 

if (__MW_INSTRUM_NODE_66(((__mw_tmp_for_expr_9 = rtb_Saturation), (__MW_INSTRUM_NODE_68(__mw_tmp_for_expr_9, (0.33333333333333331)), (__mw_tmp_for_expr_9 > (0.33333333333333331)))))) { 
localDW->is_Brake = (uint8_T)1U; 
localB->StoppedControllerMode = (0.0F); 
} else { 
localB->TargetSpeed_km_h = (0.0); 
}  
break; 
}  
}  
} 
break; 

case (uint8_T)2U:  __MW_INSTRUM_NODE_70(); 
{ 
rtb_AutomaticTransmissionState = 3; 
if (__MW_INSTRUM_NODE_71(__MW_INSTRUM_NODE_73((__MW_INSTRUM_NODE_75(rtb_DataTypeConversion1, 4), (rtb_DataTypeConversion1 == 4))) && __MW_INSTRUM_NODE_78(((__mw_tmp_for_expr_10 = rtb_Saturation), (__MW_INSTRUM_NODE_80(__mw_tmp_for_expr_10, (0.33333333333333331)), (__mw_tmp_for_expr_10 > (0.33333333333333331))))))) 
{ 
localDW->is_Drive = (uint8_T)0U; 
localDW->is_c3_controller = (uint8_T)1U; 
rtb_AutomaticTransmissionState = 4; 
localDW->is_Brake = (uint8_T)2U; 
localB->StoppedControllerMode = (0.0F); 
} else { if (__MW_INSTRUM_NODE_82((__MW_INSTRUM_NODE_84(rtb_DataTypeConversion1, 3), (rtb_DataTypeConversion1 < 3)))) { 
localDW->is_Drive = (uint8_T)0U; 
localDW->is_c3_controller = (uint8_T)3U; 
rtb_AutomaticTransmissionState = 2; 
} else { if (__MW_INSTRUM_NODE_87(((__mw_tmp_for_expr_11 = localDW->is_Drive), ((__mw_tmp_for_expr_12 = (uint8_T)1U), (__MW_INSTRUM_NODE_89(__mw_tmp_for_expr_11, __mw_tmp_for_expr_12), (__mw_tmp_for_expr_11 == __mw_tmp_for_expr_12)))))) { 
boolean_T i_out; 
i_out = __MW_INSTRUM_NODE_92((__MW_INSTRUM_NODE_94(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_96((__MW_INSTRUM_NODE_98(rtb_Saturation, (0.0F)), (rtb_Saturation == (0.0F))))); 
if (__MW_INSTRUM_NODE_100(i_out)) { 
localDW->is_Drive = (uint8_T)2U; 
} else { 
localB->TorqueRequest_Nm_e = (real32_T)rtP_MAX_TORQUE * rtb_Saturation; 

}  
} else { 
boolean_T i_out; 


i_out = __MW_INSTRUM_NODE_102(__MW_INSTRUM_NODE_104((__MW_INSTRUM_NODE_106(rtb_Saturation, (0.0F)), (rtb_Saturation > (0.0F)))) && __MW_INSTRUM_NODE_108(!__MW_INSTRUM_NODE_110(*rtu_BrakePedalPressed))); 
if (__MW_INSTRUM_NODE_112(i_out)) { 
localDW->is_Drive = (uint8_T)1U; 
} else { 
localB->StoppedControllerMode = (1.0F); 
localB->TargetSpeed_km_h = (0.0); 
}  
}  }  }  
} 
break; 

case (uint8_T)3U:  __MW_INSTRUM_NODE_114(); 
{ 
rtb_AutomaticTransmissionState = 2; 
if (__MW_INSTRUM_NODE_115(__MW_INSTRUM_NODE_117(((__mw_tmp_for_expr_13 = (__MW_INSTRUM_NODE_121(), fabsf(*rtu_VehicleSpeed_km_h))), (__MW_INSTRUM_NODE_119(__mw_tmp_for_expr_13, (5.0F)), (__mw_tmp_for_expr_13 < (5.0F))))) && __MW_INSTRUM_NODE_122((__MW_INSTRUM_NODE_124(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_126((__MW_INSTRUM_NODE_128(rtb_DataTypeConversion1, 0), (rtb_DataTypeConversion1 == 0)))))) 
{ 
localDW->is_c3_controller = (uint8_T)4U; 
rtb_AutomaticTransmissionState = 0; 
} else { 
boolean_T i_out; 
i_out = __MW_INSTRUM_NODE_131(__MW_INSTRUM_NODE_133(__MW_INSTRUM_NODE_135(((__mw_tmp_for_expr_14 = *rtu_VehicleSpeed_km_h), (__MW_INSTRUM_NODE_137(__mw_tmp_for_expr_14, (5.0F)), (__mw_tmp_for_expr_14 < (5.0F))))) && (__MW_INSTRUM_NODE_139(*rtu_BrakePedalPressed))) && __MW_INSTRUM_NODE_141((__MW_INSTRUM_NODE_143(rtb_DataTypeConversion1, 1), (rtb_DataTypeConversion1 == 1)))); 

if (__MW_INSTRUM_NODE_146(i_out)) { 
localDW->is_c3_controller = (uint8_T)5U; 
rtb_AutomaticTransmissionState = 1; 
localDW->is_Reverse = (uint8_T)1U; 
} else { 
i_out = __MW_INSTRUM_NODE_148(__MW_INSTRUM_NODE_150(__MW_INSTRUM_NODE_152(((__mw_tmp_for_expr_15 = *rtu_VehicleSpeed_km_h), ((__mw_tmp_for_expr_16 = -(5.0F)), (__MW_INSTRUM_NODE_154(__mw_tmp_for_expr_15, __mw_tmp_for_expr_16), (__mw_tmp_for_expr_15 > __mw_tmp_for_expr_16))))) && (__MW_INSTRUM_NODE_156(*rtu_BrakePedalPressed))) && __MW_INSTRUM_NODE_158((__MW_INSTRUM_NODE_160(rtb_DataTypeConversion1, 2), (rtb_DataTypeConversion1 > 2)))); 

if (__MW_INSTRUM_NODE_163(i_out)) { 
localDW->is_c3_controller = (uint8_T)2U; 
rtb_AutomaticTransmissionState = 3; 
localDW->is_Drive = (uint8_T)1U; 
} else { 
localB->TorqueRequest_Nm_e = (0.0F); 
}  
}  
}  
} 
break; 

case (uint8_T)4U:  __MW_INSTRUM_NODE_165(); 
{ 
boolean_T i_out; 
rtb_AutomaticTransmissionState = 0; 
i_out = __MW_INSTRUM_NODE_166((__MW_INSTRUM_NODE_168(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_170((__MW_INSTRUM_NODE_172(rtb_DataTypeConversion1, 0), (rtb_DataTypeConversion1 != 0)))); 
if (__MW_INSTRUM_NODE_175(i_out)) { 
localDW->is_c3_controller = (uint8_T)3U; 
rtb_AutomaticTransmissionState = 2; 
} else { 
localB->TorqueRequest_Nm_e = (0.0F); 
}  
} 
break; 

default:  __MW_INSTRUM_NODE_177(); 
{ 

rtb_AutomaticTransmissionState = 1; 
if (__MW_INSTRUM_NODE_178((__MW_INSTRUM_NODE_180(rtb_DataTypeConversion1, 1), (rtb_DataTypeConversion1 != 1)))) { 
localDW->is_Reverse = (uint8_T)0U; 
localDW->is_c3_controller = (uint8_T)3U; 
rtb_AutomaticTransmissionState = 2; 
} else { if (__MW_INSTRUM_NODE_183(((__mw_tmp_for_expr_17 = localDW->is_Reverse), ((__mw_tmp_for_expr_18 = (uint8_T)1U), (__MW_INSTRUM_NODE_185(__mw_tmp_for_expr_17, __mw_tmp_for_expr_18), (__mw_tmp_for_expr_17 == __mw_tmp_for_expr_18)))))) { 
boolean_T i_out; 
i_out = __MW_INSTRUM_NODE_188((__MW_INSTRUM_NODE_190(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_192((__MW_INSTRUM_NODE_194(rtb_Saturation, (0.0F)), (rtb_Saturation == (0.0F))))); 
if (__MW_INSTRUM_NODE_196(i_out)) { 
localDW->is_Reverse = (uint8_T)2U; 
} else { 
localB->StoppedControllerMode = (0.0F); 
localB->TorqueRequest_Nm_e = -rtb_Saturation * (real32_T)rtP_MAX_TORQUE_REVERSE; 

}  
} else { 
boolean_T i_out; 


i_out = __MW_INSTRUM_NODE_198(__MW_INSTRUM_NODE_200(!__MW_INSTRUM_NODE_202(*rtu_BrakePedalPressed)) && __MW_INSTRUM_NODE_204((__MW_INSTRUM_NODE_206(rtb_Saturation, (0.0F)), (rtb_Saturation > (0.0F))))); 
if (__MW_INSTRUM_NODE_208(i_out)) { 
localDW->is_Reverse = (uint8_T)1U; 
} else { 
localB->StoppedControllerMode = (1.0F); 
localB->TargetSpeed_km_h = (0.0); 
}  
}  }  
} 
break; 
}  
}  




if (__MW_INSTRUM_NODE_210(((__mw_tmp_for_expr_19 = localDW->temporalCounter_i1), (__MW_INSTRUM_NODE_212(__mw_tmp_for_expr_19, 127U), (__mw_tmp_for_expr_19 < 127U))))) { 
(localDW->temporalCounter_i1)++; 
}  

if (__MW_INSTRUM_NODE_215(((__mw_tmp_for_expr_20 = localDW->is_active_c1_controller), (__MW_INSTRUM_NODE_217(__mw_tmp_for_expr_20, 0U), (__mw_tmp_for_expr_20 == 0U))))) { 
localDW->is_active_c1_controller = (1U); 
localDW->is_c1_controller = (uint8_T)3U; 
} else { 
switch (localDW->is_c1_controller) { 
case (uint8_T)1U:  __MW_INSTRUM_NODE_220(); 
if (__MW_INSTRUM_NODE_221(((__mw_tmp_for_expr_21 = localDW->temporalCounter_i1), (__MW_INSTRUM_NODE_223(__mw_tmp_for_expr_21, 100U), (__mw_tmp_for_expr_21 >= 100U))))) { 
localDW->is_c1_controller = (uint8_T)2U; 
*rty_Error = (1.0F); 
} else { if (__MW_INSTRUM_NODE_226(((__mw_tmp_for_expr_22 = __MW_INSTRUM_NODE_231(*rtu_BrakePedalPressed_Backup)), ((__mw_tmp_for_expr_23 = __MW_INSTRUM_NODE_233(*rtu_BrakePedalPressed)), (__MW_INSTRUM_NODE_228(__mw_tmp_for_expr_22, __mw_tmp_for_expr_23), (__mw_tmp_for_expr_22 == __mw_tmp_for_expr_23)))))) { 
localDW->is_c1_controller = (uint8_T)3U; 
}  }  
break; 

case (uint8_T)2U:  __MW_INSTRUM_NODE_235(); 
localB->AutomaticTransmissionState = 2; 
localB->TorqueRequest_Nm = (0.0F); 
break; 

case (uint8_T)3U:  __MW_INSTRUM_NODE_236(); 
if (__MW_INSTRUM_NODE_237(((__mw_tmp_for_expr_24 = *rtu_ThrottlePedalPosition_Backu), (__MW_INSTRUM_NODE_239(__mw_tmp_for_expr_24, rtb_Saturation), (__mw_tmp_for_expr_24 != rtb_Saturation))))) { 
localDW->is_c1_controller = (uint8_T)4U; 
localDW->temporalCounter_i1 = (0U); 
} else { if (__MW_INSTRUM_NODE_241(((__mw_tmp_for_expr_25 = __MW_INSTRUM_NODE_246(*rtu_BrakePedalPressed_Backup)), ((__mw_tmp_for_expr_26 = __MW_INSTRUM_NODE_248(*rtu_BrakePedalPressed)), (__MW_INSTRUM_NODE_243(__mw_tmp_for_expr_25, __mw_tmp_for_expr_26), (__mw_tmp_for_expr_25 != __mw_tmp_for_expr_26)))))) { 
localDW->is_c1_controller = (uint8_T)1U; 
localDW->temporalCounter_i1 = (0U); 
} else { if (__MW_INSTRUM_NODE_250((__MW_INSTRUM_NODE_252(rtb_Saturation, (1.0F)), (rtb_Saturation > (1.0F))))) { 
localDW->is_c1_controller = (uint8_T)2U; 
*rty_Error = (1.0F); 
} else { 
*rty_Error = (0.0F); 
}  }  }  
break; 

default:  __MW_INSTRUM_NODE_254(); 

if (__MW_INSTRUM_NODE_255(((__mw_tmp_for_expr_27 = localDW->temporalCounter_i1), (__MW_INSTRUM_NODE_257(__mw_tmp_for_expr_27, 100U), (__mw_tmp_for_expr_27 >= 100U))))) { 
localDW->is_c1_controller = (uint8_T)2U; 
*rty_Error = (1.0F); 
} else { if (__MW_INSTRUM_NODE_260(((__mw_tmp_for_expr_28 = *rtu_ThrottlePedalPosition_Backu), (__MW_INSTRUM_NODE_262(__mw_tmp_for_expr_28, rtb_Saturation), (__mw_tmp_for_expr_28 == rtb_Saturation))))) { 
localDW->is_c1_controller = (uint8_T)3U; 
}  }  
break; 
}  
}  
#line 391
if (__MW_INSTRUM_NODE_264(!__MW_INSTRUM_NODE_266(((__mw_tmp_for_expr_29 = *rty_Error), (__MW_INSTRUM_NODE_268(__mw_tmp_for_expr_29, (0.0F)), (__mw_tmp_for_expr_29 != (0.0F))))))) { 
real_T rtb_Sum; 
#line 398
if (__MW_INSTRUM_NODE_270(!__MW_INSTRUM_NODE_272(((__mw_tmp_for_expr_30 = localB->StoppedControllerMode), (__MW_INSTRUM_NODE_274(__mw_tmp_for_expr_30, (0.0F)), (__mw_tmp_for_expr_30 != (0.0F))))))) { 
rtb_Sum = localB->TorqueRequest_Nm_e; 
} else { 

rtb_Sum = localB->TargetSpeed_km_h - *rtu_VehicleSpeed_km_h; 
rtb_Sum *= controller_P.Gain_Gain; 
}  




if (__MW_INSTRUM_NODE_276(((__mw_tmp_for_expr_31 = controller_P.Saturation1_UpperSat), (__MW_INSTRUM_NODE_278(rtb_Sum, __mw_tmp_for_expr_31), (rtb_Sum > __mw_tmp_for_expr_31))))) { 
*rty_TorqueRequest_Nm = (real32_T)(controller_P.Saturation1_UpperSat); 
} else { if (__MW_INSTRUM_NODE_280(((__mw_tmp_for_expr_32 = controller_P.Saturation1_LowerSat), (__MW_INSTRUM_NODE_282(rtb_Sum, __mw_tmp_for_expr_32), (rtb_Sum < __mw_tmp_for_expr_32))))) { 
*rty_TorqueRequest_Nm = (real32_T)(controller_P.Saturation1_LowerSat); 
} else { 
*rty_TorqueRequest_Nm = (real32_T)rtb_Sum; 
}  }  


} else { 
*rty_TorqueRequest_Nm = localB->TorqueRequest_Nm; 
}  
#line 429
if (__MW_INSTRUM_NODE_284(!__MW_INSTRUM_NODE_286(((__mw_tmp_for_expr_33 = *rty_Error), (__MW_INSTRUM_NODE_288(__mw_tmp_for_expr_33, (0.0F)), (__mw_tmp_for_expr_33 != (0.0F))))))) { 
*rty_AutomaticTransmissionState = (TransmissionState)rtb_AutomaticTransmissionState; 

} else { 
*rty_AutomaticTransmissionState = (TransmissionState)(localB->AutomaticTransmissionState); 

}  } __MW_INSTRUM_NODE_290(); 


} 


void controller_initialize(const char_T **rt_errorStatus, RT_MODEL_controller_T *const 
controller_M, B_controller_c_T *localB, DW_controller_f_T *localDW) 
{ __MW_INSTRUM_FCN_ENTER_4(); __MW_INSTRUM_NODE_291(); 



controller_M->errorStatus = rt_errorStatus; 


(void)(__MW_INSTRUM_NODE_292(), memset((void *)localB, 0, sizeof(B_controller_c_T))); 



(void)(__MW_INSTRUM_NODE_293(), memset((void *)localDW, 0, sizeof(DW_controller_f_T))); __MW_INSTRUM_NODE_294(); 

} 
